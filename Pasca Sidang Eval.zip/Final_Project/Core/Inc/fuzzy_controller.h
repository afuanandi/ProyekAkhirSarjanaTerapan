/**
 * @file fuzzy_controller.h
 * @brief Type-2 Fuzzy Logic Controller for 7-Level PUCI Inverter - REDESIGNED
 * @author afuanandi
 * @date 2025
 *
 * REDESIGN CHANGES:
 * - Input range: ±50V (handles 180-270V output)
 * - Reduced Type-2 uncertainty (Z lower=0.8) to eliminate oscillation
 * - Removed MI output smoothing
 * - Tunable startup delay
 */

#ifndef FUZZY_CONTROLLER_H
#define FUZZY_CONTROLLER_H

#include "main.h"
#include "fuzzy_structures.h"
#include "ac_sensor.h"
#include <math.h>
#include <stdio.h>

/* ============================================================================
 * CONFIGURATION PARAMETERS
 * ============================================================================ */

/* Target and Limits */
#define FUZZY_TARGET_VOLTAGE        220.0f      // Target voltage (V RMS)
// Note: FUZZY_MI_MIN, FUZZY_MI_MAX defined in main.h (system-wide constants)
#define FUZZY_MI_DEFAULT            1.0f        // Default MI (fallback)

/* Filtering */
#define FUZZY_DERIVATIVE_ALPHA      0.5f        // Derivative filter coefficient

/* Fuzzy Input Ranges - REDESIGNED */
#define FUZZY_INPUT_RANGE_MAX       50.0f       // ±50V fuzzy input range (was ±17V)

/* Tunable Startup Delay Configuration */
#define FUZZY_STARTUP_DELAY_ENABLE  0           // 1 = Enable delay, 0 = Skip directly to NORMAL
#define FUZZY_STARTUP_DELAY_MS      100         // Startup delay duration (ms)
                                                // Recommendation: 100ms = 5 RMS cycles
                                                // Set to 0 to disable even if ENABLE=1

/* Safety Thresholds */
#define FUZZY_MAX_ERROR             60.0f       // Fault if |error| > 60V (was 50V)
#define FUZZY_SENSOR_TIMEOUT_MS     100         // Fault if no sensor update

/* Debug */
#define FUZZY_DEBUG_BUFFER_SIZE     200

/* ============================================================================
 * TYPE DEFINITIONS
 * ============================================================================ */

/**
 * @brief Fuzzy controller state machine
 */
typedef enum {
    FUZZY_STATE_DISABLED,       // Controller disabled (open loop active)
    FUZZY_STATE_WAIT_MLBC,      // Waiting for MLBC to reach RUNNING state
    FUZZY_STATE_WAIT_STABLE,    // Waiting for stability delay (tunable)
    FUZZY_STATE_NORMAL,         // Active regulation
    FUZZY_STATE_FAULT           // Fault condition detected
} FuzzyControllerState_t;

/**
 * @brief Main Fuzzy Controller Structure
 */
typedef struct {
    /* State Management */
    FuzzyControllerState_t state;   // Current state
    uint8_t initialized;            // Initialization flag
    uint32_t state_entry_time;      // Time when current state was entered

    /* Setpoint and Measurement */
    float target_voltage;           // Target voltage setpoint (V RMS)
    float current_voltage;          // Current measured voltage (V RMS)

    /* Error Processing */
    float error;                    // Voltage error (target - actual)
    float previous_error;           // Previous error for derivative
    float error_derivative_raw;     // Raw error derivative
    float error_derivative_filtered;// Filtered error derivative

    /* Fuzzy System Inputs (Direct mapping, no scaling) */
    float fuzzy_error;              // Error input to fuzzy
    float fuzzy_derror;             // Derivative input to fuzzy

    /* Fuzzy System Outputs - SIMPLIFIED (removed smoothing) */
    float fuzzy_output_raw;         // Raw output from fuzzy inference
    float fuzzy_output_final;       // Final output after clamping

    /* Statistics and Monitoring */
    uint32_t update_count;          // Total updates performed
    uint32_t out_of_range_count;    // Input out-of-range occurrences
    uint32_t sensor_timeout_count;  // Sensor timeout occurrences
    uint32_t last_sensor_timestamp; // Last AC sensor update time

    /* Debug System */
    uint8_t debug_enabled;          // Debug output flag
    char debug_buffer[FUZZY_DEBUG_BUFFER_SIZE];

} FuzzyController_t;

/* ============================================================================
 * EXTERNAL VARIABLES
 * ============================================================================ */

extern FuzzyController_t fuzzy_controller;
extern FuzzySystem fuzzy_system;
extern UART_HandleTypeDef huart2;

/* ============================================================================
 * FUNCTION PROTOTYPES
 * ============================================================================ */

/* Core Functions */

/**
 * @brief Initialize the fuzzy controller system
 * Call once during system initialization
 */
void Fuzzy_Controller_Init(void);

/**
 * @brief Main fuzzy controller update function - EVENT-DRIVEN
 *
 * THIS SHOULD BE CALLED FROM AC_Sensor_Update() after RMS calculation completes
 * DO NOT call from main loop timer!
 *
 * @return Modulation index for POD PWM (0.75 - 1.25 range)
 */
float Fuzzy_Controller_Update(void);

/**
 * @brief Enable fuzzy controller with bumpless transfer
 * Call when switching from open loop to closed loop
 * Initializes from current POD PWM modulation index
 */
void Fuzzy_Controller_Enable(void);

/**
 * @brief Disable fuzzy controller
 * Returns to DISABLED state, ready for re-enable
 */
void Fuzzy_Controller_Disable(void);

/**
 * @brief Reset controller to initial state
 * Clears error history and statistics
 */
void Fuzzy_Controller_Reset(void);

/* Configuration Functions */

/**
 * @brief Set target voltage setpoint
 * @param target_voltage: New target voltage in V RMS
 */
void Fuzzy_Controller_Set_Target_Voltage(float target_voltage);

/**
 * @brief Get current target voltage
 * @return Target voltage in V RMS
 */
float Fuzzy_Controller_Get_Target_Voltage(void);

/**
 * @brief Enable/disable debug output
 * @param enable: 1 to enable, 0 to disable
 */
void Fuzzy_Controller_Set_Debug(uint8_t enable);

/* Status Functions */

/**
 * @brief Get current controller state
 * @return Current fuzzy controller state
 */
FuzzyControllerState_t Fuzzy_Controller_Get_State(void);

/**
 * @brief Check if controller is actively regulating
 * @return 1 if in NORMAL state, 0 otherwise
 */
uint8_t Fuzzy_Controller_Is_Active(void);

/**
 * @brief Get current error value
 * @return Voltage error in V
 */
float Fuzzy_Controller_Get_Error(void);

/**
 * @brief Get current output MI
 * @return Current modulation index
 */
float Fuzzy_Controller_Get_Output(void);

/* Debug Functions */

/**
 * @brief Transmit debug data via UART
 * Call from main loop debug section
 */
void Fuzzy_Controller_Debug_Transmit(void);

/**
 * @brief Get controller statistics string
 * @param buffer: Output buffer
 * @param buffer_size: Size of buffer
 */
void Fuzzy_Controller_Get_Statistics(char* buffer, size_t buffer_size);

/* ============================================================================
 * INTERNAL FUNCTIONS (Do not call directly)
 * ============================================================================ */

/**
 * @brief Process startup state machine
 */
void Fuzzy_Controller_Process_Startup(void);

/**
 * @brief Calculate error and derivative
 */
void Fuzzy_Controller_Calculate_Error(void);

/**
 * @brief Apply derivative filtering
 */
void Fuzzy_Controller_Apply_Derivative_Filter(void);

/**
 * @brief Prepare fuzzy inputs (direct mapping)
 */
void Fuzzy_Controller_Prepare_Inputs(void);

/**
 * @brief Check if inputs are within safe range
 * @return 1 if safe, 0 if out of range
 */
uint8_t Fuzzy_Controller_Check_Input_Range(void);

/**
 * @brief Apply output limits
 */
void Fuzzy_Controller_Apply_Output_Limits(void);

/**
 * @brief Check for fault conditions
 * @return 1 if fault detected, 0 if OK
 */
uint8_t Fuzzy_Controller_Check_Faults(void);

#endif /* FUZZY_CONTROLLER_H */
