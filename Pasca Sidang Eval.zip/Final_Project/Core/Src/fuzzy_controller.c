/**
 * @file fuzzy_controller.c
 * @brief Type-2 Fuzzy Logic Controller Implementation
 * @author afuanandi
 * @date 2025
 *
 */

#include "fuzzy_controller.h"
#include "fuzzy_init.h"
#include "pod_pwm.h"
#include "pwm_mlbc.h"

/* Global controller structure */
FuzzyController_t fuzzy_controller;

/* Global fuzzy system */
FuzzySystem fuzzy_system;

/* ============================================================================
 * PUBLIC FUNCTIONS
 * ============================================================================ */

/**
 * @brief Initialize the fuzzy controller system
 */
void Fuzzy_Controller_Init(void) {
    /* Clear structure */
    memset(&fuzzy_controller, 0, sizeof(FuzzyController_t));

    /* Initialize state */
    fuzzy_controller.state = FUZZY_STATE_DISABLED;
    fuzzy_controller.initialized = 0;
    fuzzy_controller.state_entry_time = HAL_GetTick();

    /* Initialize setpoint */
    fuzzy_controller.target_voltage = FUZZY_TARGET_VOLTAGE;
    fuzzy_controller.current_voltage = 0.0f;

    /* Initialize errors */
    fuzzy_controller.error = 0.0f;
    fuzzy_controller.previous_error = 0.0f;
    fuzzy_controller.error_derivative_raw = 0.0f;
    fuzzy_controller.error_derivative_filtered = 0.0f;

    /* Initialize fuzzy inputs/outputs */
    fuzzy_controller.fuzzy_error = 0.0f;
    fuzzy_controller.fuzzy_derror = 0.0f;
    fuzzy_controller.fuzzy_output_raw = FUZZY_MI_DEFAULT;
    fuzzy_controller.fuzzy_output_final = FUZZY_MI_DEFAULT;

    /* Initialize statistics */
    fuzzy_controller.update_count = 0;
    fuzzy_controller.out_of_range_count = 0;
    fuzzy_controller.sensor_timeout_count = 0;
    fuzzy_controller.last_sensor_timestamp = HAL_GetTick();

    /* Initialize debug */
    fuzzy_controller.debug_enabled = 0;

    /* Initialize Type-2 fuzzy system */
    if(InitializeFuzzySystem(&fuzzy_system) == 0) {
        fuzzy_controller.initialized = 1;
        printf("Fuzzy Controller REDESIGNED - Type-2\r\n");
        printf("Input: +/-%.0fV, Output: [0-2] clamped [%.2f-%.2f]\r\n",
               FUZZY_INPUT_RANGE_MAX, FUZZY_MI_MIN, FUZZY_MI_MAX);
        printf("Startup delay: %s",
               FUZZY_STARTUP_DELAY_ENABLE ? "Enabled" : "Disabled");
        if(FUZZY_STARTUP_DELAY_ENABLE) {
            printf(" (%dms)\r\n", FUZZY_STARTUP_DELAY_MS);
        } else {
            printf("\r\n");
        }
    } else {
        fuzzy_controller.state = FUZZY_STATE_FAULT;
        printf("ERROR: Fuzzy system initialization failed\r\n");
    }
}

/**
 * @brief Main fuzzy controller update - EVENT DRIVEN
 * Called from AC_Sensor_Update() after RMS calculation
 */
float Fuzzy_Controller_Update(void) {
    /* Check initialization */
    if(!fuzzy_controller.initialized) {
        return FUZZY_MI_DEFAULT;
    }

    /* Update sensor timestamp */
    fuzzy_controller.last_sensor_timestamp = HAL_GetTick();

    /* State machine processing */
    switch(fuzzy_controller.state) {
        case FUZZY_STATE_DISABLED:
            /* Controller not active - return default MI */
            return FUZZY_MI_DEFAULT;

        case FUZZY_STATE_WAIT_MLBC:
        case FUZZY_STATE_WAIT_STABLE:
            /* Process startup sequence */
            Fuzzy_Controller_Process_Startup();
            return FUZZY_MI_DEFAULT;

        case FUZZY_STATE_NORMAL:
            /* Active regulation - proceed with control algorithm */
            break;

        case FUZZY_STATE_FAULT:
            /* Fault state - return default MI */
            return FUZZY_MI_DEFAULT;
    }

    /* Get current voltage measurement */
    fuzzy_controller.current_voltage = AC_Sensor_Get_Voltage_RMS();

    /* Calculate error and derivative */
    Fuzzy_Controller_Calculate_Error();

    /* Apply derivative filtering */
    Fuzzy_Controller_Apply_Derivative_Filter();

    /* Prepare fuzzy inputs (direct mapping, no scaling) */
    Fuzzy_Controller_Prepare_Inputs();

    /* Check input safety (optional - can be disabled for performance) */
    // if(!Fuzzy_Controller_Check_Input_Range()) {
    //     fuzzy_controller.out_of_range_count++;
    //     fuzzy_controller.fuzzy_output_final = FUZZY_MI_DEFAULT;
    //     if(fuzzy_controller.debug_enabled) {
    //         printf("Fuzzy: Input out of range, using default MI\r\n");
    //     }
    //     return fuzzy_controller.fuzzy_output_final;
    // }

    /* Perform fuzzy inference */
    fuzzy_controller.fuzzy_output_raw = FuzzyInference(&fuzzy_system,
                                                       fuzzy_controller.fuzzy_error,
                                                       fuzzy_controller.fuzzy_derror);

    /* Direct assignment - no smoothing */
    fuzzy_controller.fuzzy_output_final = fuzzy_controller.fuzzy_output_raw;

    /* Apply output limits */
    Fuzzy_Controller_Apply_Output_Limits();

    /* Check for faults */
    if(Fuzzy_Controller_Check_Faults()) {
        fuzzy_controller.state = FUZZY_STATE_FAULT;
        printf("Fuzzy: FAULT detected, entering fault state\r\n");
        return FUZZY_MI_DEFAULT;
    }

    /* Update error history for next iteration */
    fuzzy_controller.previous_error = fuzzy_controller.error;

    /* Update statistics */
    fuzzy_controller.update_count++;

    /* Return final output */
    return fuzzy_controller.fuzzy_output_final;
}

/**
 * @brief Enable fuzzy controller with bumpless transfer
 */
void Fuzzy_Controller_Enable(void) {
    if(!fuzzy_controller.initialized) {
        printf("Fuzzy: Cannot enable - not initialized\r\n");
        return;
    }

    /* Bumpless transfer: Initialize from current POD PWM MI */
    float current_mi = POD_PWM_Get_Current_MI();
    fuzzy_controller.fuzzy_output_final = current_mi;

    /* Reset error history */
    fuzzy_controller.error = 0.0f;
    fuzzy_controller.previous_error = 0.0f;
    fuzzy_controller.error_derivative_filtered = 0.0f;

    /* Enter startup sequence */
    fuzzy_controller.state = FUZZY_STATE_WAIT_MLBC;
    fuzzy_controller.state_entry_time = HAL_GetTick();

    printf("Fuzzy: Enabled with bumpless transfer from MI=%.3f\r\n", current_mi);
}

/**
 * @brief Disable fuzzy controller
 */
void Fuzzy_Controller_Disable(void) {
    fuzzy_controller.state = FUZZY_STATE_DISABLED;
    printf("Fuzzy: Disabled\r\n");
}

/**
 * @brief Reset controller to initial state
 */
void Fuzzy_Controller_Reset(void) {
    fuzzy_controller.state = FUZZY_STATE_DISABLED;
    fuzzy_controller.error = 0.0f;
    fuzzy_controller.previous_error = 0.0f;
    fuzzy_controller.error_derivative_filtered = 0.0f;
    fuzzy_controller.update_count = 0;
    fuzzy_controller.out_of_range_count = 0;
    fuzzy_controller.sensor_timeout_count = 0;

    printf("Fuzzy: Reset complete\r\n");
}

/**
 * @brief Set target voltage
 */
void Fuzzy_Controller_Set_Target_Voltage(float target_voltage) {
    fuzzy_controller.target_voltage = target_voltage;
    printf("Fuzzy: Target voltage set to %.1fV\r\n", target_voltage);
}

/**
 * @brief Get target voltage
 */
float Fuzzy_Controller_Get_Target_Voltage(void) {
    return fuzzy_controller.target_voltage;
}

/**
 * @brief Enable/disable debug
 */
void Fuzzy_Controller_Set_Debug(uint8_t enable) {
    fuzzy_controller.debug_enabled = enable;
    if(enable) {
        printf("Fuzzy: Debug enabled\r\n");
    } else {
        printf("Fuzzy: Debug disabled\r\n");
    }
}

/**
 * @brief Get current state
 */
FuzzyControllerState_t Fuzzy_Controller_Get_State(void) {
    return fuzzy_controller.state;
}

/**
 * @brief Check if actively regulating
 */
uint8_t Fuzzy_Controller_Is_Active(void) {
    return (fuzzy_controller.state == FUZZY_STATE_NORMAL) ? 1 : 0;
}

/**
 * @brief Get current error
 */
float Fuzzy_Controller_Get_Error(void) {
    return fuzzy_controller.error;
}

/**
 * @brief Get current output
 */
float Fuzzy_Controller_Get_Output(void) {
    return fuzzy_controller.fuzzy_output_final;
}

/**
 * @brief Transmit debug data
 */
void Fuzzy_Controller_Debug_Transmit(void) {
    if(fuzzy_controller.debug_enabled) {
        /* Updated format - removed smoothed output column */
        snprintf(fuzzy_controller.debug_buffer, sizeof(fuzzy_controller.debug_buffer),
            "FUZZY,%.1f,%.3f,%.3f,%.3f,%.3f,%.3f,%.3f,%.3f,%d\r\n",
            fuzzy_controller.current_voltage,
            fuzzy_controller.error,
            fuzzy_controller.error_derivative_raw,
            fuzzy_controller.error_derivative_filtered,
            fuzzy_controller.fuzzy_error,
            fuzzy_controller.fuzzy_derror,
            fuzzy_controller.fuzzy_output_raw,
            fuzzy_controller.fuzzy_output_final,
            fuzzy_controller.state);

        HAL_UART_Transmit(&huart2, (uint8_t*)fuzzy_controller.debug_buffer,
                         strlen(fuzzy_controller.debug_buffer), 100);
    }
}

/**
 * @brief Get statistics string
 */
void Fuzzy_Controller_Get_Statistics(char* buffer, size_t buffer_size) {
    const char* state_strings[] = {
        "DISABLED", "WAIT_MLBC", "WAIT_STABLE", "NORMAL", "FAULT"
    };

    snprintf(buffer, buffer_size,
        "FUZZY: %s,Tgt:%.1fV,Cur:%.1fV,Err:%.2fV,MI:%.3f,Upd:%lu,OOR:%lu",
        state_strings[fuzzy_controller.state],
        fuzzy_controller.target_voltage,
        fuzzy_controller.current_voltage,
        fuzzy_controller.error,
        fuzzy_controller.fuzzy_output_final,
        fuzzy_controller.update_count,
        fuzzy_controller.out_of_range_count);
}

/* ============================================================================
 * INTERNAL FUNCTIONS
 * ============================================================================ */

/**
 * @brief Process startup state machine with tunable delay
 */
void Fuzzy_Controller_Process_Startup(void) {
    uint32_t time_in_state = HAL_GetTick() - fuzzy_controller.state_entry_time;

    switch(fuzzy_controller.state) {
        case FUZZY_STATE_WAIT_MLBC:
            /* Check if MLBC is running */
            if(MLBC_Get_State() == MLBC_STATE_RUNNING) {
                /* MLBC reached running state */

                #if FUZZY_STARTUP_DELAY_ENABLE
                    /* Startup delay enabled - enter wait state */
                    if(FUZZY_STARTUP_DELAY_MS > 0) {
                        fuzzy_controller.state = FUZZY_STATE_WAIT_STABLE;
                        fuzzy_controller.state_entry_time = HAL_GetTick();
                        printf("Fuzzy: MLBC running, waiting %dms for stability...\r\n",
                               FUZZY_STARTUP_DELAY_MS);
                    } else {
                        /* Delay set to 0 - skip directly to normal */
                        fuzzy_controller.state = FUZZY_STATE_NORMAL;
                        fuzzy_controller.state_entry_time = HAL_GetTick();
                        printf("Fuzzy: MLBC running, regulation active (no delay)\r\n");
                    }
                #else
                    /* Startup delay disabled - skip directly to normal */
                    fuzzy_controller.state = FUZZY_STATE_NORMAL;
                    fuzzy_controller.state_entry_time = HAL_GetTick();
                    printf("Fuzzy: MLBC running, regulation active (delay disabled)\r\n");
                #endif
            }
            break;

        case FUZZY_STATE_WAIT_STABLE:
            /* Wait for stability delay (only reached if enabled and > 0) */
            if(time_in_state >= FUZZY_STARTUP_DELAY_MS) {
                /* Stability delay complete - begin regulation */
                fuzzy_controller.state = FUZZY_STATE_NORMAL;
                fuzzy_controller.state_entry_time = HAL_GetTick();
                printf("Fuzzy: Startup complete, regulation active\r\n");
            }
            break;

        default:
            break;
    }
}

/**
 * @brief Calculate error and derivative
 */
void Fuzzy_Controller_Calculate_Error(void) {
    /* Calculate error */
    fuzzy_controller.error = fuzzy_controller.target_voltage -
                            fuzzy_controller.current_voltage;

    /* Calculate raw derivative */
    fuzzy_controller.error_derivative_raw = fuzzy_controller.error -
                                           fuzzy_controller.previous_error;
}

/**
 * @brief Apply derivative filtering
 */
void Fuzzy_Controller_Apply_Derivative_Filter(void) {
    /* First-order low-pass filter */
    fuzzy_controller.error_derivative_filtered =
        FUZZY_DERIVATIVE_ALPHA * fuzzy_controller.error_derivative_filtered +
        (1.0f - FUZZY_DERIVATIVE_ALPHA) * fuzzy_controller.error_derivative_raw;
}

/**
 * @brief Prepare fuzzy inputs (direct mapping)
 */
void Fuzzy_Controller_Prepare_Inputs(void) {
    /* Direct mapping with clamping to fuzzy range */
    fuzzy_controller.fuzzy_error = fuzzy_controller.error;
    fuzzy_controller.fuzzy_derror = fuzzy_controller.error_derivative_filtered;

    /* Clamp error to [-50, +50] range */
    if(fuzzy_controller.fuzzy_error > FUZZY_INPUT_RANGE_MAX) {
        fuzzy_controller.fuzzy_error = FUZZY_INPUT_RANGE_MAX;
    } else if(fuzzy_controller.fuzzy_error < -FUZZY_INPUT_RANGE_MAX) {
        fuzzy_controller.fuzzy_error = -FUZZY_INPUT_RANGE_MAX;
    }

    /* Clamp derivative to [-50, +50] range */
    if(fuzzy_controller.fuzzy_derror > FUZZY_INPUT_RANGE_MAX) {
        fuzzy_controller.fuzzy_derror = FUZZY_INPUT_RANGE_MAX;
    } else if(fuzzy_controller.fuzzy_derror < -FUZZY_INPUT_RANGE_MAX) {
        fuzzy_controller.fuzzy_derror = -FUZZY_INPUT_RANGE_MAX;
    }
}

/**
 * @brief Check if inputs are within safe range
 */
uint8_t Fuzzy_Controller_Check_Input_Range(void) {
    /* Check if inputs are within fuzzy system range [-50, +50] */
    if(fabsf(fuzzy_controller.fuzzy_error) > FUZZY_INPUT_RANGE_MAX) {
        return 0;
    }

    if(fabsf(fuzzy_controller.fuzzy_derror) > FUZZY_INPUT_RANGE_MAX) {
        return 0;
    }

    return 1;
}

/**
 * @brief Apply output limits
 */
void Fuzzy_Controller_Apply_Output_Limits(void) {
    /* Apply minimum limit */
    if(fuzzy_controller.fuzzy_output_final < FUZZY_MI_MIN) {
        fuzzy_controller.fuzzy_output_final = FUZZY_MI_MIN;
    }

    /* Apply maximum limit */
    if(fuzzy_controller.fuzzy_output_final > FUZZY_MI_MAX) {
        fuzzy_controller.fuzzy_output_final = FUZZY_MI_MAX;
    }
}

/**
 * @brief Check for fault conditions
 */
uint8_t Fuzzy_Controller_Check_Faults(void) {
    /* Check for excessive error */
    if(fabsf(fuzzy_controller.error) > FUZZY_MAX_ERROR) {
        printf("Fuzzy FAULT: Error too large (%.1fV)\r\n",
               fuzzy_controller.error);
        return 1;
    }

    /* Check for sensor timeout */
    uint32_t time_since_sensor = HAL_GetTick() - fuzzy_controller.last_sensor_timestamp;
    if(time_since_sensor > FUZZY_SENSOR_TIMEOUT_MS) {
        printf("Fuzzy FAULT: Sensor timeout (%lums)\r\n", time_since_sensor);
        fuzzy_controller.sensor_timeout_count++;
        return 1;
    }

    /* Check for invalid voltage reading */
    if(fuzzy_controller.current_voltage <= 0.0f ||
       fuzzy_controller.current_voltage > 400.0f) {
        printf("Fuzzy FAULT: Invalid voltage (%.1fV)\r\n",
               fuzzy_controller.current_voltage);
        return 1;
    }

    return 0;
}
