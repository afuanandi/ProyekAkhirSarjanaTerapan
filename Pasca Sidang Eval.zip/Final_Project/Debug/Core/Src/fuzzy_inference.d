Core/Src/fuzzy_inference.o: ../Core/Src/fuzzy_inference.c \
 ../Core/Inc/fuzzy_init.h ../Core/Inc/fuzzy_structures.h
../Core/Inc/fuzzy_init.h:
../Core/Inc/fuzzy_structures.h:
