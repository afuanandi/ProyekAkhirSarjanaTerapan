/**
 * @file oled_display.h
 * @brief OLED display management with non-blocking updates
 * @author afuanandi
 * @date 2025
 */

#ifndef OLED_DISPLAY_H
#define OLED_DISPLAY_H

#include "sh1106.h"  // Updated to use non-blocking SH1106 driver
#include "main.h"

/* Display layout constants (same as before) */
#define OLED_WIDTH 128
#define OLED_HEIGHT 64
#define OLED_CENTER_LINE 64
#define OLED_TITLE_ROW 0
#define OLED_VOLTAGE_ROW 16
#define OLED_CURRENT_ROW 24
#define OLED_POWER_ROW 32
#define OLED_MI_ROW 46
#define OLED_STATUS_ROW 56
#define OLED_SEPARATOR_ROW 10

/* Display data structure (same as before) */
typedef struct {
    /* DC Input values */
    float dc_voltage;
    float dc_current;
    float dc_power;

    /* AC Output values */
    float ac_voltage;
    float ac_current;
    float ac_power;
    float modulation_index;

    /* Status indicators */
    uint8_t converter_status;    // 0: OFF, 1: ON
    uint8_t control_mode;        // 0: Open Loop, 1: Closed Loop
} DisplayData_t;

/* Function prototypes */

/**
 * @brief Initialize the OLED display system
 * This function is blocking (only called once during startup)
 */
void OLED_Display_Init(void);

/**
 * @brief Non-blocking update function - call from main loop frequently (1-5ms)
 * This processes the chunked I2C transmission in the background
 */
void OLED_Display_Update_NonBlocking(void);

/**
 * @brief Update display with new data structure
 * This modifies the display buffer and requests an update
 * @param data: Pointer to display data structure
 */
void OLED_Display_Update(DisplayData_t* data);

/**
 * @brief Draw the basic layout (titles, separators)
 * Call this once during initialization or when layout needs refresh
 */
void OLED_Display_DrawLayout(void);

/**
 * @brief Update display with data from system sensors and controllers
 * This is the main function called from your main loop every 500ms
 * @param dc_voltage: DC bus voltage
 * @param dc_current: DC bus current
 * @param ac_voltage: AC output voltage RMS
 * @param ac_current: AC output current RMS
 * @param modulation_index: Current modulation index
 * @param converter_status: Converter ON/OFF status (0/1)
 * @param control_mode: Open loop (0) or Closed loop (1)
 * @param sensor_mode: Normal (0) or Calibration (1)
 */
void OLED_Display_UpdateFromSystem(float dc_voltage, float dc_current,
                                  float ac_voltage, float ac_current,
                                  float modulation_index, uint8_t converter_status,
                                  uint8_t control_mode, uint8_t sensor_mode);

/**
 * @brief Check if display is currently updating
 * @return: 1 if display update in progress, 0 if idle
 */
uint8_t OLED_Display_Is_Updating(void);

/**
 * @brief Force immediate display update
 * Use sparingly - only for critical updates
 */
void OLED_Display_Force_Update(void);

/**
 * @brief Get display statistics for debugging
 * @param buffer: Output buffer for statistics
 * @param buffer_size: Size of output buffer
 */
void OLED_Display_Get_Statistics(char* buffer, size_t buffer_size);

#endif /* OLED_DISPLAY_H */
