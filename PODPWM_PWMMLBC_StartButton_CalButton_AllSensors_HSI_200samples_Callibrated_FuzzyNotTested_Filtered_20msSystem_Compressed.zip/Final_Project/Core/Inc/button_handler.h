/**
 * @file button_handler.h
 * @brief Non-blocking button handler with state machine debouncing
 * @author afuanandi & Claude
 * @date 2025
 *
 * This module provides non-blocking button handling with proper debouncing
 * for real-time embedded systems. No HAL_Delay() calls are used.
 */

#ifndef BUTTON_HANDLER_H
#define BUTTON_HANDLER_H

#include "main.h"
#include <stdint.h>

/* Button Configuration */
#define BUTTON_DEBOUNCE_TIME_MS 50      // 50ms debounce time
#define BUTTON_LONG_PRESS_TIME_MS 1000  // 1 second for long press
#define MAX_BUTTONS 2                   // Number of buttons in system

/* Button IDs */
typedef enum {
    BUTTON_START_STOP = 0,
    BUTTON_MODE = 1
} ButtonID_t;

/* Button States */
typedef enum {
    BUTTON_STATE_IDLE,          // Button not pressed
    BUTTON_STATE_DEBOUNCE,      // Debouncing in progress
    BUTTON_STATE_PRESSED,       // Button confirmed pressed
    BUTTON_STATE_LONG_PRESS     // Long press detected
} ButtonState_t;

/* Button Events */
typedef enum {
    BUTTON_EVENT_NONE,
    BUTTON_EVENT_PRESS,         // Short press detected
    BUTTON_EVENT_LONG_PRESS,    // Long press detected
    BUTTON_EVENT_RELEASE        // Button released
} ButtonEvent_t;

/* Button Configuration Structure */
typedef struct {
    GPIO_TypeDef* gpio_port;    // GPIO port
    uint16_t gpio_pin;          // GPIO pin
    uint8_t active_low;         // 1 if button is active low, 0 if active high
    const char* name;           // Button name for debugging
} ButtonConfig_t;

/* Button Runtime Structure */
typedef struct {
    ButtonState_t state;        // Current button state
    uint32_t state_start_time;  // Time when current state started
    uint8_t last_reading;       // Last GPIO reading
    uint8_t stable_reading;     // Stable reading after debounce
    ButtonEvent_t pending_event; // Pending event to be processed
    uint32_t press_count;       // Total press count (for statistics)
} ButtonRuntime_t;

/* Button Handler System Structure */
typedef struct {
    ButtonConfig_t config[MAX_BUTTONS];     // Button configurations
    ButtonRuntime_t runtime[MAX_BUTTONS];   // Button runtime data
    uint8_t initialized;                    // System initialized flag
    uint32_t last_update_time;              // Last update timestamp
} ButtonHandler_t;

/* External Variables */
extern ButtonHandler_t button_handler;

/* Function Prototypes */

/**
 * @brief Initialize the button handler system
 */
void Button_Handler_Init(void);

/**
 * @brief Update button states (call from main loop every 1-5ms)
 * This is the main update function that should be called frequently
 */
void Button_Handler_Update(void);

/**
 * @brief Check if a button event is pending
 * @param button_id: Button ID to check
 * @return: Button event type
 */
ButtonEvent_t Button_Handler_Get_Event(ButtonID_t button_id);

/**
 * @brief Clear a pending button event
 * @param button_id: Button ID to clear
 */
void Button_Handler_Clear_Event(ButtonID_t button_id);

/**
 * @brief Get current button state
 * @param button_id: Button ID to check
 * @return: Current button state
 */
ButtonState_t Button_Handler_Get_State(ButtonID_t button_id);

/**
 * @brief Check if button is currently pressed (stable)
 * @param button_id: Button ID to check
 * @return: 1 if pressed, 0 if not pressed
 */
uint8_t Button_Handler_Is_Pressed(ButtonID_t button_id);

/**
 * @brief Get button press statistics
 * @param button_id: Button ID to check
 * @return: Total number of presses since initialization
 */
uint32_t Button_Handler_Get_Press_Count(ButtonID_t button_id);

/**
 * @brief Get button name for debugging
 * @param button_id: Button ID
 * @return: Button name string
 */
const char* Button_Handler_Get_Name(ButtonID_t button_id);

#endif /* BUTTON_HANDLER_H */
