/**
 * @file fuzzy_structures.h
 * @brief Data structures for type-2 fuzzy logic controller
 * @author afuanandi
 */

#ifndef FUZZY_STRUCTURES_H
#define FUZZY_STRUCTURES_H

#include <stdint.h>

/**
 * @brief Type definition for floating point type used in fuzzy calculations
 * Note: Can be changed to float for memory optimization if needed
 */
typedef float fuzzy_t;

/**
 * @brief Triangular membership function parameters
 */
typedef struct {
    fuzzy_t a; // Left point
    fuzzy_t b; // Center point
    fuzzy_t c; // Right point
    fuzzy_t upper; // Upper membership grade (typically 1.0)
    fuzzy_t lower; // Lower membership grade (0.5 in your design)
    fuzzy_t lowerUncertainty; // Lower membership uncertainty
    fuzzy_t upperUncertainty; // Upper membership uncertainty
} TriangularMF;

/**
 * @brief Input structure
 */
typedef struct {
    char name[20];     // Name of the input
    fuzzy_t min;       // Minimum value of range
    fuzzy_t max;       // Maximum value of range
    uint8_t numMFs;    // Number of membership functions
    TriangularMF* mfs; // Array of membership functions
} FuzzyInput;

/**
 * @brief Output structure
 */
typedef struct {
    char name[20];     // Name of the output
    fuzzy_t min;       // Minimum value of range
    fuzzy_t max;       // Maximum value of range
    uint8_t numMFs;    // Number of membership functions
    TriangularMF* mfs; // Array of membership functions
} FuzzyOutput;

/**
 * @brief Rule antecedent and consequent structure
 */
typedef struct {
    uint8_t input1MF;  // Index of input 1 membership function
    uint8_t input2MF;  // Index of input 2 membership function
    uint8_t outputMF;  // Index of output membership function
    fuzzy_t weight;    // Rule weight (typically 1.0)
} FuzzyRule;

/**
 * @brief Type-2 fuzzy system structure
 */
typedef struct {
    FuzzyInput inputs[2];     // Array of inputs
    FuzzyOutput output;       // Output
    FuzzyRule* rules;         // Array of rules
    uint8_t numRules;         // Number of rules

    // Inference methods
    enum {
        AND_MIN,
        AND_PROD
    } andMethod;

    enum {
        OR_MAX,
        OR_PROBOR
    } orMethod;

    enum {
        DEFUZZ_CENTROID,
        DEFUZZ_BISECTOR,
        DEFUZZ_MOM,
        DEFUZZ_SOM,
        DEFUZZ_LOM
    } defuzzMethod;

    enum {
        TR_KARNIKMENDEL,
        TR_ENHANCED_KARNIKMENDEL,
        TR_ITERATIVE
    } typeReductionMethod;
} FuzzySystem;

#endif /* FUZZY_STRUCTURES_H */
