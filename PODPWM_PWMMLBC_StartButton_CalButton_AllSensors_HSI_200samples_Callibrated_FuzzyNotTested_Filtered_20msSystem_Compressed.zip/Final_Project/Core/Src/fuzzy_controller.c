/**
 * @file fuzzy_controller.c
 * @brief Type-2 Fuzzy Logic Controller Implementation - No Scaling Version
 */

#include "main.h"
#include "fuzzy_init.h"
#include "fuzzy_controller.h"

/* Global Fuzzy Controller structure */
FuzzyController_t fuzzy_controller;

/* Global Fuzzy System structure */
FuzzySystem fuzzy_system;

/**
 * @brief Initialize the fuzzy controller system
 */
void Fuzzy_Controller_Init(void) {
    /* Initialize controller structure */
    fuzzy_controller.status = FUZZY_STATUS_STARTUP;
    fuzzy_controller.initialized = 0;
    fuzzy_controller.ready = 0;

    /* Initialize timing */
    fuzzy_controller.start_time = 0;
    fuzzy_controller.last_update_time = HAL_GetTick();

    /* Initialize control parameters */
    fuzzy_controller.target_voltage = FUZZY_TARGET_VOLTAGE;
    fuzzy_controller.current_voltage = 0.0f;
    fuzzy_controller.error = 0.0f;
    fuzzy_controller.previous_error = 0.0f;
    fuzzy_controller.error_derivative = 0.0f;
    fuzzy_controller.filtered_derivative = 0.0f;

    /* Initialize direct fuzzy inputs (no scaling) */
    fuzzy_controller.fuzzy_error = 0.0f;
    fuzzy_controller.fuzzy_derror = 0.0f;
    fuzzy_controller.fuzzy_output_raw = MANUAL_MODULATION_INDEX_DEFAULT;
    fuzzy_controller.fuzzy_output_final = MANUAL_MODULATION_INDEX_DEFAULT;

    /* Initialize statistics */
    fuzzy_controller.update_count = 0;
    fuzzy_controller.safety_fallback_count = 0;
    fuzzy_controller.sensor_error_count = 0;

    /* Initialize debug system */
    fuzzy_controller.debug_enabled = 0;  // Disabled by default

    memset(fuzzy_controller.debug_buffer, 0, sizeof(fuzzy_controller.debug_buffer));

    /* Initialize the Type-2 fuzzy system */
    if(InitializeFuzzySystem(&fuzzy_system) == 0) {
        fuzzy_controller.initialized = 1;
        printf("Fuzzy Controller initialized successfully (NO SCALING)\r\n");
        printf("Target: %.1fV, Input Range: ±%.1fV, Output: %.2f-%.2f MI\r\n",
               FUZZY_TARGET_VOLTAGE, FUZZY_INPUT_RANGE_MAX, FUZZY_MI_MIN, FUZZY_MI_MAX);
        printf("Operating Range: %.1fV to %.1fV\r\n",
               FUZZY_TARGET_VOLTAGE - FUZZY_INPUT_RANGE_MAX,
               FUZZY_TARGET_VOLTAGE + FUZZY_INPUT_RANGE_MAX);
    } else {
        fuzzy_controller.status = FUZZY_STATUS_SENSOR_ERROR;
        printf("ERROR: Fuzzy Controller initialization failed\r\n");
    }
}

/**
 * @brief Main fuzzy controller update function
 */
float Fuzzy_Controller_Update(void) {
    /* Check if controller is properly initialized */
    if(!fuzzy_controller.initialized) {
        fuzzy_controller.status = FUZZY_STATUS_SENSOR_ERROR;
        return MANUAL_MODULATION_INDEX_DEFAULT;
    }

    /* Handle startup delay (non-blocking) */
    if(!Fuzzy_Controller_Is_Ready()) {
        fuzzy_controller.status = FUZZY_STATUS_STARTUP;
        return MANUAL_MODULATION_INDEX_DEFAULT;
    }

    /* Get current voltage measurement */
    fuzzy_controller.current_voltage = AC_Sensor_Get_Voltage_RMS();

    /* Check for sensor errors */
    if(fuzzy_controller.current_voltage <= 0.0f || fuzzy_controller.current_voltage > 400.0f) {
        fuzzy_controller.status = FUZZY_STATUS_SENSOR_ERROR;
        fuzzy_controller.sensor_error_count++;
        return MANUAL_MODULATION_INDEX_DEFAULT;
    }

    /* Calculate error and derivative */
    Fuzzy_Controller_Calculate_Error();

    /* Apply filtering */
    Fuzzy_Controller_Apply_Filtering();

    /* Prepare inputs for fuzzy system (no scaling) */
    Fuzzy_Controller_Prepare_Inputs();

    /* DEADBAND CONTROL: If error is small, maintain current MI */
    if(fabsf(fuzzy_controller.error) < CONTROL_DEADBAND) {
         /* Error is within deadband, no control action needed */
         fuzzy_controller.status = FUZZY_STATUS_NORMAL;

         /* Update statistics but don't change output */
         Fuzzy_Controller_Update_Statistics();
         fuzzy_controller.previous_error = fuzzy_controller.error;
         fuzzy_controller.last_update_time = HAL_GetTick();

         /* Return current MI without change */
         return fuzzy_controller.fuzzy_output_final;
     }

    /* Check input safety bounds */
    if(!Fuzzy_Controller_Check_Input_Safety()) {
        fuzzy_controller.status = FUZZY_STATUS_SAFETY_FALLBACK;
        fuzzy_controller.safety_fallback_count++;
        return MANUAL_MODULATION_INDEX_DEFAULT;
    }

    /* Perform fuzzy inference */
    fuzzy_controller.fuzzy_output_raw = FuzzyInference(&fuzzy_system,
                                                      fuzzy_controller.fuzzy_error,
                                                      fuzzy_controller.fuzzy_derror);

    /* Apply output clamping for safety */
    fuzzy_controller.fuzzy_output_final = Fuzzy_Controller_Apply_Output_Clamping(
                                            fuzzy_controller.fuzzy_output_raw);

    /* Update statistics */
    Fuzzy_Controller_Update_Statistics();

    /* Update error history for next iteration */
    fuzzy_controller.previous_error = fuzzy_controller.error;
    fuzzy_controller.last_update_time = HAL_GetTick();

    /* Controller operating normally */
    fuzzy_controller.status = FUZZY_STATUS_NORMAL;

    return fuzzy_controller.fuzzy_output_final;
}

/**
 * @brief Get current controller status
 */
FuzzyStatus_t Fuzzy_Controller_Get_Status(void) {
    return fuzzy_controller.status;
}

/**
 * @brief Reset the fuzzy controller to initial state
 */
void Fuzzy_Controller_Reset(void) {
    fuzzy_controller.ready = 0;
    fuzzy_controller.start_time = 0;
    fuzzy_controller.error = 0.0f;
    fuzzy_controller.previous_error = 0.0f;
    fuzzy_controller.error_derivative = 0.0f;
    fuzzy_controller.filtered_derivative = 0.0f;
    fuzzy_controller.status = FUZZY_STATUS_STARTUP;

    printf("Fuzzy Controller reset\r\n");
}

/**
 * @brief Set target voltage setpoint
 */
void Fuzzy_Controller_Set_Target_Voltage(float target_voltage) {
    fuzzy_controller.target_voltage = target_voltage;
    printf("Fuzzy target voltage set to: %.1fV\r\n", target_voltage);
}

/**
 * @brief Get current target voltage
 */
float Fuzzy_Controller_Get_Target_Voltage(void) {
    return fuzzy_controller.target_voltage;
}

/**
 * @brief Enable/disable debug output
 */
void Fuzzy_Controller_Set_Debug(uint8_t enable) {
    fuzzy_controller.debug_enabled = enable;
    if(enable) {
        printf("Fuzzy Controller debug enabled\r\n");
    } else {
        printf("Fuzzy Controller debug disabled\r\n");
    }
}

/**
 * @brief Transmit debug data via UART
 */
void Fuzzy_Controller_Debug_Transmit(void) {
    if(fuzzy_controller.debug_enabled) {
        // Check if we're in deadband
        uint8_t in_deadband = (fabsf(fuzzy_controller.error) < CONTROL_DEADBAND) ? 1 : 0;

        snprintf(fuzzy_controller.debug_buffer, sizeof(fuzzy_controller.debug_buffer),
            "FUZZY,%.1f,%.3f,%.3f,%.3f,%.3f,%.3f,%.3f,%d\r\n",
            fuzzy_controller.current_voltage,     // Measured AC voltage RMS
            fuzzy_controller.error,               // Raw voltage error
            fuzzy_controller.error_derivative,    // Raw delta error
            fuzzy_controller.fuzzy_error,         // Direct error input (no scaling)
            fuzzy_controller.fuzzy_derror,        // Direct derivative input (no scaling)
            fuzzy_controller.fuzzy_output_raw,    // Raw fuzzy output
            fuzzy_controller.fuzzy_output_final,  // Final clamped output
			in_deadband);

        HAL_UART_Transmit(&huart2, (uint8_t*)fuzzy_controller.debug_buffer,
                         strlen(fuzzy_controller.debug_buffer), 100);
    }
}

/**
 * @brief Get controller statistics string
 */
void Fuzzy_Controller_Get_Statistics(char* buffer, size_t buffer_size) {
    const char* status_strings[] = {
        "STARTUP", "NORMAL", "SAFETY_FALLBACK", "SENSOR_ERROR"
    };

    snprintf(buffer, buffer_size,
        "FUZZY_CTRL: %s,Target:%.1fV,Current:%.1fV,Error:%.3fV,MI:%.3f,Updates:%lu,Fallbacks:%lu",
        status_strings[fuzzy_controller.status],
        fuzzy_controller.target_voltage,
        fuzzy_controller.current_voltage,
        fuzzy_controller.error,
        fuzzy_controller.fuzzy_output_final,
        fuzzy_controller.update_count,
        fuzzy_controller.safety_fallback_count);
}

/* Internal Processing Functions */

/**
 * @brief Check if controller startup delay has completed
 */
uint8_t Fuzzy_Controller_Is_Ready(void) {
    if(fuzzy_controller.ready) {
        return 1;
    }

    /* Initialize start time on first call */
    if(fuzzy_controller.start_time == 0) {
        fuzzy_controller.start_time = HAL_GetTick();
        return 0;
    }

    /* Check if startup delay has elapsed */
    if((HAL_GetTick() - fuzzy_controller.start_time) >= FUZZY_STARTUP_DELAY_MS) {
        fuzzy_controller.ready = 1;
        printf("Fuzzy Controller startup delay complete - ready for operation\r\n");
        return 1;
    }

    return 0;
}

/**
 * @brief Calculate voltage error and derivative
 */
void Fuzzy_Controller_Calculate_Error(void) {
    /* Calculate voltage error */
    fuzzy_controller.error = fuzzy_controller.target_voltage - fuzzy_controller.current_voltage;

    /* Calculate raw error derivative */
    fuzzy_controller.error_derivative = fuzzy_controller.error - fuzzy_controller.previous_error;
}

/**
 * @brief Apply derivative filtering to reduce noise
 */
void Fuzzy_Controller_Apply_Filtering(void) {
    /* Apply first-order low-pass filter to derivative */
    fuzzy_controller.filtered_derivative = DERIVATIVE_FILTER_ALPHA * fuzzy_controller.filtered_derivative +
                                          (1.0f - DERIVATIVE_FILTER_ALPHA) * fuzzy_controller.error_derivative;
}

/**
 * @brief Prepare inputs for fuzzy system (no scaling, direct mapping)
 */
void Fuzzy_Controller_Prepare_Inputs(void) {
    /* Direct mapping - no scaling applied */
    fuzzy_controller.fuzzy_error = fuzzy_controller.error;
    fuzzy_controller.fuzzy_derror = fuzzy_controller.filtered_derivative;
}

/**
 * @brief Check if inputs are within safe fuzzy range
 */
uint8_t Fuzzy_Controller_Check_Input_Safety(void) {
    /* Check if inputs are within fuzzy system range [-17, +17] */
    if(fabsf(fuzzy_controller.fuzzy_error) > FUZZY_INPUT_RANGE_MAX) {
        return 0;
    }

    if(fabsf(fuzzy_controller.fuzzy_derror) > FUZZY_INPUT_RANGE_MAX) {
        return 0;
    }

    return 1;
}

/**
 * @brief Apply safety clamping to fuzzy output
 */
float Fuzzy_Controller_Apply_Output_Clamping(float raw_output) {
    float clamped_output = raw_output;

    /* Apply minimum limit */
    if(clamped_output < FUZZY_MI_MIN) {
        clamped_output = FUZZY_MI_MIN;
    }

    /* Apply maximum limit */
    if(clamped_output > FUZZY_MI_MAX) {
        clamped_output = FUZZY_MI_MAX;
    }

    return clamped_output;
}

/**
 * @brief Update controller statistics
 */
void Fuzzy_Controller_Update_Statistics(void) {
    fuzzy_controller.update_count++;
}
