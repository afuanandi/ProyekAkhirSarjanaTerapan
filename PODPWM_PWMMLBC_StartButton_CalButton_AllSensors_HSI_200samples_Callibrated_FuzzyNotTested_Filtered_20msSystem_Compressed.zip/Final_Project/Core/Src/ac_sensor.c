/**
 * @file ac_sensor.c
 * @brief AC Voltage and Current Sensor - 20ms Implementation
 * @author afuanandi
 * @date 2025
 *
 * High-performance AC sensor using restart-based DMA approach
 * optimized for 20ms control updates with dual buffer capability
 */

#include "ac_sensor.h"
#include <stdio.h>
#include <string.h>
#include <math.h>

/* Global AC Sensor Instance */
AC_Sensor_t ac_sensor;

/* Internal Function Prototypes */
static HAL_StatusTypeDef AC_Setup_Hardware(void);
static HAL_StatusTypeDef AC_Start_DMA_Collection(void);
static void AC_Configure_For_Mode(AC_Mode_t mode);
static void AC_Extract_Signals(void);
static void AC_Analyze_Raw_Signals(void);
static void AC_Calculate_RMS(void);
static void AC_Process_Normal_Mode(void);
static void AC_Process_Calibration_Mode(void);
static void AC_Transmit_Calibration_Data(void);
static float AC_Apply_Calibration(uint16_t raw, float scale, float offset);

/**
 * @brief Initialize AC sensor system
 */
void AC_Sensor_Init(void) {
    /* Clear structure */
    memset(&ac_sensor, 0, sizeof(AC_Sensor_t));

    /* Set initial state */
    ac_sensor.mode = AC_MODE_NORMAL;
    ac_sensor.status = AC_STATUS_IDLE;
    ac_sensor.initialized = 0;

    /* Initialize calibration parameters */
    ac_sensor.v_scale = AC_VOLTAGE_SCALE_DEFAULT;
    ac_sensor.i_scale = 0.001f;  // Much smaller for current (was 0.004f)
    ac_sensor.v_offset = 0.0f;
    ac_sensor.i_offset = 0.0f;

    /* Initialize debug */
    ac_sensor.debug_enabled = 0;

    printf("AC Sensor 20ms Implementation Initialized\r\n");

    /* Configure for Normal mode initially */
    AC_Configure_For_Mode(AC_MODE_NORMAL);

    printf("Normal: %d samples (%d cycle, 20ms)\r\n",
           AC_NORMAL_TOTAL_SAMPLES, AC_NORMAL_CYCLES);
    printf("Calibration: %d samples (%d cycles, 100ms)\r\n",
           AC_CALIB_TOTAL_SAMPLES, AC_CALIB_CYCLES);
    printf("Sampling: %.1fkHz (TIM3), Restart-based DMA\r\n",
           AC_SAMPLING_FREQ/1000.0f);

    ac_sensor.initialized = 1;
}

/**
 * @brief Start AC sensor acquisition
 */
void AC_Sensor_Start(void) {
    if (!ac_sensor.initialized) {
        printf("ERROR: AC Sensor not initialized!\r\n");
        ac_sensor.status = AC_STATUS_ERROR;
        return;
    }

    /* Setup hardware properly */
    if (AC_Setup_Hardware() != HAL_OK) {
        printf("ERROR: AC Sensor hardware setup failed!\r\n");
        ac_sensor.status = AC_STATUS_ERROR;
        return;
    }

    /* Start DMA collection */
    if (AC_Start_DMA_Collection() != HAL_OK) {
        printf("ERROR: AC Sensor DMA start failed!\r\n");
        ac_sensor.status = AC_STATUS_ERROR;
        return;
    }

    ac_sensor.status = AC_STATUS_COLLECTING;
    ac_sensor.buffer_ready = 0;

    printf("AC Sensor started successfully - Mode: %s, Samples: %d\r\n",
           (ac_sensor.mode == AC_MODE_NORMAL) ? "NORMAL" : "CALIBRATION",
           ac_sensor.active_total_samples);
}

/**
 * @brief Stop AC sensor acquisition
 */
void AC_Sensor_Stop(void) {
    /* Stop ADC and DMA */
    HAL_ADC_Stop_DMA(&hadc1);

    ac_sensor.status = AC_STATUS_IDLE;
    ac_sensor.buffer_ready = 0;

    printf("AC Sensor stopped\r\n");
}

/**
 * @brief Main update function (call every 20ms from main loop)
 */
void AC_Sensor_Update(void) {
    if (!ac_sensor.initialized || !ac_sensor.buffer_ready) {
        /* Debug output for no data condition */
        static uint32_t debug_timer = 0;
        if (ac_sensor.debug_enabled && (HAL_GetTick() - debug_timer) > 2000) {
            printf("AC: Waiting for data - DMA_Count=%lu, Status=%d\r\n",
                   ac_sensor.dma_complete_count, ac_sensor.status);
            debug_timer = HAL_GetTick();
        }
        return;
    }

    /* Process data based on current mode */
    switch (ac_sensor.mode) {
        case AC_MODE_NORMAL:
            AC_Process_Normal_Mode();
            break;

        case AC_MODE_CALIBRATION:
            AC_Process_Calibration_Mode();
            break;

        default:
            ac_sensor.status = AC_STATUS_ERROR;
            ac_sensor.error_count++;
            return;
    }

    /* Clear buffer ready flag */
    ac_sensor.buffer_ready = 0;

    /* Update statistics */
    ac_sensor.measurement_count++;

    /* Restart DMA for next collection cycle */
    if (AC_Start_DMA_Collection() != HAL_OK) {
        printf("ERROR: AC Sensor DMA restart failed!\r\n");
        ac_sensor.status = AC_STATUS_ERROR;
        ac_sensor.error_count++;
        return;
    }

    ac_sensor.status = AC_STATUS_COLLECTING;
}

/**
 * @brief Set operation mode with automatic buffer reconfiguration
 */
void AC_Sensor_Set_Mode(AC_Mode_t mode) {
    if (ac_sensor.mode != mode) {
        printf("AC Sensor mode change: %s -> %s\r\n",
               (ac_sensor.mode == AC_MODE_NORMAL) ? "NORMAL" : "CALIBRATION",
               (mode == AC_MODE_NORMAL) ? "NORMAL" : "CALIBRATION");

        /* Stop current operation */
        HAL_ADC_Stop_DMA(&hadc1);

        /* Configure for new mode */
        ac_sensor.mode = mode;
        AC_Configure_For_Mode(mode);

        /* Reset mode-specific flags */
        if (mode == AC_MODE_CALIBRATION) {
            ac_sensor.calib_data_sent = 0;
            printf("=== CALIBRATION MODE ACTIVATED ===\r\n");
        } else {
            printf("=== NORMAL MODE ACTIVATED ===\r\n");
        }

        /* Clear flags and restart */
        ac_sensor.buffer_ready = 0;
        ac_sensor.mode_switch_pending = 0;

        /* Start with new configuration */
        if (AC_Start_DMA_Collection() != HAL_OK) {
            printf("ERROR: DMA restart after mode change failed!\r\n");
            ac_sensor.status = AC_STATUS_ERROR;
        } else {
            ac_sensor.status = AC_STATUS_COLLECTING;
        }
    }
}

/* Data Access Functions */

float AC_Sensor_Get_Voltage_RMS(void) {
    return ac_sensor.voltage_rms;
}

float AC_Sensor_Get_Current_RMS(void) {
    return ac_sensor.current_rms;
}

AC_Mode_t AC_Sensor_Get_Mode(void) {
    return ac_sensor.mode;
}

AC_Status_t AC_Sensor_Get_Status(void) {
    return ac_sensor.status;
}

uint8_t AC_Sensor_Is_Ready(void) {
    return ac_sensor.buffer_ready;
}

/* Configuration Functions */

void AC_Sensor_Set_Voltage_Calibration(float scale, float offset) {
    ac_sensor.v_scale = scale;
    ac_sensor.v_offset = offset;
    printf("AC Voltage calibration: Scale=%.6f, Offset=%.3f\r\n", scale, offset);
}

void AC_Sensor_Set_Current_Calibration(float scale, float offset) {
    ac_sensor.i_scale = scale;
    ac_sensor.i_offset = offset;
    printf("AC Current calibration: Scale=%.6f, Offset=%.3f\r\n", scale, offset);
}

void AC_Sensor_Set_Debug(uint8_t enable) {
    ac_sensor.debug_enabled = enable;
    printf("AC Sensor debug %s\r\n", enable ? "enabled" : "disabled");
    printf("====================\r\n");
}

/**
 * @brief DMA transfer complete callback
 */
void AC_Sensor_DMA_Complete_Callback(void) {
    ac_sensor.buffer_ready = 1;
    ac_sensor.status = AC_STATUS_READY;
    ac_sensor.dma_complete_count++;

    if (ac_sensor.debug_enabled) {
        printf("AC DMA Complete #%lu (%s mode)\r\n",
               ac_sensor.dma_complete_count,
               (ac_sensor.mode == AC_MODE_NORMAL) ? "NORMAL" : "CALIB");
    }
}

void AC_Sensor_Get_Statistics(char* buffer, size_t size) {
    snprintf(buffer, size,
        "AC: %s,V:%.1fV,I:%.2fA,Meas:%lu,DMA:%lu,Err:%lu",
        (ac_sensor.mode == AC_MODE_NORMAL) ? "NORMAL" : "CALIB",
        ac_sensor.voltage_rms, ac_sensor.current_rms,
        ac_sensor.measurement_count, ac_sensor.dma_complete_count,
        ac_sensor.error_count);
}

/* Internal Functions */

/**
 * @brief Setup ADC and related hardware
 */
static HAL_StatusTypeDef AC_Setup_Hardware(void) {
    /* TIM3 should already be running from POD PWM system */
    /* Try to start base timer, but don't fail if it's already running */
    HAL_StatusTypeDef tim_result = HAL_TIM_Base_Start(&htim3);
    if (tim_result == HAL_OK) {
        printf("TIM3 base timer started for ADC triggering\r\n");
    } else {
        printf("TIM3 base timer already running (shared with POD PWM) - OK\r\n");
    }

    /* Always return OK since TIM3 is working regardless of start result */
    return HAL_OK;
}

/**
 * @brief Start DMA collection based on current mode
 */
static HAL_StatusTypeDef AC_Start_DMA_Collection(void) {
    /* Start ADC with DMA - restart-based approach */
    HAL_StatusTypeDef result = HAL_ADC_Start_DMA(&hadc1,
                                                (uint32_t*)ac_sensor.dma_buffer,
                                                ac_sensor.active_total_samples);

    if (result == HAL_OK) {
        if (ac_sensor.debug_enabled) {
            printf("DMA started: %d samples, Mode: %s\r\n",
                   ac_sensor.active_total_samples,
                   (ac_sensor.mode == AC_MODE_NORMAL) ? "NORMAL" : "CALIB");
        }
    }

    return result;
}

/**
 * @brief Configure buffer parameters for specified mode
 */
static void AC_Configure_For_Mode(AC_Mode_t mode) {
    if (mode == AC_MODE_NORMAL) {
        /* Normal Mode: 1 cycle (20ms) */
        ac_sensor.active_total_samples = AC_NORMAL_TOTAL_SAMPLES;
        ac_sensor.active_signal_samples = AC_NORMAL_SIGNAL_SAMPLES;
        ac_sensor.active_cycles = AC_NORMAL_CYCLES;
    } else {
        /* Calibration Mode: 5 cycles (100ms) */
        ac_sensor.active_total_samples = AC_CALIB_TOTAL_SAMPLES;
        ac_sensor.active_signal_samples = AC_CALIB_SIGNAL_SAMPLES;
        ac_sensor.active_cycles = AC_CALIB_CYCLES;
    }

    printf("AC configured for %s: %d samples (%d cycles)\r\n",
           (mode == AC_MODE_NORMAL) ? "NORMAL" : "CALIBRATION",
           ac_sensor.active_total_samples, ac_sensor.active_cycles);
}

/**
 * @brief Extract voltage and current signals from interleaved DMA buffer
 */
static void AC_Extract_Signals(void) {
    /* Extract voltage samples (even indices: 0, 2, 4, ...) */
    for (uint32_t i = 0; i < ac_sensor.active_signal_samples; i++) {
        ac_sensor.voltage_raw[i] = ac_sensor.dma_buffer[i * 2];
    }

    /* Extract current samples (odd indices: 1, 3, 5, ...) */
    for (uint32_t i = 0; i < ac_sensor.active_signal_samples; i++) {
        ac_sensor.current_raw[i] = ac_sensor.dma_buffer[i * 2 + 1];
    }
}

/**
 * @brief Analyze raw signal characteristics
 */
static void AC_Analyze_Raw_Signals(void) {
    /* Initialize extremes */
    ac_sensor.v_peak = 0;
    ac_sensor.v_trough = 4095;
    ac_sensor.i_peak = 0;
    ac_sensor.i_trough = 4095;

    /* Find voltage extremes */
    for (uint32_t i = 0; i < ac_sensor.active_signal_samples; i++) {
        if (ac_sensor.voltage_raw[i] > ac_sensor.v_peak) {
            ac_sensor.v_peak = ac_sensor.voltage_raw[i];
        }
        if (ac_sensor.voltage_raw[i] < ac_sensor.v_trough) {
            ac_sensor.v_trough = ac_sensor.voltage_raw[i];
        }
    }

    /* Find current extremes */
    for (uint32_t i = 0; i < ac_sensor.active_signal_samples; i++) {
        if (ac_sensor.current_raw[i] > ac_sensor.i_peak) {
            ac_sensor.i_peak = ac_sensor.current_raw[i];
        }
        if (ac_sensor.current_raw[i] < ac_sensor.i_trough) {
            ac_sensor.i_trough = ac_sensor.current_raw[i];
        }
    }

    /* Calculate DC midpoints (zero crossing references) */
    ac_sensor.v_midpoint = (float)(ac_sensor.v_peak + ac_sensor.v_trough) / 2.0f;
    ac_sensor.i_midpoint = (float)(ac_sensor.i_peak + ac_sensor.i_trough) / 2.0f;
}

/**
 * @brief Calculate RMS values from extracted signals
 */
static void AC_Calculate_RMS(void) {
    float v_sum_sq = 0.0f;
    float i_sum_sq = 0.0f;

    /* Calculate voltage RMS (AC component only) */
    for (uint32_t i = 0; i < ac_sensor.active_signal_samples; i++) {
        float v_ac = (float)ac_sensor.voltage_raw[i] - ac_sensor.v_midpoint;
        v_sum_sq += v_ac * v_ac;
    }
    ac_sensor.v_rms_raw = sqrtf(v_sum_sq / (float)ac_sensor.active_signal_samples);

    /* Calculate current RMS (AC component only) */
    for (uint32_t i = 0; i < ac_sensor.active_signal_samples; i++) {
        float i_ac = (float)ac_sensor.current_raw[i] - ac_sensor.i_midpoint;
        i_sum_sq += i_ac * i_ac;
    }
    ac_sensor.i_rms_raw = sqrtf(i_sum_sq / (float)ac_sensor.active_signal_samples);

    /* Apply calibration to get real units */
    ac_sensor.voltage_rms = AC_Apply_Calibration((uint16_t)ac_sensor.v_rms_raw,
                                                 ac_sensor.v_scale, ac_sensor.v_offset);
    ac_sensor.current_rms = AC_Apply_Calibration((uint16_t)ac_sensor.i_rms_raw,
                                                 ac_sensor.i_scale, ac_sensor.i_offset);

    /* Ensure non-negative values */
    if (ac_sensor.voltage_rms < 0.0f) ac_sensor.voltage_rms = 0.0f;
    if (ac_sensor.current_rms < 0.0f) ac_sensor.current_rms = 0.0f;
}

/**
 * @brief Process data in normal mode (20ms RMS calculation)
 */
static void AC_Process_Normal_Mode(void) {
    /* Extract signals from interleaved buffer */
    AC_Extract_Signals();

    /* Analyze signal characteristics */
    AC_Analyze_Raw_Signals();

    /* Calculate RMS values */
    AC_Calculate_RMS();

    /* Debug output if enabled */
    if (ac_sensor.debug_enabled) {
        printf("AC: V=%.1fV, I=%.2fA, VRaw=%.1f, IRaw=%.2f, Cycles=%d\r\n",
               ac_sensor.voltage_rms, ac_sensor.current_rms,
               ac_sensor.v_rms_raw, ac_sensor.i_rms_raw,
               ac_sensor.active_cycles);
    }
}

/**
 * @brief Process data in calibration mode (100ms data transmission)
 */
static void AC_Process_Calibration_Mode(void) {
    /* Only transmit calibration data once per activation */
    if (!ac_sensor.calib_data_sent) {
        AC_Transmit_Calibration_Data();
        ac_sensor.calib_data_sent = 1;
        printf("Calibration data transmission complete\r\n");
    }
}

/**
 * @brief Transmit calibration data via UART
 */
static void AC_Transmit_Calibration_Data(void) {
    uint32_t sample_pairs = ac_sensor.active_total_samples / 2;

    printf("=== AC CALIBRATION DATA START ===\r\n");
    printf("Config: %d samples/cycle, %d cycles, %dms total\r\n",
           AC_SAMPLES_PER_CYCLE, ac_sensor.active_cycles,
           ac_sensor.active_cycles * 20);
    printf("Sample_Index,Voltage_ADC,Current_ADC\r\n");

    /* Transmit all sample pairs */
    for (uint32_t i = 0; i < sample_pairs; i++) {
        printf("%lu,%d,%d\r\n", i,
               ac_sensor.dma_buffer[i * 2],       // Voltage (even index)
               ac_sensor.dma_buffer[i * 2 + 1]);  // Current (odd index)

        /* Small delay every 100 samples to prevent UART overflow */
        if (i % 100 == 99) {
            HAL_Delay(1);
        }
    }

    printf("=== AC CALIBRATION DATA END ===\r\n");
    printf("Total: %lu sample pairs transmitted\r\n", sample_pairs);
}

/**
 * @brief Apply calibration to convert ADC counts to real units
 */
static float AC_Apply_Calibration(uint16_t raw, float scale, float offset) {
    return ((float)raw * scale) + offset;
}
