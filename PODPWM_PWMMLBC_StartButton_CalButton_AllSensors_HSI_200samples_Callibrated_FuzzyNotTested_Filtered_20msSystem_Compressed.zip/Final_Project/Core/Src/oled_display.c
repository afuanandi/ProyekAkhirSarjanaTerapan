/**
 * @file oled_display.c
 * @brief OLED display management implementation with non-blocking updates
 * @author afuanandi
 * @date 2025
 */

#include "main.h"
#include "oled_display.h"
#include "ac_sensor.h"
#include <stdio.h>
#include <string.h>

/* Global variables */
volatile uint8_t force_display_update = 0;

/**
 * @brief Initialize the OLED display system
 */
void OLED_Display_Init(void) {
    /* Initialize the non-blocking SH1106 driver */
    SH1106_Init();

    /* Draw the basic layout */
    OLED_Display_DrawLayout();

    printf("OLED Display initialized with non-blocking updates\r\n");
}

/**
 * @brief Non-blocking update function - call from main loop frequently
 */
void OLED_Display_Update_NonBlocking(void) {
    /* Process the chunked I2C transmission */
    SH1106_Update();
}

/**
 * @brief Draw the basic layout
 */
void OLED_Display_DrawLayout(void) {
    /* Clear the display buffer */
    SH1106_Clear();

    /* Draw titles - better centered for each half */
    SH1106_DrawString(10, OLED_TITLE_ROW, "DC INPUT");
    SH1106_DrawString(71, OLED_TITLE_ROW, "AC OUTPUT");

    /* Draw separator lines */
    /* Horizontal line under titles */
    for (uint8_t x = 0; x < OLED_WIDTH; x++) {
        SH1106_DrawPixel(x, OLED_SEPARATOR_ROW, true);
    }

    /* Vertical center line - stop at power row + 8 pixels */
    for (uint8_t y = OLED_SEPARATOR_ROW; y < OLED_POWER_ROW + 8; y++) {
        SH1106_DrawPixel(OLED_CENTER_LINE, y, true);
    }

    /* Request display update to show the layout */
    SH1106_Request_Update();
}

/**
 * @brief Update the display values
 */
void OLED_Display_Update(DisplayData_t* data) {
    char buffer[32];

    /* Clear dynamic areas (preserve static layout) */
    SH1106_ClearRect(0, OLED_VOLTAGE_ROW, OLED_CENTER_LINE-1, OLED_POWER_ROW+8-OLED_VOLTAGE_ROW);
    SH1106_ClearRect(OLED_CENTER_LINE+1, OLED_VOLTAGE_ROW, OLED_CENTER_LINE-1, OLED_POWER_ROW+8-OLED_VOLTAGE_ROW);
    SH1106_ClearRect(0, OLED_MI_ROW, OLED_WIDTH, OLED_HEIGHT-OLED_MI_ROW);

    /* DC Section - Left side (shifted right by 6 pixels) */
    /* DC Voltage */
    sprintf(buffer, "%5.1f V", data->dc_voltage);
    SH1106_DrawString(8, OLED_VOLTAGE_ROW, buffer);

    /* DC Current */
    sprintf(buffer, "%5.1f A", data->dc_current);
    SH1106_DrawString(8, OLED_CURRENT_ROW, buffer);

    /* DC Power */
    sprintf(buffer, "%5.1f W", data->dc_power);
    SH1106_DrawString(8, OLED_POWER_ROW, buffer);

    /* AC Section - Right side (shifted right by 4 pixels, all with 2 decimals) */
    /* AC Voltage */
    sprintf(buffer, "%6.2f V", data->ac_voltage);
    SH1106_DrawString(OLED_CENTER_LINE+10, OLED_VOLTAGE_ROW, buffer);

    /* AC Current */
    sprintf(buffer, "%6.2f A", data->ac_current);
    SH1106_DrawString(OLED_CENTER_LINE+10, OLED_CURRENT_ROW, buffer);

    /* AC Power - now with 2 decimals to match others */
    sprintf(buffer, "%6.2f W", data->ac_power);
    SH1106_DrawString(OLED_CENTER_LINE+10, OLED_POWER_ROW, buffer);

    /* Modulation Index - Centered across both columns with 4 decimal places */
    sprintf(buffer, "MI: %.4f", data->modulation_index);
    uint8_t mi_x = (OLED_WIDTH - strlen(buffer) * 6) / 2;  // Center the text
    SH1106_DrawString(mi_x, OLED_MI_ROW, buffer);

    /* Status - Bottom left */
    sprintf(buffer, "%s", data->converter_status ? "ON" : "OFF");
    SH1106_DrawString(2, OLED_STATUS_ROW, buffer);

    /* Mode - Bottom right */
    sprintf(buffer, "%s", data->control_mode ? "Closeloop" : "Openloop");
    uint8_t mode_x = OLED_WIDTH - (strlen(buffer) * 6) - 2;  // Right align with 2px margin
    SH1106_DrawString(mode_x, OLED_STATUS_ROW, buffer);

    /* Request non-blocking update instead of immediate blocking update */
    SH1106_Request_Update();
}

/**
 * @brief Update display with data from system sensors and controllers
 */
void OLED_Display_UpdateFromSystem(float dc_voltage, float dc_current,
                                  float ac_voltage, float ac_current,
                                  float modulation_index, uint8_t converter_status,
                                  uint8_t control_mode, uint8_t sensor_mode) {
    DisplayData_t display_data;

    /* Populate display data structure */
    display_data.dc_voltage = dc_voltage;
    display_data.dc_current = dc_current;
    display_data.dc_power = dc_voltage * dc_current;

    display_data.ac_voltage = ac_voltage;
    display_data.ac_current = ac_current;
    display_data.ac_power = ac_voltage * ac_current;

    display_data.modulation_index = modulation_index;
    display_data.converter_status = converter_status;
    display_data.control_mode = control_mode;

    /* Update standard display data */
    OLED_Display_Update(&display_data);

    /* Add calibration mode indicator if needed */
    if (sensor_mode == SENSOR_MODE_CALIBRATION) {
        /* Calculate position for centered "CAL" indicator */
        uint8_t cal_x = OLED_WIDTH/2 - 9; // "CAL" is about 18 pixels wide (3 chars * 6 pixels)

        /* Draw at bottom row */
        SH1106_DrawString(cal_x, OLED_STATUS_ROW, "CAL");

        /* Request another update for the calibration indicator */
        SH1106_Request_Update();
    }
}

/**
 * @brief Check if display is currently updating
 */
uint8_t OLED_Display_Is_Updating(void) {
    return SH1106_Is_Updating();
}

/**
 * @brief Force immediate display update
 */
void OLED_Display_Force_Update(void) {
    SH1106_Force_Update();
}

/**
 * @brief Get display statistics for debugging
 */
void OLED_Display_Get_Statistics(char* buffer, size_t buffer_size) {
    /* Get statistics from the underlying SH1106 driver */
    SH1106_Get_Statistics(buffer, buffer_size);
}
