/**
 * @file ac_sensor.c
 * @brief AC Voltage and Current Sensor Module Implementation
 */

#include "ac_sensor.h"
#include <stdio.h>
#include <string.h>
#include <math.h>

/* Global AC Sensor structure */
AC_Sensor_TypeDef ac_sensor;

/**
 * @brief Initialize AC sensor system
 */
void AC_Sensor_Init(void) {
    /* Initialize structure */
    ac_sensor.mode = AC_SENSOR_MODE_NORMAL;
    ac_sensor.status = AC_SENSOR_STATUS_COLLECTING;
    ac_sensor.buffer_ready = 0;
    ac_sensor.sample_count = 0;

    /* Initialize processed data */
    ac_sensor.voltage_rms = 0.0f;
    ac_sensor.current_rms = 0.0f;
    ac_sensor.voltage_peak = 0.0f;
    ac_sensor.current_peak = 0.0f;

    /* Initialize raw signal analysis */
    ac_sensor.voltage_adc_peak = 0;
    ac_sensor.voltage_adc_trough = 4095;
    ac_sensor.voltage_adc_midpoint = 2048.0f;
    ac_sensor.voltage_adc_raw_rms = 0.0f;
    ac_sensor.current_adc_peak = 0;
    ac_sensor.current_adc_trough = 4095;
    ac_sensor.current_adc_midpoint = 2048.0f;
    ac_sensor.current_adc_raw_rms = 0.0f;

    /* Initialize calibration parameters (default values) */
    /* These should be calibrated based on your AMC1100 conditioning circuit */
    ac_sensor.voltage_scale_factor = AC_VOLTAGE_NOMINAL_RMS / (AC_ADC_RESOLUTION * 0.5f);  // Rough estimate
    ac_sensor.current_scale_factor = AC_CURRENT_NOMINAL_RMS / (AC_ADC_RESOLUTION * 0.5f);  // Rough estimate
    ac_sensor.voltage_offset = AC_ADC_RESOLUTION / 2.0f;  // Assume centered at 1.65V
    ac_sensor.current_offset = AC_ADC_RESOLUTION / 2.0f;  // Assume centered at 1.65V

    /* Initialize statistics */
    ac_sensor.measurement_count = 0;
    ac_sensor.last_update_tick = HAL_GetTick();
    ac_sensor.fault_flag = 0;

    /* Initialize one-time calibration mode */
    ac_sensor.previous_mode = AC_SENSOR_MODE_NORMAL;
    ac_sensor.calibration_data_sent = 0;
    ac_sensor.waiting_for_buffer = 0;

    /* Initialize debug */
    ac_sensor.debug_flag = 1;

    /* Clear buffers */
    memset(ac_sensor.adc_buffer, 0, sizeof(ac_sensor.adc_buffer));
    memset(ac_sensor.voltage_samples, 0, sizeof(ac_sensor.voltage_samples));
    memset(ac_sensor.current_samples, 0, sizeof(ac_sensor.current_samples));

    printf("AC Sensor initialized\r\n");
    printf("Configuration: %d samples per cycle, %d cycles per measurement\r\n",
           AC_SAMPLES_PER_CYCLE, AC_CYCLES_PER_MEASUREMENT);
    printf("Total buffer size: %d samples (%dV + %dI)\r\n",
           AC_TOTAL_SAMPLES, AC_VOLTAGE_SAMPLES, AC_CURRENT_SAMPLES);
    printf("Sampling rate: %.1f kHz (TIM3 shared with POD PWM)\r\n", AC_SAMPLING_FREQ / 1000.0f);
}

/**
 * @brief Start AC sensor data acquisition
 */
void AC_Sensor_Start(void) {
    /* TIM3 is already started by POD PWM system - no need to start it again */

    /* Start ADC with DMA in circular mode */
    HAL_ADC_Start_DMA(&hadc1, (uint32_t*)ac_sensor.adc_buffer, AC_TOTAL_SAMPLES);

    ac_sensor.status = AC_SENSOR_STATUS_COLLECTING;
    ac_sensor.sample_count = 0;
    ac_sensor.buffer_ready = 0;

    printf("AC Sensor started - DMA acquisition active (triggered by TIM3 at %.1fkHz)\r\n",
           AC_SAMPLING_FREQ / 1000.0f);
}

/**
 * @brief Stop AC sensor data acquisition
 */
void AC_Sensor_Stop(void) {
    /* Stop ADC and DMA */
    HAL_ADC_Stop_DMA(&hadc1);

    /* Don't stop TIM3 - it's needed for POD PWM system */

    ac_sensor.status = AC_SENSOR_STATUS_COLLECTING;
    ac_sensor.buffer_ready = 0;

    printf("AC Sensor stopped\r\n");
}

/**
 * @brief Main update function (call from main loop every 100ms)
 */
void AC_Sensor_Update(void) {
    /* Focused debug every 2 seconds */
    static uint32_t last_debug = 0;
    uint32_t current_tick = HAL_GetTick();

    /* Check if new data is available */
    if(!ac_sensor.buffer_ready) {
        return;  // Still collecting data
    }

    /* Process data based on current mode */
    ac_sensor.status = AC_SENSOR_STATUS_PROCESSING;

    switch(ac_sensor.mode) {
        case AC_SENSOR_MODE_NORMAL:
            AC_Sensor_Process_Normal_Mode();
            break;

        case AC_SENSOR_MODE_CALIBRATION:
            AC_Sensor_Process_Calibration_Mode();
            break;
    }

    /* Update statistics */
    ac_sensor.measurement_count++;
    ac_sensor.last_update_tick = HAL_GetTick();

    /* Clear buffer ready flag for next collection cycle */
    ac_sensor.buffer_ready = 0;
    ac_sensor.status = AC_SENSOR_STATUS_COLLECTING;

    /* Restart DMA for next 100ms collection cycle */
    HAL_ADC_Start_DMA(&hadc1, (uint32_t*)ac_sensor.adc_buffer, AC_TOTAL_SAMPLES);

    /* Clean AC voltage and current debug output every 2 seconds */
    if((current_tick - last_debug) >= 2000 && ac_sensor.mode == AC_SENSOR_MODE_NORMAL && ac_sensor.debug_flag) {
        /* AC Voltage debug */
        printf("AC_V: Peak=%d, Low=%d, Mid=%.1f, RMS_Raw=%.1f, V_Cal=%.1fV\r\n",
               ac_sensor.voltage_adc_peak,
               ac_sensor.voltage_adc_trough,
               ac_sensor.voltage_adc_midpoint,
               ac_sensor.voltage_adc_raw_rms,
               ac_sensor.voltage_rms);

        /* AC Current debug */
        printf("AC_I: Peak=%d, Low=%d, Mid=%.1f, RMS_Raw=%.1f, I_Cal=%.2fA\r\n",
               ac_sensor.current_adc_peak,
               ac_sensor.current_adc_trough,
               ac_sensor.current_adc_midpoint,
               ac_sensor.current_adc_raw_rms,
               ac_sensor.current_rms);

        last_debug = current_tick;
    }
}

/**
 * @brief Set operation mode with automatic one-time calibration data transmission
 */
void AC_Sensor_Set_Mode(AC_Sensor_Mode_t mode) {
    if(ac_sensor.mode != mode) {
        ac_sensor.previous_mode = ac_sensor.mode;
        ac_sensor.mode = mode;

        if(mode == AC_SENSOR_MODE_CALIBRATION) {
            /* Just switched TO calibration mode */
            ac_sensor.calibration_data_sent = 0;      // Reset flag
            ac_sensor.waiting_for_buffer = 1;         // Wait for next complete buffer
            printf("=== CALIBRATION MODE ACTIVATED ===\r\n");
            printf("Waiting for complete buffer (%d samples over %dms)...\r\n",
                   AC_TOTAL_SAMPLES, AC_CYCLES_PER_MEASUREMENT * 20);
        } else {
            /* Switched AWAY from calibration mode */
            ac_sensor.calibration_data_sent = 0;      // Reset for next time
            ac_sensor.waiting_for_buffer = 0;
            printf("=== NORMAL MODE ACTIVATED ===\r\n");
        }

        printf("AC Sensor mode changed: %s → %s\r\n",
               (ac_sensor.previous_mode == AC_SENSOR_MODE_NORMAL) ? "NORMAL" : "CALIBRATION",
               (mode == AC_SENSOR_MODE_NORMAL) ? "NORMAL" : "CALIBRATION");
    }
}

/**
 * @brief Get current operation mode
 */
AC_Sensor_Mode_t AC_Sensor_Get_Mode(void) {
    return ac_sensor.mode;
}

/**
 * @brief Get voltage RMS value (Normal mode only)
 */
float AC_Sensor_Get_Voltage_RMS(void) {
    return ac_sensor.voltage_rms;
}

/**
 * @brief Get current RMS value (Normal mode only)
 */
float AC_Sensor_Get_Current_RMS(void) {
    return ac_sensor.current_rms;
}

/**
 * @brief Get voltage peak value
 */
float AC_Sensor_Get_Voltage_Peak(void) {
    return ac_sensor.voltage_peak;
}

/**
 * @brief Get current peak value
 */
float AC_Sensor_Get_Current_Peak(void) {
    return ac_sensor.current_peak;
}

/**
 * @brief Set voltage calibration parameters
 */
void AC_Sensor_Set_Voltage_Calibration(float scale_factor, float offset) {
    ac_sensor.voltage_scale_factor = scale_factor;
    ac_sensor.voltage_offset = offset;

    printf("Voltage calibration updated: Scale=%.6f, Offset=%.1f\r\n",
           scale_factor, offset);
}

/**
 * @brief Set current calibration parameters
 */
void AC_Sensor_Set_Current_Calibration(float scale_factor, float offset) {
    ac_sensor.current_scale_factor = scale_factor;
    ac_sensor.current_offset = offset;

    printf("Current calibration updated: Scale=%.6f, Offset=%.1f\r\n",
           scale_factor, offset);
}

/**
 * @brief Check if new data is available
 */
uint8_t AC_Sensor_Is_Data_Ready(void) {
    return ac_sensor.buffer_ready;
}

/**
 * @brief Get sensor status
 */
AC_Sensor_Status_t AC_Sensor_Get_Status(void) {
    return ac_sensor.status;
}

/**
 * @brief Set debug flag
 */
void AC_Sensor_Set_Debug(uint8_t flag) {
    ac_sensor.debug_flag = flag;
    if(flag) {
        printf("AC Sensor debug enabled\r\n");
    } else {
        printf("AC Sensor debug disabled\r\n");
    }
}

/**
 * @brief Check if calibration data has been transmitted
 */
uint8_t AC_Sensor_Is_Calibration_Data_Sent(void) {
    return ac_sensor.calibration_data_sent;
}

/**
 * @brief Reset calibration transmission flags (for testing)
 */
void AC_Sensor_Reset_Calibration_Flags(void) {
    ac_sensor.calibration_data_sent = 0;
    ac_sensor.waiting_for_buffer = 0;
    printf("AC Sensor calibration flags reset\r\n");
}

/**
 * @brief Extract voltage and current samples from interleaved DMA buffer
 */
void AC_Sensor_Extract_Samples(void) {
    /* Extract voltage samples (even indices: 0, 2, 4, ...) */
    for(uint32_t i = 0; i < AC_VOLTAGE_SAMPLES; i++) {
        ac_sensor.voltage_samples[i] = ac_sensor.adc_buffer[i * 2];
    }

    /* Extract current samples (odd indices: 1, 3, 5, ...) */
    for(uint32_t i = 0; i < AC_CURRENT_SAMPLES; i++) {
        ac_sensor.current_samples[i] = ac_sensor.adc_buffer[i * 2 + 1];
    }
}

/**
 * @brief Calculate RMS values from extracted samples
 */
void AC_Sensor_Calculate_RMS(void) {
    /* First analyze raw signal characteristics */
    AC_Sensor_Analyze_Raw_Signal();

    /* Calculate raw ADC RMS */
    ac_sensor.voltage_adc_raw_rms = AC_Sensor_Calculate_Voltage_Raw_RMS();

    /* Now calculate calibrated RMS using existing method */
    float voltage_sum_squares = 0.0f;
    float current_sum_squares = 0.0f;
    float voltage_max = 0.0f;
    float current_max = 0.0f;

    /* Use calculated midpoint as DC offset for calibration */
    float voltage_dc_offset = ac_sensor.voltage_adc_midpoint;
    float current_dc_offset = ac_sensor.current_adc_midpoint;

    /* Calculate calibrated RMS with DC offset removal */
    for(uint32_t i = 0; i < AC_VOLTAGE_SAMPLES; i++) {
        /* Remove DC offset and apply calibration */
        float voltage_ac = AC_Sensor_Apply_Calibration(ac_sensor.voltage_samples[i],
                                                       ac_sensor.voltage_scale_factor,
                                                       voltage_dc_offset);
        float current_ac = AC_Sensor_Apply_Calibration(ac_sensor.current_samples[i],
                                                       ac_sensor.current_scale_factor,
                                                       current_dc_offset);

        /* Accumulate squares for RMS */
        voltage_sum_squares += voltage_ac * voltage_ac;
        current_sum_squares += current_ac * current_ac;

        /* Track peak values (calibrated) */
        float voltage_abs = fabsf(voltage_ac);
        float current_abs = fabsf(current_ac);
        if(voltage_abs > voltage_max) voltage_max = voltage_abs;
        if(current_abs > current_max) current_max = current_abs;
    }

    /* Calculate calibrated RMS values */
    ac_sensor.voltage_rms = sqrtf(voltage_sum_squares / (float)AC_VOLTAGE_SAMPLES);
    ac_sensor.current_rms = sqrtf(current_sum_squares / (float)AC_CURRENT_SAMPLES);

    /* Store calibrated peak values */
    ac_sensor.voltage_peak = voltage_max;
    ac_sensor.current_peak = current_max;
}

/**
 * @brief Analyze raw signal characteristics (peak, trough, midpoint, raw RMS)
 */
void AC_Sensor_Analyze_Raw_Signal(void) {
    /* Reset min/max for this buffer */
    ac_sensor.voltage_adc_peak = 0;
    ac_sensor.voltage_adc_trough = 4095;
    ac_sensor.current_adc_peak = 0;
    ac_sensor.current_adc_trough = 4095;

    /* Find peak and trough values */
    for(uint32_t i = 0; i < AC_VOLTAGE_SAMPLES; i++) {
        /* Voltage analysis */
        if(ac_sensor.voltage_samples[i] > ac_sensor.voltage_adc_peak) {
            ac_sensor.voltage_adc_peak = ac_sensor.voltage_samples[i];
        }
        if(ac_sensor.voltage_samples[i] < ac_sensor.voltage_adc_trough) {
            ac_sensor.voltage_adc_trough = ac_sensor.voltage_samples[i];
        }

        /* Current analysis */
        if(ac_sensor.current_samples[i] > ac_sensor.current_adc_peak) {
            ac_sensor.current_adc_peak = ac_sensor.current_samples[i];
        }
        if(ac_sensor.current_samples[i] < ac_sensor.current_adc_trough) {
            ac_sensor.current_adc_trough = ac_sensor.current_samples[i];
        }
    }

    /* Calculate midpoints (zero crossing points) */
    ac_sensor.voltage_adc_midpoint = (float)(ac_sensor.voltage_adc_peak + ac_sensor.voltage_adc_trough) / 2.0f;
    ac_sensor.current_adc_midpoint = (float)(ac_sensor.current_adc_peak + ac_sensor.current_adc_trough) / 2.0f;
}

/**
 * @brief Calculate raw ADC RMS for voltage signal
 */
float AC_Sensor_Calculate_Voltage_Raw_RMS(void) {
    float sum_squares = 0.0f;

    /* Calculate RMS using raw ADC values with midpoint as reference */
    for(uint32_t i = 0; i < AC_VOLTAGE_SAMPLES; i++) {
        float ac_component = (float)ac_sensor.voltage_samples[i] - ac_sensor.voltage_adc_midpoint;
        sum_squares += ac_component * ac_component;
    }

    return sqrtf(sum_squares / (float)AC_VOLTAGE_SAMPLES);
}

/**
 * @brief Calculate raw ADC RMS for current signal
 */
float AC_Sensor_Calculate_Current_Raw_RMS(void) {
    float sum_squares = 0.0f;

    /* Calculate RMS using raw ADC values with midpoint as reference */
    for(uint32_t i = 0; i < AC_CURRENT_SAMPLES; i++) {
        float ac_component = (float)ac_sensor.current_samples[i] - ac_sensor.current_adc_midpoint;
        sum_squares += ac_component * ac_component;
    }

    return sqrtf(sum_squares / (float)AC_CURRENT_SAMPLES);
}

/**
 * @brief Process data in normal mode (RMS calculation)
 */
void AC_Sensor_Process_Normal_Mode(void) {
    /* Extract samples from interleaved buffer */
    AC_Sensor_Extract_Samples();

    /* Calculate RMS values */
    AC_Sensor_Calculate_RMS();
}

/**
 * @brief Process data in calibration mode (one-time full data transmission)
 */
void AC_Sensor_Process_Calibration_Mode(void) {
    /* Only transmit once when mode first changes to calibration */
    if(ac_sensor.waiting_for_buffer && ac_sensor.buffer_ready && !ac_sensor.calibration_data_sent) {
        AC_Sensor_Transmit_Calibration_Data();

        /* Mark as sent - no more transmissions until mode changes again */
        ac_sensor.calibration_data_sent = 1;
        ac_sensor.waiting_for_buffer = 0;
    }

    /* In calibration mode but data already sent - do nothing */
    /* Just continue normal buffer management but no transmission */
}

/**
 * @brief Transmit complete calibration dataset (2000 samples)
 */
void AC_Sensor_Transmit_Calibration_Data(void) {
    uint32_t total_sample_pairs = AC_TOTAL_SAMPLES / 2;  // 1000 sample pairs

    printf("=== AC SENSOR CALIBRATION DATA START ===\r\n");
    printf("Configuration: %d samples/cycle, %d cycles, %dms total\r\n",
           AC_SAMPLES_PER_CYCLE, AC_CYCLES_PER_MEASUREMENT, AC_CYCLES_PER_MEASUREMENT * 20);
    printf("Sample_Index,Voltage_ADC,Current_ADC\r\n");

    /* Send all sample pairs in one transmission */
    for(uint32_t i = 0; i < total_sample_pairs; i++) {
        printf("%lu,%d,%d\r\n",
               i,
               ac_sensor.adc_buffer[i * 2],      // Voltage sample
               ac_sensor.adc_buffer[i * 2 + 1]); // Current sample

        /* Small delay every 100 samples to prevent UART overflow */
        if(i % 100 == 99) {
            HAL_Delay(1);  // 1ms pause
        }
    }

    printf("=== AC SENSOR CALIBRATION DATA END ===\r\n");
    printf("Total: %lu sample pairs (%d total samples)\r\n", total_sample_pairs, AC_TOTAL_SAMPLES);
    printf("Analysis: %d cycles × %d samples/cycle = %d samples per signal\r\n",
           AC_CYCLES_PER_MEASUREMENT, AC_SAMPLES_PER_CYCLE, AC_VOLTAGE_SAMPLES);
    printf("Switch back to NORMAL mode when calibration complete.\r\n");
}

/**
 * @brief DMA conversion complete callback
 */
void AC_Sensor_DMA_ConvCpltCallback(void) {
    /* 2000 samples collected (5 complete cycles, 1000 sample pairs) */
    ac_sensor.buffer_ready = 1;
    ac_sensor.sample_count = AC_TOTAL_SAMPLES;
    ac_sensor.status = AC_SENSOR_STATUS_READY;
}

/**
 * @brief DMA half complete callback
 */
void AC_Sensor_DMA_HalfCpltCallback(void) {
    /* 1000 samples collected (2.5 cycles, 500 sample pairs) - not used in our application */
    /* We wait for complete buffer (5 cycles) for better accuracy */
}

/**
 * @brief Calculate DC offset from samples
 */
float AC_Sensor_Calculate_DC_Offset(uint16_t* samples, uint32_t count) {
    uint32_t sum = 0;
    for(uint32_t i = 0; i < count; i++) {
        sum += samples[i];
    }
    return (float)sum / (float)count;
}

/**
 * @brief Apply calibration to raw ADC value
 */
float AC_Sensor_Apply_Calibration(uint16_t raw_value, float scale_factor, float offset) {
    /* Remove DC offset and apply scaling */
    return ((float)raw_value - offset) * scale_factor;
}

/**
 * @brief Get sensor statistics string
 */
void AC_Sensor_Get_Statistics(char* buffer, size_t buffer_size) {
    const char* mode_str = (ac_sensor.mode == AC_SENSOR_MODE_NORMAL) ? "NORMAL" : "CALIBRATION";
    const char* status_str;

    switch(ac_sensor.status) {
        case AC_SENSOR_STATUS_COLLECTING: status_str = "COLLECTING"; break;
        case AC_SENSOR_STATUS_READY: status_str = "READY"; break;
        case AC_SENSOR_STATUS_PROCESSING: status_str = "PROCESSING"; break;
        default: status_str = "UNKNOWN"; break;
    }

    snprintf(buffer, buffer_size,
        "AC_SENSOR: %s,%s,V_RMS:%.1fV,I_RMS:%.2fA,Measurements:%lu,CalibSent:%d",
        mode_str, status_str,
        ac_sensor.voltage_rms, ac_sensor.current_rms,
        ac_sensor.measurement_count, ac_sensor.calibration_data_sent);
}

/* HAL Callback Functions */

/**
 * @brief ADC conversion complete callback
 * This function is called by HAL when DMA transfer completes
 */
void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef* hadc) {
    if(hadc == &hadc1) {
        AC_Sensor_DMA_ConvCpltCallback();
    }
}

/**
 * @brief ADC conversion half complete callback
 * This function is called by HAL when DMA transfer is half complete
 */
void HAL_ADC_ConvHalfCpltCallback(ADC_HandleTypeDef* hadc) {
    if(hadc == &hadc1) {
        AC_Sensor_DMA_HalfCpltCallback();
    }
}
