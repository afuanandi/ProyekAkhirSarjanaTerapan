/**
 * @file ac_sensor.h
 * @brief AC Voltage and Current Sensor Module for 7-Level PUCI Inverter
 * @author afuanandi
 * @date 2025
 *
 * This module handles AC voltage and current sensing using ADC1 with DMA.
 * Features dual operating modes: Normal (RMS calculation) and Calibration (raw data).
 *
 * Hardware Configuration:
 * - ADC1 Channel 1 (PA1): AC Voltage sensing via AMC1100
 * - ADC1 Channel 4 (PA4): AC Current sensing via AMC1100
 * - TIM3: 10kHz trigger for synchronized sampling (shared with POD PWM)
 * - DMA2 Stream0: Circular buffer for continuous acquisition
 *
 * Sampling Strategy:
 * - 5 cycles (100ms) collection period synchronized with main loop
 * - 200 samples per cycle, 1000 total samples per signal
 * - Interleaved buffer: [V1,I1,V2,I2,...,V1000,I1000] = 2000 samples
 * - Perfect synchronization with fuzzy controller (100ms update rate)
 */

#ifndef AC_SENSOR_H
#define AC_SENSOR_H

#include "main.h"
#include "math.h"
#include <stdio.h>
#include <string.h>

/* Sensor Parameters */
#define AC_FUNDAMENTAL_FREQ 50.0f           // 50 Hz AC frequency
#define AC_SAMPLING_FREQ 10000.0f           // 10 kHz sampling rate (using TIM3)
#define AC_SAMPLES_PER_CYCLE 200            // 200 samples per 20ms cycle (higher resolution)
#define AC_CYCLES_PER_MEASUREMENT 5         // 5 cycles = 100ms measurement period
#define AC_TOTAL_SAMPLES 2000               // Total samples in buffer (1000V + 1000I)
#define AC_VOLTAGE_SAMPLES 1000             // Voltage samples per measurement (200 * 5 cycles)
#define AC_CURRENT_SAMPLES 1000             // Current samples per measurement (200 * 5 cycles)

/* ADC Parameters */
#define AC_ADC_RESOLUTION 4096.0f            // 12-bit ADC (0-4095)
#define AC_ADC_VREF 3.3f                     // 3.3V reference voltage
#define AC_ADC_BITS 12                       // 12-bit resolution

/* Calibration and Scaling */
#define AC_VOLTAGE_NOMINAL_RMS 220.0f        // Expected voltage RMS (Country standard)
#define AC_CURRENT_NOMINAL_RMS 10.0f         // Expected current RMS (typical load)

/* Debug and Transmission */
#define AC_DEBUG_BUFFER_SIZE 150             // UART debug buffer size

/**
 * @brief AC Sensor operation modes
 */
typedef enum {
    AC_SENSOR_MODE_NORMAL,          // Calculate RMS values for control system
    AC_SENSOR_MODE_CALIBRATION      // Transmit raw ADC data for analysis
} AC_Sensor_Mode_t;

/**
 * @brief AC Sensor data status
 */
typedef enum {
    AC_SENSOR_STATUS_COLLECTING,     // Data collection in progress
    AC_SENSOR_STATUS_READY,          // Data ready for processing
    AC_SENSOR_STATUS_PROCESSING      // Processing in progress
} AC_Sensor_Status_t;

/**
 * @brief Main AC Sensor control structure
 */
typedef struct {
    /* Operation Mode */
    AC_Sensor_Mode_t mode;               // Current operation mode
    AC_Sensor_Status_t status;           // Current data status

    /* DMA Buffer Management */
    uint16_t adc_buffer[AC_TOTAL_SAMPLES];   // DMA buffer: [V1,I1,V2,I2,...] (1000 samples)
    uint8_t buffer_ready;                    // Buffer ready flag
    uint32_t sample_count;                   // Current sample count

    /* Processed Data (Normal Mode) */
    float voltage_rms;                   // Calculated voltage RMS (V)
    float current_rms;                   // Calculated current RMS (A)
    float voltage_peak;                  // Peak voltage value
    float current_peak;                  // Peak current value

    /* Raw Signal Analysis (for calibration) */
    uint16_t voltage_adc_peak;           // Highest ADC value in current buffer
    uint16_t voltage_adc_trough;         // Lowest ADC value in current buffer
    float voltage_adc_midpoint;          // Calculated midpoint (zero crossing)
    float voltage_adc_raw_rms;           // RMS calculated from raw ADC values
    uint16_t current_adc_peak;           // Highest current ADC value
    uint16_t current_adc_trough;         // Lowest current ADC value
    float current_adc_midpoint;          // Current midpoint
    float current_adc_raw_rms;           // Current raw RMS

    /* Raw Data Arrays (for processing) */
    uint16_t voltage_samples[AC_VOLTAGE_SAMPLES];    // Extracted voltage samples (500)
    uint16_t current_samples[AC_CURRENT_SAMPLES];    // Extracted current samples (500)

    /* Calibration Parameters */
    float voltage_scale_factor;         // Voltage scaling factor (V/ADC_count)
    float current_scale_factor;         // Current scaling factor (A/ADC_count)
    float voltage_offset;               // DC offset compensation (ADC counts)
    float current_offset;               // DC offset compensation (ADC counts)

    /* Statistics and Monitoring */
    uint32_t measurement_count;         // Total measurements completed
    uint32_t last_update_tick;          // Last update timestamp
    uint8_t fault_flag;                 // Sensor fault detection

    /* Calibration Mode - One-time transmission approach */
    AC_Sensor_Mode_t previous_mode;          // Track mode changes
    uint8_t calibration_data_sent;           // Flag: calibration data already sent
    uint8_t waiting_for_buffer;              // Flag: waiting for complete buffer after mode change

    /* Debug System */
    uint8_t debug_flag;                 		// Enable/disable debug output
    char debug_buffer[AC_DEBUG_BUFFER_SIZE];  	// Debug message buffer

} AC_Sensor_TypeDef;

/* External Variables */
extern AC_Sensor_TypeDef ac_sensor;
extern ADC_HandleTypeDef hadc1;
extern TIM_HandleTypeDef htim3;
extern DMA_HandleTypeDef hdma_adc1;
extern UART_HandleTypeDef huart2;

/* Function Prototypes */

/**
 * @brief Initialize AC sensor system
 * Configures ADC, DMA, and starts acquisition
 */
void AC_Sensor_Init(void);

/**
 * @brief Start AC sensor data acquisition
 * Begins continuous DMA-based sampling
 */
void AC_Sensor_Start(void);

/**
 * @brief Stop AC sensor data acquisition
 * Stops DMA and timer
 */
void AC_Sensor_Stop(void);

/**
 * @brief Main update function (call from main loop every 100ms)
 * Processes collected data based on current mode
 */
void AC_Sensor_Update(void);

/**
 * @brief Set operation mode with automatic one-time calibration data transmission
 * @param mode: AC_SENSOR_MODE_NORMAL or AC_SENSOR_MODE_CALIBRATION
 *
 * When switching TO calibration mode:
 * - Waits for next complete buffer (100ms)
 * - Transmits all 2000 samples once via UART
 * - No further transmissions until mode changes again
 *
 * When switching FROM calibration mode:
 * - Resets calibration flags for next calibration session
 */
void AC_Sensor_Set_Mode(AC_Sensor_Mode_t mode);

/**
 * @brief Get current operation mode
 * @return Current operation mode
 */
AC_Sensor_Mode_t AC_Sensor_Get_Mode(void);

/**
 * @brief Get voltage RMS value (Normal mode only)
 * @return Voltage RMS in Volts (primary input for fuzzy controller)
 */
float AC_Sensor_Get_Voltage_RMS(void);

/**
 * @brief Get current RMS value (Normal mode only)
 * @return Current RMS in Amperes
 */
float AC_Sensor_Get_Current_RMS(void);

/**
 * @brief Get voltage peak value
 * @return Peak voltage in Volts
 */
float AC_Sensor_Get_Voltage_Peak(void);

/**
 * @brief Get current peak value
 * @return Peak current in Amperes
 */
float AC_Sensor_Get_Current_Peak(void);

/**
 * @brief Set voltage calibration parameters
 * @param scale_factor: Scaling factor (V/ADC_count)
 * @param offset: DC offset (ADC counts)
 */
void AC_Sensor_Set_Voltage_Calibration(float scale_factor, float offset);

/**
 * @brief Set current calibration parameters
 * @param scale_factor: Scaling factor (A/ADC_count)
 * @param offset: DC offset (ADC counts)
 */
void AC_Sensor_Set_Current_Calibration(float scale_factor, float offset);

/**
 * @brief Check if new data is available
 * @return 1 if new data ready, 0 if still collecting
 */
uint8_t AC_Sensor_Is_Data_Ready(void);

/**
 * @brief Get sensor status
 * @return Current sensor status
 */
AC_Sensor_Status_t AC_Sensor_Get_Status(void);

/**
 * @brief Set debug flag
 * @param flag: 1 to enable debug output, 0 to disable
 */
void AC_Sensor_Set_Debug(uint8_t flag);

/**
 * @brief Get sensor statistics string
 * @param buffer: Output buffer for statistics
 * @param buffer_size: Size of output buffer
 */
void AC_Sensor_Get_Statistics(char* buffer, size_t buffer_size);

/* Internal Processing Functions */

/**
 * @brief Extract voltage and current samples from interleaved DMA buffer
 */
void AC_Sensor_Extract_Samples(void);

/**
 * @brief Calculate RMS values from extracted samples
 */
void AC_Sensor_Calculate_RMS(void);

/**
 * @brief Analyze raw signal characteristics (peak, trough, midpoint, raw RMS)
 * Called during RMS calculation for calibration purposes
 */
void AC_Sensor_Analyze_Raw_Signal(void);

/**
 * @brief Calculate raw ADC RMS for voltage signal
 * @return Raw ADC RMS value (before calibration scaling)
 */
float AC_Sensor_Calculate_Voltage_Raw_RMS(void);

/**
 * @brief Calculate raw ADC RMS for current signal
 * @return Raw ADC RMS value (before calibration scaling)
 */
float AC_Sensor_Calculate_Current_Raw_RMS(void);

/**
 * @brief Process data in normal mode (RMS calculation)
 */
void AC_Sensor_Process_Normal_Mode(void);

/**
 * @brief Process data in calibration mode (one-time full data transmission)
 * Transmits complete dataset only once when mode changes to calibration
 */
void AC_Sensor_Process_Calibration_Mode(void);

/**
 * @brief Transmit complete calibration dataset (2000 samples)
 * Called once when switching to calibration mode
 */
void AC_Sensor_Transmit_Calibration_Data(void);

/**
 * @brief DMA conversion complete callback
 * Called when DMA buffer is full (1000 samples pairs = 2000 total collected)
 */
void AC_Sensor_DMA_ConvCpltCallback(void);

/**
 * @brief DMA half complete callback
 * Called when half of DMA buffer is full (500 pairs = 1000 total samples)
 */
void AC_Sensor_DMA_HalfCpltCallback(void);

/**
 * @brief Calculate DC offset from samples
 * @param samples: Array of samples
 * @param count: Number of samples
 * @return Average DC offset
 */
float AC_Sensor_Calculate_DC_Offset(uint16_t* samples, uint32_t count);

/**
 * @brief Apply calibration to raw ADC value
 * @param raw_value: Raw ADC value
 * @param scale_factor: Scaling factor
 * @param offset: DC offset
 * @return Calibrated value
 */
float AC_Sensor_Apply_Calibration(uint16_t raw_value, float scale_factor, float offset);

/**
 * @brief Check if calibration data has been transmitted
 * @return 1 if calibration data sent, 0 if waiting or normal mode
 */
uint8_t AC_Sensor_Is_Calibration_Data_Sent(void);

/**
 * @brief Reset calibration transmission flags (for testing)
 * Forces retransmission on next mode change to calibration
 */
void AC_Sensor_Reset_Calibration_Flags(void);

#endif /* AC_SENSOR_H */
