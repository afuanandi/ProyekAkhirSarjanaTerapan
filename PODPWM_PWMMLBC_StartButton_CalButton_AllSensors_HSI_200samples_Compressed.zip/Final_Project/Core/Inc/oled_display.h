/**
 * @file oled_display.h
 * @brief OLED display management
 */

#ifndef OLED_DISPLAY_H
#define OLED_DISPLAY_H

#include "sh1106.h"
#include "main.h"

// Display layout constants
#define OLED_WIDTH          128
#define OLED_HEIGHT         64
#define OLED_CENTER_LINE    64
#define OLED_TITLE_ROW      0
#define OLED_VOLTAGE_ROW    16
#define OLED_CURRENT_ROW    24
#define OLED_POWER_ROW      32
#define OLED_MI_ROW         46
#define OLED_STATUS_ROW     56
#define OLED_SEPARATOR_ROW  10

// Display data structure
typedef struct {
    // DC Input values
    float dc_voltage;
    float dc_current;
    float dc_power;
    uint8_t converter_status;  // 0: OFF, 1: ON
    uint8_t control_mode;      // 0: Open Loop, 1: Closed Loop

    // AC Output values
    float ac_voltage;
    float ac_current;
    float ac_power;
    float modulation_index;
} DisplayData_t;

// Function prototypes
void OLED_Display_Init(void);
void OLED_Display_Update(DisplayData_t* data);
void OLED_Display_DrawLayout(void);
void OLED_Display_UpdateValues(DisplayData_t* data);
void OLED_Display_UpdateFromSystem(float dc_voltage, float dc_current,
                                  float ac_voltage, float ac_current,
                                  float modulation_index, uint8_t converter_status,
                                  uint8_t control_mode, uint8_t sensor_mode);

#endif /* OLED_DISPLAY_H */
