/**
 * @file sh1106.c
 * @brief Non-blocking SH1106 OLED display driver implementation
 * @author afuanandi & Claude
 */

#include "sh1106.h"
#include <string.h>
#include <stdlib.h>
#include <stdio.h>

/* Global controller structure */
SH1106_Controller_t sh1106_ctrl;

/* Basic 5x8 font (ASCII 32-127) - same as before */
static const uint8_t font5x8[][5] = {
    {0x00, 0x00, 0x00, 0x00, 0x00}, // 32 Space
    {0x00, 0x00, 0x5F, 0x00, 0x00}, // 33 !
    {0x00, 0x07, 0x00, 0x07, 0x00}, // 34 "
    {0x14, 0x7F, 0x14, 0x7F, 0x14}, // 35 #
    {0x24, 0x2A, 0x7F, 0x2A, 0x12}, // 36 $
    {0x23, 0x13, 0x08, 0x64, 0x62}, // 37 %
    {0x36, 0x49, 0x55, 0x22, 0x50}, // 38 &
    {0x00, 0x05, 0x03, 0x00, 0x00}, // 39 '
    {0x00, 0x1C, 0x22, 0x41, 0x00}, // 40 (
    {0x00, 0x41, 0x22, 0x1C, 0x00}, // 41 )
    {0x14, 0x08, 0x3E, 0x08, 0x14}, // 42 *
    {0x08, 0x08, 0x3E, 0x08, 0x08}, // 43 +
    {0x00, 0x50, 0x30, 0x00, 0x00}, // 44 ,
    {0x08, 0x08, 0x08, 0x08, 0x08}, // 45 -
    {0x00, 0x60, 0x60, 0x00, 0x00}, // 46 .
    {0x20, 0x10, 0x08, 0x04, 0x02}, // 47 /
    {0x3E, 0x51, 0x49, 0x45, 0x3E}, // 48 0
    {0x00, 0x42, 0x7F, 0x40, 0x00}, // 49 1
    {0x42, 0x61, 0x51, 0x49, 0x46}, // 50 2
    {0x21, 0x41, 0x45, 0x4B, 0x31}, // 51 3
    {0x18, 0x14, 0x12, 0x7F, 0x10}, // 52 4
    {0x27, 0x45, 0x45, 0x45, 0x39}, // 53 5
    {0x3C, 0x4A, 0x49, 0x49, 0x30}, // 54 6
    {0x01, 0x71, 0x09, 0x05, 0x03}, // 55 7
    {0x36, 0x49, 0x49, 0x49, 0x36}, // 56 8
    {0x06, 0x49, 0x49, 0x29, 0x1E}, // 57 9
    {0x00, 0x36, 0x36, 0x00, 0x00}, // 58 :
    {0x00, 0x56, 0x36, 0x00, 0x00}, // 59 ;
    {0x08, 0x14, 0x22, 0x41, 0x00}, // 60 <
    {0x14, 0x14, 0x14, 0x14, 0x14}, // 61 =
    {0x00, 0x41, 0x22, 0x14, 0x08}, // 62 >
    {0x02, 0x01, 0x51, 0x09, 0x06}, // 63 ?
    {0x32, 0x49, 0x79, 0x41, 0x3E}, // 64 @
    {0x7E, 0x11, 0x11, 0x11, 0x7E}, // 65 A
    {0x7F, 0x49, 0x49, 0x49, 0x36}, // 66 B
    {0x3E, 0x41, 0x41, 0x41, 0x22}, // 67 C
    {0x7F, 0x41, 0x41, 0x22, 0x1C}, // 68 D
    {0x7F, 0x49, 0x49, 0x49, 0x41}, // 69 E
    {0x7F, 0x09, 0x09, 0x09, 0x01}, // 70 F
    {0x3E, 0x41, 0x49, 0x49, 0x7A}, // 71 G
    {0x7F, 0x08, 0x08, 0x08, 0x7F}, // 72 H
    {0x00, 0x41, 0x7F, 0x41, 0x00}, // 73 I
    {0x20, 0x40, 0x41, 0x3F, 0x01}, // 74 J
    {0x7F, 0x08, 0x14, 0x22, 0x41}, // 75 K
    {0x7F, 0x40, 0x40, 0x40, 0x40}, // 76 L
    {0x7F, 0x02, 0x0C, 0x02, 0x7F}, // 77 M
    {0x7F, 0x04, 0x08, 0x10, 0x7F}, // 78 N
    {0x3E, 0x41, 0x41, 0x41, 0x3E}, // 79 O
    {0x7F, 0x09, 0x09, 0x09, 0x06}, // 80 P
    {0x3E, 0x41, 0x51, 0x21, 0x5E}, // 81 Q
    {0x7F, 0x09, 0x19, 0x29, 0x46}, // 82 R
    {0x46, 0x49, 0x49, 0x49, 0x31}, // 83 S
    {0x01, 0x01, 0x7F, 0x01, 0x01}, // 84 T
    {0x3F, 0x40, 0x40, 0x40, 0x3F}, // 85 U
    {0x1F, 0x20, 0x40, 0x20, 0x1F}, // 86 V
    {0x3F, 0x40, 0x38, 0x40, 0x3F}, // 87 W
    {0x63, 0x14, 0x08, 0x14, 0x63}, // 88 X
    {0x07, 0x08, 0x70, 0x08, 0x07}, // 89 Y
    {0x61, 0x51, 0x49, 0x45, 0x43}, // 90 Z
    {0x00, 0x7F, 0x41, 0x41, 0x00}, // 91 [
    {0x02, 0x04, 0x08, 0x10, 0x20}, // 92 backslash
    {0x00, 0x41, 0x41, 0x7F, 0x00}, // 93 ]
    {0x04, 0x02, 0x01, 0x02, 0x04}, // 94 ^
    {0x40, 0x40, 0x40, 0x40, 0x40}, // 95 _
    {0x00, 0x01, 0x02, 0x04, 0x00}, // 96 `
    {0x20, 0x54, 0x54, 0x54, 0x78}, // 97 a
    {0x7F, 0x48, 0x44, 0x44, 0x38}, // 98 b
    {0x38, 0x44, 0x44, 0x44, 0x20}, // 99 c
    {0x38, 0x44, 0x44, 0x48, 0x7F}, // 100 d
    {0x38, 0x54, 0x54, 0x54, 0x18}, // 101 e
    {0x08, 0x7E, 0x09, 0x01, 0x02}, // 102 f
    {0x0C, 0x52, 0x52, 0x52, 0x3E}, // 103 g
    {0x7F, 0x08, 0x04, 0x04, 0x78}, // 104 h
    {0x00, 0x44, 0x7D, 0x40, 0x00}, // 105 i
    {0x20, 0x40, 0x44, 0x3D, 0x00}, // 106 j
    {0x7F, 0x10, 0x28, 0x44, 0x00}, // 107 k
    {0x00, 0x41, 0x7F, 0x40, 0x00}, // 108 l
    {0x7C, 0x04, 0x18, 0x04, 0x78}, // 109 m
    {0x7C, 0x08, 0x04, 0x04, 0x78}, // 110 n
    {0x38, 0x44, 0x44, 0x44, 0x38}, // 111 o
    {0x7C, 0x14, 0x14, 0x14, 0x08}, // 112 p
    {0x08, 0x14, 0x14, 0x18, 0x7C}, // 113 q
    {0x7C, 0x08, 0x04, 0x04, 0x08}, // 114 r
    {0x48, 0x54, 0x54, 0x54, 0x20}, // 115 s
    {0x04, 0x3F, 0x44, 0x40, 0x20}, // 116 t
    {0x3C, 0x40, 0x40, 0x20, 0x7C}, // 117 u
    {0x1C, 0x20, 0x40, 0x20, 0x1C}, // 118 v
    {0x3C, 0x40, 0x30, 0x40, 0x3C}, // 119 w
    {0x44, 0x28, 0x10, 0x28, 0x44}, // 120 x
    {0x0C, 0x50, 0x50, 0x50, 0x3C}, // 121 y
    {0x44, 0x64, 0x54, 0x4C, 0x44}, // 122 z
    {0x00, 0x08, 0x36, 0x41, 0x00}, // 123 {
    {0x00, 0x00, 0x7F, 0x00, 0x00}, // 124 |
    {0x00, 0x41, 0x36, 0x08, 0x00}, // 125 }
    {0x10, 0x08, 0x08, 0x10, 0x08}, // 126 ~
    {0x78, 0x46, 0x41, 0x46, 0x78}  // 127 DEL
};

/* Internal function prototypes */
static HAL_StatusTypeDef SH1106_SendCommand_Fast(uint8_t cmd);
static HAL_StatusTypeDef SH1106_SendData_Chunk(uint8_t* data, uint8_t size);
static void SH1106_Process_Update_State_Machine(void);
static void SH1106_Setup_Page_Commands(uint8_t page);
static uint8_t SH1106_Prepare_Data_Chunk(uint8_t page, uint8_t start_col, uint8_t size);

/**
 * @brief Initialize the SH1106 display (blocking - only called once)
 */
void SH1106_Init(void) {
    /* Initialize controller structure */
    memset(&sh1106_ctrl, 0, sizeof(sh1106_ctrl));
    sh1106_ctrl.update_state = DISPLAY_STATE_IDLE;
    sh1106_ctrl.last_update_time = HAL_GetTick();

    /* Wait for display to power up (only blocking delay in init) */
    HAL_Delay(100);

    /* Send initialization sequence (blocking - only during startup) */
    SH1106_SendCommand_Fast(SH1106_DISPLAYOFF);
    SH1106_SendCommand_Fast(SH1106_SETDISPLAYCLOCKDIV);
    SH1106_SendCommand_Fast(0x80);
    SH1106_SendCommand_Fast(SH1106_SETMULTIPLEX);
    SH1106_SendCommand_Fast(0x3F);
    SH1106_SendCommand_Fast(SH1106_SETDISPLAYOFFSET);
    SH1106_SendCommand_Fast(0x00);
    SH1106_SendCommand_Fast(SH1106_SETSTARTLINE | 0x00);
    SH1106_SendCommand_Fast(SH1106_CHARGEPUMP);
    SH1106_SendCommand_Fast(0x14);
    SH1106_SendCommand_Fast(SH1106_MEMORYMODE);
    SH1106_SendCommand_Fast(0x00);
    SH1106_SendCommand_Fast(SH1106_SEGREMAP | 0x01);
    SH1106_SendCommand_Fast(SH1106_COMSCANDEC);
    SH1106_SendCommand_Fast(SH1106_SETCOMPINS);
    SH1106_SendCommand_Fast(0x12);
    SH1106_SendCommand_Fast(SH1106_SETCONTRAST);
    SH1106_SendCommand_Fast(0xCF);
    SH1106_SendCommand_Fast(SH1106_SETPRECHARGE);
    SH1106_SendCommand_Fast(0xF1);
    SH1106_SendCommand_Fast(SH1106_SETVCOMDETECT);
    SH1106_SendCommand_Fast(0x40);
    SH1106_SendCommand_Fast(SH1106_DISPLAYALLON_RESUME);
    SH1106_SendCommand_Fast(SH1106_NORMALDISPLAY);
    SH1106_SendCommand_Fast(SH1106_DISPLAYON);

    /* Clear display buffer */
    SH1106_Clear();

    /* Mark as initialized */
    sh1106_ctrl.initialized = 1;

    printf("SH1106 Non-blocking display initialized\r\n");
}

/**
 * @brief Non-blocking update function - call from main loop frequently
 */
void SH1106_Update(void) {
    if(!sh1106_ctrl.initialized) {
        return;
    }

    /* Process the update state machine */
    SH1106_Process_Update_State_Machine();
}

/**
 * @brief Request a display update (non-blocking)
 */
void SH1106_Request_Update(void) {
    if(!sh1106_ctrl.initialized) {
        return;
    }

    /* Set update pending flag */
    sh1106_ctrl.update_pending = 1;

    /* If display is idle, start update immediately */
    if(sh1106_ctrl.update_state == DISPLAY_STATE_IDLE) {
        sh1106_ctrl.update_state = DISPLAY_STATE_UPDATING;
        sh1106_ctrl.current_page = 0;
        sh1106_ctrl.current_column = 0;
        sh1106_ctrl.update_start_time = HAL_GetTick();
    }
}

/**
 * @brief Force immediate display update (still non-blocking)
 */
void SH1106_Force_Update(void) {
    sh1106_ctrl.update_forced = 1;
    SH1106_Request_Update();
}

/**
 * @brief Check if display update is in progress
 */
uint8_t SH1106_Is_Updating(void) {
    return (sh1106_ctrl.update_state != DISPLAY_STATE_IDLE);
}

/**
 * @brief Clear the display buffer
 */
void SH1106_Clear(void) {
    memset(sh1106_ctrl.buffer, 0, sizeof(sh1106_ctrl.buffer));
}

/**
 * @brief Draw a pixel in the buffer
 */
void SH1106_DrawPixel(uint8_t x, uint8_t y, bool color) {
    if(x >= SH1106_WIDTH || y >= SH1106_HEIGHT) {
        return;
    }

    if(color) {
        sh1106_ctrl.buffer[y / 8][x] |= (1 << (y % 8));
    } else {
        sh1106_ctrl.buffer[y / 8][x] &= ~(1 << (y % 8));
    }
}

/**
 * @brief Draw a character at specified position
 */
void SH1106_DrawChar(uint8_t x, uint8_t y, char c) {
    if(c < 32 || c > 127) return;

    for(uint8_t i = 0; i < 5; i++) {
        uint8_t column = font5x8[c - 32][i];
        for(uint8_t j = 0; j < 8; j++) {
            if(column & (1 << j)) {
                SH1106_DrawPixel(x + i, y + j, true);
            }
        }
    }
}

/**
 * @brief Draw a string at specified position
 */
void SH1106_DrawString(uint8_t x, uint8_t y, const char* str) {
    while(*str) {
        SH1106_DrawChar(x, y, *str);
        x += 6;  // Character width + spacing
        str++;
    }
}

/**
 * @brief Draw a line between two points
 */
void SH1106_DrawLine(uint8_t x0, uint8_t y0, uint8_t x1, uint8_t y1) {
    int16_t dx = abs(x1 - x0);
    int16_t dy = abs(y1 - y0);
    int16_t sx = (x0 < x1) ? 1 : -1;
    int16_t sy = (y0 < y1) ? 1 : -1;
    int16_t err = dx - dy;

    while (1) {
        SH1106_DrawPixel(x0, y0, true);

        if (x0 == x1 && y0 == y1) break;

        int16_t e2 = 2 * err;
        if (e2 > -dy) {
            err -= dy;
            x0 += sx;
        }
        if (e2 < dx) {
            err += dx;
            y0 += sy;
        }
    }
}

/**
 * @brief Draw a rectangle outline
 */
void SH1106_DrawRect(uint8_t x, uint8_t y, uint8_t width, uint8_t height) {
    SH1106_DrawLine(x, y, x + width - 1, y);
    SH1106_DrawLine(x, y + height - 1, x + width - 1, y + height - 1);
    SH1106_DrawLine(x, y, x, y + height - 1);
    SH1106_DrawLine(x + width - 1, y, x + width - 1, y + height - 1);
}

/**
 * @brief Fill a rectangle with white pixels
 */
void SH1106_FillRect(uint8_t x, uint8_t y, uint8_t width, uint8_t height) {
    for(uint8_t i = x; i < x + width; i++) {
        for(uint8_t j = y; j < y + height; j++) {
            SH1106_DrawPixel(i, j, true);
        }
    }
}

/**
 * @brief Clear a rectangle
 */
void SH1106_ClearRect(uint8_t x, uint8_t y, uint8_t width, uint8_t height) {
    for(uint8_t i = x; i < x + width; i++) {
        for(uint8_t j = y; j < y + height; j++) {
            SH1106_DrawPixel(i, j, false);
        }
    }
}

/**
 * @brief Set display contrast
 */
void SH1106_SetContrast(uint8_t contrast) {
    SH1106_SendCommand_Fast(SH1106_SETCONTRAST);
    SH1106_SendCommand_Fast(contrast);
}

/**
 * @brief Turn display on
 */
void SH1106_DisplayOn(void) {
    SH1106_SendCommand_Fast(SH1106_DISPLAYON);
}

/**
 * @brief Turn display off
 */
void SH1106_DisplayOff(void) {
    SH1106_SendCommand_Fast(SH1106_DISPLAYOFF);
}

/**
 * @brief Get display statistics for debugging
 */
void SH1106_Get_Statistics(char* buffer, size_t buffer_size) {
    snprintf(buffer, buffer_size,
        "OLED: Updates:%lu, Errors:%lu, I2C_Fails:%lu, State:%d",
        sh1106_ctrl.successful_updates,
        sh1106_ctrl.failed_updates,
        sh1106_ctrl.i2c_errors,
        sh1106_ctrl.update_state);
}

/**
 * @brief Test function to verify display works
 */
void SH1106_Test(void) {
    SH1106_Clear();
    SH1106_DrawString(10, 10, "POWER CONVERTER");
    SH1106_DrawString(10, 20, "STM32F446RE");
    SH1106_DrawString(10, 30, "SH1106 OLED");
    SH1106_Request_Update();
}

/* Internal Functions */

/**
 * @brief Send command with short timeout
 */
static HAL_StatusTypeDef SH1106_SendCommand_Fast(uint8_t cmd) {
    uint8_t data[2] = {0x00, cmd};
    return HAL_I2C_Master_Transmit(&hi2c1, SH1106_I2C_ADDR << 1, data, 2, SH1106_I2C_TIMEOUT_MS);
}

/**
 * @brief Send data chunk with short timeout
 */
static HAL_StatusTypeDef SH1106_SendData_Chunk(uint8_t* data, uint8_t size) {
    return HAL_I2C_Master_Transmit(&hi2c1, SH1106_I2C_ADDR << 1, data, size, SH1106_I2C_TIMEOUT_MS);
}

/**
 * @brief Process the update state machine
 */
static void SH1106_Process_Update_State_Machine(void) {
    HAL_StatusTypeDef result;

    switch(sh1106_ctrl.update_state) {
        case DISPLAY_STATE_IDLE:
            /* Check if update is requested */
            if(sh1106_ctrl.update_pending) {
                sh1106_ctrl.update_state = DISPLAY_STATE_UPDATING;
                sh1106_ctrl.current_page = 0;
                sh1106_ctrl.current_column = 0;
                sh1106_ctrl.update_start_time = HAL_GetTick();
                sh1106_ctrl.retry_count = 0;
            }
            break;

        case DISPLAY_STATE_UPDATING:
            /* Setup page commands */
            sh1106_ctrl.update_state = DISPLAY_STATE_PAGE_SETUP;
            SH1106_Setup_Page_Commands(sh1106_ctrl.current_page);
            break;

        case DISPLAY_STATE_PAGE_SETUP:
            /* Start transmitting page data */
            sh1106_ctrl.update_state = DISPLAY_STATE_PAGE_DATA;
            sh1106_ctrl.current_column = 0;
            break;

        case DISPLAY_STATE_PAGE_DATA:
            /* Transmit data chunk */
            uint8_t chunk_size = SH1106_Prepare_Data_Chunk(
                sh1106_ctrl.current_page,
                sh1106_ctrl.current_column,
                SH1106_CHUNK_SIZE
            );

            if(chunk_size > 0) {
                result = SH1106_SendData_Chunk(sh1106_ctrl.transmission_buffer, chunk_size + 1);

                if(result == HAL_OK) {
                    /* Successful transmission */
                    sh1106_ctrl.current_column += chunk_size;
                    sh1106_ctrl.retry_count = 0;

                    /* Check if page is complete */
                    if(sh1106_ctrl.current_column >= SH1106_WIDTH) {
                        sh1106_ctrl.current_page++;

                        /* Check if all pages are complete */
                        if(sh1106_ctrl.current_page >= SH1106_PAGES) {
                            /* Update complete */
                            sh1106_ctrl.update_state = DISPLAY_STATE_COMPLETE;
                        } else {
                            /* Move to next page */
                            sh1106_ctrl.update_state = DISPLAY_STATE_UPDATING;
                        }
                    }
                } else {
                    /* Transmission failed */
                    sh1106_ctrl.i2c_errors++;
                    sh1106_ctrl.retry_count++;

                    if(sh1106_ctrl.retry_count >= SH1106_MAX_RETRIES) {
                        /* Max retries reached - abort update */
                        sh1106_ctrl.update_state = DISPLAY_STATE_IDLE;
                        sh1106_ctrl.failed_updates++;
                        sh1106_ctrl.update_pending = 0;
                    }
                }
            }
            break;

        case DISPLAY_STATE_COMPLETE:
            /* Update completed successfully */
            sh1106_ctrl.update_state = DISPLAY_STATE_IDLE;
            sh1106_ctrl.update_pending = 0;
            sh1106_ctrl.update_forced = 0;
            sh1106_ctrl.successful_updates++;
            sh1106_ctrl.last_update_time = HAL_GetTick();
            break;
    }
}

/**
 * @brief Setup page commands (non-blocking)
 */
static void SH1106_Setup_Page_Commands(uint8_t page) {
    /* Send page setup commands with short timeout */
    SH1106_SendCommand_Fast(SH1106_SETPAGEADDR | page);
    SH1106_SendCommand_Fast(SH1106_SETLOWCOLUMN | 2);  // Column offset for SH1106
    SH1106_SendCommand_Fast(SH1106_SETHIGHCOLUMN | 0);
}

/**
 * @brief Prepare data chunk for transmission
 */
static uint8_t SH1106_Prepare_Data_Chunk(uint8_t page, uint8_t start_col, uint8_t max_size) {
    uint8_t remaining = SH1106_WIDTH - start_col;
    uint8_t chunk_size = (remaining > max_size) ? max_size : remaining;

    if(chunk_size == 0) {
        return 0;
    }

    /* Prepare transmission buffer */
    sh1106_ctrl.transmission_buffer[0] = 0x40;  // Data mode control byte

    /* Copy data from display buffer */
    for(uint8_t i = 0; i < chunk_size; i++) {
        sh1106_ctrl.transmission_buffer[i + 1] = sh1106_ctrl.buffer[page][start_col + i];
    }

    return chunk_size;
}
