/**
 * @file fuzzy_inference.c
 * @brief Type-2 Fuzzy Inference Engine Implementation
 * @author afuanandi
 * @date 2025
 *
 * This module implements the core Type-2 fuzzy inference engine using
 * Karnik-Mendel type reduction algorithm for real-time embedded applications.
 */

#include "fuzzy_init.h"
#include <math.h>
#include <stdlib.h>

/* Internal function prototypes */
static float TriangularMembership(float x, float a, float b, float c);
static float KarnikMendelTypeReduction(float* firing_strengths_lower, float* firing_strengths_upper,
                                      float* consequent_centers, int num_rules);
static void BubbleSort(float* array, int* indices, int n);

/**
 * @brief Main Type-2 fuzzy inference function
 * @param system: Pointer to fuzzy system structure
 * @param input1: First input value (scaled error)
 * @param input2: Second input value (scaled error derivative)
 * @return: Crisp output value (modulation index)
 */
float FuzzyInference(FuzzySystem* system, float input1, float input2) {
    if(system == NULL) {
        return 1.0f;  // Default modulation index
    }

    /* Arrays for firing strengths */
    float firing_strengths_lower[49];  // Maximum 49 rules (7x7)
    float firing_strengths_upper[49];
    float consequent_centers[49];

    /* Step 1: Fuzzification - Calculate membership grades for all inputs */
    float input1_memberships_lower[7];
    float input1_memberships_upper[7];
    float input2_memberships_lower[7];
    float input2_memberships_upper[7];

    /* Calculate input 1 membership grades */
    for(int i = 0; i < system->inputs[0].numMFs; i++) {
        TriangularMF* mf = &system->inputs[0].mfs[i];

        /* Primary membership */
        float primary = TriangularMembership(input1, mf->a, mf->b, mf->c);

        /* Type-2 bounds */
        input1_memberships_lower[i] = primary * mf->lower;
        input1_memberships_upper[i] = primary * mf->upper;

        /* Apply uncertainty bounds */
        if(primary > 0.0f) {
            input1_memberships_lower[i] = fmaxf(input1_memberships_lower[i] - mf->lowerUncertainty, 0.0f);
            input1_memberships_upper[i] = fminf(input1_memberships_upper[i] + mf->upperUncertainty, 1.0f);
        }
    }

    /* Calculate input 2 membership grades */
    for(int i = 0; i < system->inputs[1].numMFs; i++) {
        TriangularMF* mf = &system->inputs[1].mfs[i];

        /* Primary membership */
        float primary = TriangularMembership(input2, mf->a, mf->b, mf->c);

        /* Type-2 bounds */
        input2_memberships_lower[i] = primary * mf->lower;
        input2_memberships_upper[i] = primary * mf->upper;

        /* Apply uncertainty bounds */
        if(primary > 0.0f) {
            input2_memberships_lower[i] = fmaxf(input2_memberships_lower[i] - mf->lowerUncertainty, 0.0f);
            input2_memberships_upper[i] = fminf(input2_memberships_upper[i] + mf->upperUncertainty, 1.0f);
        }
    }

    /* Step 2: Rule Evaluation */
    int rule_count = 0;
    for(int r = 0; r < system->numRules; r++) {
        FuzzyRule* rule = &system->rules[r];

        /* Get antecedent membership grades */
        float input1_lower = input1_memberships_lower[rule->input1MF];
        float input1_upper = input1_memberships_upper[rule->input1MF];
        float input2_lower = input2_memberships_lower[rule->input2MF];
        float input2_upper = input2_memberships_upper[rule->input2MF];

        /* Rule firing strength using MIN t-norm */
        firing_strengths_lower[rule_count] = fminf(input1_lower, input2_lower) * rule->weight;
        firing_strengths_upper[rule_count] = fminf(input1_upper, input2_upper) * rule->weight;

        /* Get consequent center */
        consequent_centers[rule_count] = system->output.mfs[rule->outputMF].b;

        rule_count++;
    }

    /* Step 3: Type Reduction using Karnik-Mendel algorithm */
    float crisp_output = KarnikMendelTypeReduction(firing_strengths_lower, firing_strengths_upper,
                                                  consequent_centers, rule_count);

    return crisp_output;
}

/**
 * @brief Calculate triangular membership function value
 * @param x: Input value
 * @param a: Left point of triangle
 * @param b: Peak point of triangle
 * @param c: Right point of triangle
 * @return: Membership grade (0.0 to 1.0)
 */
static float TriangularMembership(float x, float a, float b, float c) {
    if(x <= a || x >= c) {
        return 0.0f;
    } else if(x == b) {
        return 1.0f;
    } else if(x < b) {
        return (x - a) / (b - a);
    } else {
        return (c - x) / (c - b);
    }
}

/**
 * @brief Karnik-Mendel Type Reduction Algorithm
 * @param firing_strengths_lower: Array of lower firing strengths
 * @param firing_strengths_upper: Array of upper firing strengths
 * @param consequent_centers: Array of consequent centers
 * @param num_rules: Number of rules
 * @return: Type-reduced crisp output
 */
static float KarnikMendelTypeReduction(float* firing_strengths_lower, float* firing_strengths_upper,
                                      float* consequent_centers, int num_rules) {
    /* Initialize arrays for sorting */
    int indices[49];
    float y_sorted[49];

    /* Copy and prepare data for sorting */
    for(int i = 0; i < num_rules; i++) {
        indices[i] = i;
        y_sorted[i] = consequent_centers[i];
    }

    /* Sort consequent centers and maintain index mapping */
    BubbleSort(y_sorted, indices, num_rules);

    /* Compute left end point (y_l) */
    float y_l = 0.0f;
    float sum_numerator = 0.0f;
    float sum_denominator = 0.0f;

    for(int i = 0; i < num_rules; i++) {
        int idx = indices[i];
        sum_numerator += y_sorted[i] * firing_strengths_upper[idx];
        sum_denominator += firing_strengths_upper[idx];
    }

    if(sum_denominator > 0.0f) {
        y_l = sum_numerator / sum_denominator;
    }

    /* Find switch point for left computation */
    int k_l = 0;
    for(int i = 0; i < num_rules - 1; i++) {
        if(y_sorted[i] <= y_l && y_l < y_sorted[i + 1]) {
            k_l = i;
            break;
        }
    }

    /* Recompute y_l with proper firing strengths */
    sum_numerator = 0.0f;
    sum_denominator = 0.0f;

    for(int i = 0; i < num_rules; i++) {
        int idx = indices[i];
        float firing_strength = (i <= k_l) ? firing_strengths_upper[idx] : firing_strengths_lower[idx];
        sum_numerator += y_sorted[i] * firing_strength;
        sum_denominator += firing_strength;
    }

    if(sum_denominator > 0.0f) {
        y_l = sum_numerator / sum_denominator;
    }

    /* Compute right end point (y_r) */
    float y_r = 0.0f;
    sum_numerator = 0.0f;
    sum_denominator = 0.0f;

    for(int i = 0; i < num_rules; i++) {
        int idx = indices[i];
        sum_numerator += y_sorted[i] * firing_strengths_lower[idx];
        sum_denominator += firing_strengths_lower[idx];
    }

    if(sum_denominator > 0.0f) {
        y_r = sum_numerator / sum_denominator;
    }

    /* Find switch point for right computation */
    int k_r = num_rules - 1;
    for(int i = 0; i < num_rules - 1; i++) {
        if(y_sorted[i] <= y_r && y_r < y_sorted[i + 1]) {
            k_r = i;
            break;
        }
    }

    /* Recompute y_r with proper firing strengths */
    sum_numerator = 0.0f;
    sum_denominator = 0.0f;

    for(int i = 0; i < num_rules; i++) {
        int idx = indices[i];
        float firing_strength = (i <= k_r) ? firing_strengths_lower[idx] : firing_strengths_upper[idx];
        sum_numerator += y_sorted[i] * firing_strength;
        sum_denominator += firing_strength;
    }

    if(sum_denominator > 0.0f) {
        y_r = sum_numerator / sum_denominator;
    }

    /* Final type-reduced output (centroid defuzzification) */
    float crisp_output = (y_l + y_r) / 2.0f;

    return crisp_output;
}

/**
 * @brief Simple bubble sort for consequent centers with index tracking
 * @param array: Array to sort
 * @param indices: Index array to maintain mapping
 * @param n: Number of elements
 */
static void BubbleSort(float* array, int* indices, int n) {
    for(int i = 0; i < n - 1; i++) {
        for(int j = 0; j < n - i - 1; j++) {
            if(array[j] > array[j + 1]) {
                /* Swap array elements */
                float temp_val = array[j];
                array[j] = array[j + 1];
                array[j + 1] = temp_val;

                /* Swap corresponding indices */
                int temp_idx = indices[j];
                indices[j] = indices[j + 1];
                indices[j + 1] = temp_idx;
            }
        }
    }
}
