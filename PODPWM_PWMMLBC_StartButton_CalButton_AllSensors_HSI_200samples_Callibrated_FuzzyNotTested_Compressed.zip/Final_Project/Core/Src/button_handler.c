/**
 * @file button_handler.c
 * @brief Non-blocking button handler implementation
 */

#include "button_handler.h"
#include <stdio.h>
#include <string.h>

/* Global button handler structure */
ButtonHandler_t button_handler;

/* Internal function prototypes */
static void Button_Handler_Update_Single(ButtonID_t button_id);
static uint8_t Button_Handler_Read_GPIO(ButtonID_t button_id);
static void Button_Handler_Process_State_Machine(ButtonID_t button_id);

/**
 * @brief Initialize the button handler system
 */
void Button_Handler_Init(void) {
    /* Initialize button configurations */

    /* Start/Stop Button (PB9) */
    button_handler.config[BUTTON_START_STOP].gpio_port = GPIOB;
    button_handler.config[BUTTON_START_STOP].gpio_pin = GPIO_PIN_9;
    button_handler.config[BUTTON_START_STOP].active_low = 1;  // Active low (pullup)
    button_handler.config[BUTTON_START_STOP].name = "START_STOP";

    /* Mode Button (PB8) */
    button_handler.config[BUTTON_MODE].gpio_port = GPIOB;
    button_handler.config[BUTTON_MODE].gpio_pin = GPIO_PIN_8;
    button_handler.config[BUTTON_MODE].active_low = 1;  // Active low (pullup)
    button_handler.config[BUTTON_MODE].name = "MODE";

    /* Initialize runtime data */
    for(int i = 0; i < MAX_BUTTONS; i++) {
        button_handler.runtime[i].state = BUTTON_STATE_IDLE;
        button_handler.runtime[i].state_start_time = HAL_GetTick();
        button_handler.runtime[i].last_reading = 1;  // Assume released initially
        button_handler.runtime[i].stable_reading = 1;
        button_handler.runtime[i].pending_event = BUTTON_EVENT_NONE;
        button_handler.runtime[i].press_count = 0;
    }

    button_handler.initialized = 1;
    button_handler.last_update_time = HAL_GetTick();

    printf("Button Handler initialized - Non-blocking debounce system ready\r\n");
}

/**
 * @brief Update button states (call from main loop every 1-5ms)
 */
void Button_Handler_Update(void) {
    if(!button_handler.initialized) {
        return;
    }

    uint32_t current_time = HAL_GetTick();

    /* Update all buttons */
    for(int i = 0; i < MAX_BUTTONS; i++) {
        Button_Handler_Update_Single((ButtonID_t)i);
    }

    button_handler.last_update_time = current_time;
}

/**
 * @brief Check if a button event is pending
 */
ButtonEvent_t Button_Handler_Get_Event(ButtonID_t button_id) {
    if(button_id >= MAX_BUTTONS) {
        return BUTTON_EVENT_NONE;
    }

    return button_handler.runtime[button_id].pending_event;
}

/**
 * @brief Clear a pending button event
 */
void Button_Handler_Clear_Event(ButtonID_t button_id) {
    if(button_id >= MAX_BUTTONS) {
        return;
    }

    button_handler.runtime[button_id].pending_event = BUTTON_EVENT_NONE;
}

/**
 * @brief Get current button state
 */
ButtonState_t Button_Handler_Get_State(ButtonID_t button_id) {
    if(button_id >= MAX_BUTTONS) {
        return BUTTON_STATE_IDLE;
    }

    return button_handler.runtime[button_id].state;
}

/**
 * @brief Check if button is currently pressed (stable)
 */
uint8_t Button_Handler_Is_Pressed(ButtonID_t button_id) {
    if(button_id >= MAX_BUTTONS) {
        return 0;
    }

    ButtonState_t state = button_handler.runtime[button_id].state;
    return (state == BUTTON_STATE_PRESSED || state == BUTTON_STATE_LONG_PRESS);
}

/**
 * @brief Get button press statistics
 */
uint32_t Button_Handler_Get_Press_Count(ButtonID_t button_id) {
    if(button_id >= MAX_BUTTONS) {
        return 0;
    }

    return button_handler.runtime[button_id].press_count;
}

/**
 * @brief Get button name for debugging
 */
const char* Button_Handler_Get_Name(ButtonID_t button_id) {
    if(button_id >= MAX_BUTTONS) {
        return "UNKNOWN";
    }

    return button_handler.config[button_id].name;
}

/* Internal Functions */

/**
 * @brief Update a single button
 */
static void Button_Handler_Update_Single(ButtonID_t button_id) {
    if(button_id >= MAX_BUTTONS) {
        return;
    }

    ButtonRuntime_t* runtime = &button_handler.runtime[button_id];

    /* Read current GPIO state */
    uint8_t current_reading = Button_Handler_Read_GPIO(button_id);

    /* Store reading for next iteration */
    runtime->last_reading = current_reading;

    /* Process state machine */
    Button_Handler_Process_State_Machine(button_id);
}

/**
 * @brief Read GPIO state for a button
 */
static uint8_t Button_Handler_Read_GPIO(ButtonID_t button_id) {
    if(button_id >= MAX_BUTTONS) {
        return 1;  // Default to not pressed
    }

    ButtonConfig_t* config = &button_handler.config[button_id];
    GPIO_PinState pin_state = HAL_GPIO_ReadPin(config->gpio_port, config->gpio_pin);

    /* Convert to logical reading based on active low/high configuration */
    if(config->active_low) {
        return (pin_state == GPIO_PIN_RESET) ? 1 : 0;  // Pressed = 1, Released = 0
    } else {
        return (pin_state == GPIO_PIN_SET) ? 1 : 0;    // Pressed = 1, Released = 0
    }
}

/**
 * @brief Process button state machine
 */
static void Button_Handler_Process_State_Machine(ButtonID_t button_id) {
    if(button_id >= MAX_BUTTONS) {
        return;
    }

    ButtonRuntime_t* runtime = &button_handler.runtime[button_id];
    uint32_t current_time = HAL_GetTick();
    uint32_t time_in_state = current_time - runtime->state_start_time;
    uint8_t current_reading = runtime->last_reading;

    switch(runtime->state) {
        case BUTTON_STATE_IDLE:
            if(current_reading == 1) {  // Button pressed
                runtime->state = BUTTON_STATE_DEBOUNCE;
                runtime->state_start_time = current_time;
            }
            break;

        case BUTTON_STATE_DEBOUNCE:
            if(time_in_state >= BUTTON_DEBOUNCE_TIME_MS) {
                if(current_reading == 1) {  // Still pressed after debounce
                    runtime->state = BUTTON_STATE_PRESSED;
                    runtime->state_start_time = current_time;
                    runtime->stable_reading = 1;
                    runtime->pending_event = BUTTON_EVENT_PRESS;
                    runtime->press_count++;

                    printf("Button %s: PRESS event (count: %lu)\r\n",
                           Button_Handler_Get_Name(button_id),
                           runtime->press_count);
                } else {  // Released during debounce (false trigger)
                    runtime->state = BUTTON_STATE_IDLE;
                    runtime->state_start_time = current_time;
                }
            }
            /* If still in debounce time, stay in this state */
            break;

        case BUTTON_STATE_PRESSED:
            if(current_reading == 0) {  // Button released
                runtime->state = BUTTON_STATE_IDLE;
                runtime->state_start_time = current_time;
                runtime->stable_reading = 0;
                runtime->pending_event = BUTTON_EVENT_RELEASE;

                printf("Button %s: RELEASE event\r\n",
                       Button_Handler_Get_Name(button_id));
            } else if(time_in_state >= BUTTON_LONG_PRESS_TIME_MS) {
                runtime->state = BUTTON_STATE_LONG_PRESS;
                runtime->state_start_time = current_time;
                runtime->pending_event = BUTTON_EVENT_LONG_PRESS;

                printf("Button %s: LONG_PRESS event\r\n",
                       Button_Handler_Get_Name(button_id));
            }
            break;

        case BUTTON_STATE_LONG_PRESS:
            if(current_reading == 0) {  // Button released after long press
                runtime->state = BUTTON_STATE_IDLE;
                runtime->state_start_time = current_time;
                runtime->stable_reading = 0;
                runtime->pending_event = BUTTON_EVENT_RELEASE;

                printf("Button %s: RELEASE after long press\r\n",
                       Button_Handler_Get_Name(button_id));
            }
            break;
    }
}
