/**
 * @file pod_pwm.c
 * @brief Phase Opposition Disposition PWM for 7-Level PUCI Inverter Implementation
 */

#include "pod_pwm.h"
#include "pwm_mlbc.h"
#include "math.h"
#include "stdio.h"

/* Global POD PWM structure */
POD_PWM_TypeDef pod_pwm;

/* Carrier band definitions for POD arrangement */
static const CarrierBand CarrierBands[6] = {
    {3.0f, 2.0f},   // Carrier 1: +3 to +2
    {2.0f, 1.0f},   // Carrier 2: +2 to +1
    {1.0f, 0.0f},   // Carrier 3: +1 to 0
    {0.0f, -1.0f},  // Carrier 4: 0 to -1
    {-1.0f, -2.0f}, // Carrier 5: -1 to -2
    {-2.0f, -3.0f}  // Carrier 6: -2 to -3
};

/* Switching patterns for 7-level PUCI inverter */
/* Pattern arrangement: [level+3][pattern][switch] */
/* Switches: S1, S2, S3, S4, S5, S6, S7, S8 */
static const uint8_t SwitchingPatterns[7][3][8] = {
    // Level +3 (index 0)
    {{1,0,0,0,0,1,1,1}, {1,0,0,0,0,1,1,1}, {1,0,0,0,0,1,1,1}},
    // Level +2 (index 1)
    {{1,0,1,0,0,1,0,1}, {1,1,0,0,0,0,1,1}, {1,0,0,1,0,1,1,0}},
    // Level +1 (index 2)
    {{1,0,1,1,0,1,0,0}, {1,1,0,1,0,0,1,0}, {1,1,1,0,0,0,0,1}},
    // Level 0 (index 3)
    {{0,0,0,0,1,1,1,1}, {0,0,0,0,1,1,1,1}, {0,0,0,0,1,1,1,1}},
    // Level -1 (index 4)
    {{0,1,0,0,1,0,1,1}, {0,0,1,0,1,1,0,1}, {0,0,0,1,1,1,1,0}},
    // Level -2 (index 5)
    {{0,1,0,1,1,0,1,0}, {0,0,1,1,1,1,0,0}, {0,1,1,0,1,0,0,1}},
    // Level -3 (index 6)
    {{0,1,1,1,1,0,0,0}, {0,1,1,1,1,0,0,0}, {0,1,1,1,1,0,0,0}}
};

/**
 * @brief Initialize POD PWM system
 */
void POD_PWM_Init(void) {
    /* Initialize structure */
    pod_pwm.reference = 0.0f;
    pod_pwm.phase = 0.0f;
    pod_pwm.modulation_index = 1.0f;  // Default modulation index
    pod_pwm.mode = POD_PWM_MODE_OPEN_LOOP;
    pod_pwm.current_level = 0;
    pod_pwm.target_level = 0;
    pod_pwm.manual_level = 0;
    pod_pwm.pattern_index = 0;
    pod_pwm.debug_counter = 0;
    pod_pwm.debug_flag = 0;  // Debug disabled by default
    pod_pwm.system_enabled = 0;  // System disabled by default

    /* Initialize chunk-based debug system */
    pod_pwm.debug_buffer_index = 0;
    pod_pwm.debug_buffer_ready = 0;
    pod_pwm.debug_cycles_count = 0;

    /* Initialize carriers to zero */
    for(int i = 0; i < 6; i++) {
        pod_pwm.carriers[i] = 0.0f;
    }

    /* Start PWM timers */
    HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_1);
    HAL_TIMEx_PWMN_Start(&htim1, TIM_CHANNEL_1);
    HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_2);
    HAL_TIMEx_PWMN_Start(&htim1, TIM_CHANNEL_2);

    HAL_TIM_PWM_Start(&htim8, TIM_CHANNEL_1);
    HAL_TIMEx_PWMN_Start(&htim8, TIM_CHANNEL_1);
    HAL_TIM_PWM_Start(&htim8, TIM_CHANNEL_2);
    HAL_TIMEx_PWMN_Start(&htim8, TIM_CHANNEL_2);

    /* Initialize with level 0 (all switches off state) */
    POD_PWM_Apply_Switching_States(0, 0);
}

/**
 * @brief Update reference and carriers (called from TIM3 interrupt)
 */
void POD_PWM_Update_Reference(void) {
    /* Only update if system is enabled */
    if(!pod_pwm.system_enabled) {
        /* System disabled - set everything to zero */
        pod_pwm.reference = 0.0f;
        for(int i = 0; i < 6; i++) {
            pod_pwm.carriers[i] = 0.0f;
        }
        pod_pwm.current_level = 0;
        pod_pwm.debug_counter++;
        return;
    }

    /* Update phase */
    pod_pwm.phase += PHASE_INCREMENT;
    if(pod_pwm.phase >= TWO_PI) {
        pod_pwm.phase -= TWO_PI;
    }

    /* Generate reference based on mode */
    switch(pod_pwm.mode) {
        case POD_PWM_MODE_MANUAL_LEVEL:
            /* Direct level control - no reference needed */
            pod_pwm.current_level = pod_pwm.manual_level;
            pod_pwm.reference = (float)pod_pwm.manual_level;  // For debug only
            break;

        default:
            /* Generate sine reference with -90° phase shift */
            /* This makes the minimum occur at phase = 0°, making pattern switching cleaner */
            float sine_angle = pod_pwm.phase - (PI / 2.0f);  // -90° shift
            pod_pwm.reference = pod_pwm.modulation_index * 3.0f * sinf(sine_angle);

            /* Generate carriers */
            POD_PWM_Generate_Carriers();

            /* Determine level from reference-carrier comparison */
            pod_pwm.target_level = POD_PWM_Determine_Level();

            /* Apply level transition limiting */
            pod_pwm.current_level = POD_PWM_Limit_Level_Transition(pod_pwm.target_level);
            break;
    }

    /* Handle pattern switching */
    POD_PWM_Handle_Pattern_Switching();

    /* Apply switching states if system is enabled */
    if(pod_pwm.system_enabled) {
        POD_PWM_Apply_Switching_States(pod_pwm.current_level, pod_pwm.pattern_index);
    } else {
        /* System disabled - set all switches to safe state (level 0) */
        POD_PWM_Apply_Switching_States(0, 0);
    }

    /* Store debug data in buffer if enabled and buffer not full */
    if(pod_pwm.debug_flag && !pod_pwm.debug_buffer_ready && pod_pwm.system_enabled) {
        uint32_t buffer_size = DEBUG_SAMPLES_PER_CYCLE * DEBUG_CYCLES_TO_CAPTURE;

        if(pod_pwm.debug_buffer_index < buffer_size) {
            /* Store current sample */
            pod_pwm.debug_buffer[pod_pwm.debug_buffer_index].reference = pod_pwm.reference;
            for(int i = 0; i < 6; i++) {
                pod_pwm.debug_buffer[pod_pwm.debug_buffer_index].carriers[i] = pod_pwm.carriers[i];
            }
            pod_pwm.debug_buffer[pod_pwm.debug_buffer_index].level = pod_pwm.current_level;
            pod_pwm.debug_buffer[pod_pwm.debug_buffer_index].pattern_index = pod_pwm.pattern_index;

            pod_pwm.debug_buffer_index++;

            /* Check if buffer is full */
            if(pod_pwm.debug_buffer_index >= buffer_size) {
                pod_pwm.debug_buffer_ready = 1;
            }
        }
    }

    /* Increment debug counter */
    pod_pwm.debug_counter++;
}

/**
 * @brief Generate triangular carriers for POD arrangement
 * Uses hardware timer counter method with POD phase arrangement
 */
void POD_PWM_Generate_Carriers(void) {
    /* Get hardware timer counter for triangular wave generation */
    uint32_t counter_value = __HAL_TIM_GET_COUNTER(&htim1);  // Use TIM1 counter directly
    uint32_t timer_period = htim1.Init.Period;               // Should be 35999
    uint32_t timer_half_period = timer_period / 2;
    float timer_half_period_f = (float)timer_period / 2.0f;

    /* Generate POD carriers */
    for(int i = 0; i < 6; i++) {
        float band_center = (CarrierBands[i].upper_limit + CarrierBands[i].lower_limit) / 2.0f;
        float band_amplitude = (CarrierBands[i].upper_limit - CarrierBands[i].lower_limit);

        /* POD arrangement: positive carriers (0,1,2) use direct triangle,
           negative carriers (3,4,5) use 180° shifted triangle */
        uint32_t shifted_counter = counter_value;
        if(i >= 3) {  // Negative carriers (4,5,6) get 180° phase shift
            shifted_counter = (shifted_counter + timer_half_period) % timer_period;
        }

        /* Generate triangle wave (0 to 1) using proven method */
        float triangle;
        if(shifted_counter < timer_half_period) {
            triangle = (float)shifted_counter / timer_half_period_f;  // Rising
        } else {
            triangle = 2.0f - ((float)shifted_counter / timer_half_period_f);  // Falling
        }

        /* Scale triangle to carrier band */
        pod_pwm.carriers[i] = band_center + band_amplitude * (triangle - 0.5f);

        /* Clamp carriers to their respective bands for safety */
        if(pod_pwm.carriers[i] > CarrierBands[i].upper_limit) {
            pod_pwm.carriers[i] = CarrierBands[i].upper_limit;
        }
        if(pod_pwm.carriers[i] < CarrierBands[i].lower_limit) {
            pod_pwm.carriers[i] = CarrierBands[i].lower_limit;
        }
    }
}

/**
 * @brief Determine output level based on reference and carrier comparison
 */
int8_t POD_PWM_Determine_Level(void) {
    float ref = pod_pwm.reference;

    /* Level determination logic - handles overmodulation (MI > 1.0) */
    /* Reference can be up to ±6.0 with MI = 2.0, but output is clamped to ±3 levels */
    if(ref >= 2.5f) return 3;       // Includes overmodulation region
    if(ref >= 1.5f) return 2;
    if(ref >= 0.5f) return 1;
    if(ref >= -0.5f) return 0;
    if(ref >= -1.5f) return -1;
    if(ref >= -2.5f) return -2;
    return -3;                      // All values below -2.5 map to level -3
}

/**
 * @brief Handle pattern switching based on phase wrap-around (clean detection)
 */
void POD_PWM_Handle_Pattern_Switching(void) {
    /* Detect when phase wraps around from 2π back to 0 */
    /* With -90° shifted sine, this happens exactly at the reference minimum */
    static float previous_phase = 0.0f;

    /* Check if phase has wrapped around (completed full cycle) */
    if(previous_phase > (TWO_PI - PHASE_INCREMENT) && pod_pwm.phase < PHASE_INCREMENT) {
        /* Full cycle completed - switch to next pattern */
        pod_pwm.pattern_index = (pod_pwm.pattern_index + 1) % NUM_PATTERNS;
    }

    /* Store current phase for next comparison */
    previous_phase = pod_pwm.phase;
}

/**
 * @brief Apply switching states to hardware timers
 */
void POD_PWM_Apply_Switching_States(int8_t level, uint8_t pattern) {
    SwitchingState state = POD_PWM_Get_Switching_State(level, pattern);

    /* TIM1 Channel 1 (S1) and its complement (S5) */
    if(state.S1) {
        __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_1, htim1.Init.Period - 1);
    } else {
        __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_1, 0);
    }

    /* TIM1 Channel 2 (S2) and its complement (S6) */
    if(state.S2) {
        __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_2, htim1.Init.Period - 1);
    } else {
        __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_2, 0);
    }

    /* TIM8 Channel 1 (S3) and its complement (S7) */
    if(state.S3) {
        __HAL_TIM_SET_COMPARE(&htim8, TIM_CHANNEL_1, htim8.Init.Period - 1);
    } else {
        __HAL_TIM_SET_COMPARE(&htim8, TIM_CHANNEL_1, 0);
    }

    /* TIM8 Channel 2 (S4) and its complement (S8) */
    if(state.S4) {
        __HAL_TIM_SET_COMPARE(&htim8, TIM_CHANNEL_2, htim8.Init.Period - 1);
    } else {
        __HAL_TIM_SET_COMPARE(&htim8, TIM_CHANNEL_2, 0);
    }
}

/**
 * @brief Get switching state for given level and pattern
 */
SwitchingState POD_PWM_Get_Switching_State(int8_t level, uint8_t pattern) {
    SwitchingState state;

    /* Convert level (-3 to +3) to array index (0 to 6) */
    int level_index = level + 3;

    /* Bounds checking */
    if(level_index < 0) level_index = 0;
    if(level_index > 6) level_index = 6;
    if(pattern >= NUM_PATTERNS) pattern = 0;

    /* Get switching states from lookup table */
    state.S1 = SwitchingPatterns[level_index][pattern][0];
    state.S2 = SwitchingPatterns[level_index][pattern][1];
    state.S3 = SwitchingPatterns[level_index][pattern][2];
    state.S4 = SwitchingPatterns[level_index][pattern][3];
    state.S5 = SwitchingPatterns[level_index][pattern][4];
    state.S6 = SwitchingPatterns[level_index][pattern][5];
    state.S7 = SwitchingPatterns[level_index][pattern][6];
    state.S8 = SwitchingPatterns[level_index][pattern][7];

    return state;
}

/**
 * @brief Limit level transitions to ±1 step maximum
 */
int8_t POD_PWM_Limit_Level_Transition(int8_t target_level) {
    int8_t level_diff = target_level - pod_pwm.current_level;

    if(level_diff > 1) {
        return pod_pwm.current_level + 1;
    } else if(level_diff < -1) {
        return pod_pwm.current_level - 1;
    } else {
        return target_level;
    }
}

/**
 * @brief Set operation mode
 */
void POD_PWM_Set_Mode(POD_PWM_Mode_t mode) {
    pod_pwm.mode = mode;
}

/**
 * @brief Set manual modulation index (open loop mode)
 */
void POD_PWM_Set_Manual_MI(float mi) {
    if(mi < 0.0f) mi = 0.0f;
    if(mi > MAX_MODULATION_INDEX) mi = MAX_MODULATION_INDEX;  // Allow up to 1.25
    pod_pwm.modulation_index = mi;
}

/**
 * @brief Set modulation index from fuzzy controller (closed loop mode)
 */
void POD_PWM_Set_Fuzzy_MI(float mi) {
    if(mi < 0.0f) mi = 0.0f;
    if(mi > MAX_MODULATION_INDEX) mi = MAX_MODULATION_INDEX;  // Allow up to 1.25
    pod_pwm.modulation_index = mi;
}

/**
 * @brief Set manual level directly (manual level mode)
 */
void POD_PWM_Set_Manual_Level(int8_t level) {
    if(level < -3) level = -3;
    if(level > 3) level = 3;
    pod_pwm.manual_level = level;
}

/**
 * @brief Enable/disable the PWM system
 */
void POD_PWM_Enable(uint8_t enable) {
    pod_pwm.system_enabled = enable;
    if(!enable) {
        /* When disabling, immediately set level to 0 */
        POD_PWM_Apply_Switching_States(0, 0);
        printf("POD PWM disabled - all switches set to 0\r\n");
    } else {
        printf("POD PWM enabled\r\n");
    }
}

/**
 * @brief Set debug flag
 */
void POD_PWM_Set_Debug(uint8_t flag) {
    pod_pwm.debug_flag = flag;
    if(flag) {
        pod_pwm.debug_counter = 0;  // Reset counter when enabling debug
    }
}

/**
 * @brief Transmit debug data via UART (call from main loop)
 * Clean chunk transmission with debug counter reset
 */
void POD_PWM_Debug_Transmit(void) {
    if(pod_pwm.debug_flag && pod_pwm.debug_buffer_ready) {
        /* Transmit all buffered data */
        for(uint32_t i = 0; i < pod_pwm.debug_buffer_index; i++) {
            printf("%lu,%.3f,%.3f,%.3f,%.3f,%.3f,%.3f,%.3f,%d,%d\r\n",
                i,
                pod_pwm.debug_buffer[i].reference,
                pod_pwm.debug_buffer[i].carriers[0],
                pod_pwm.debug_buffer[i].carriers[1],
                pod_pwm.debug_buffer[i].carriers[2],
                pod_pwm.debug_buffer[i].carriers[3],
                pod_pwm.debug_buffer[i].carriers[4],
                pod_pwm.debug_buffer[i].carriers[5],
                pod_pwm.debug_buffer[i].level,
                pod_pwm.debug_buffer[i].pattern_index
            );
        }

        /* Reset buffer for next capture */
        pod_pwm.debug_buffer_index = 0;
        pod_pwm.debug_buffer_ready = 0;
    }
}

/**
 * @brief Reset debug counter (call when starting system)
 */
void POD_PWM_Reset_Debug_Counter(void) {
    pod_pwm.debug_counter = 0;
    pod_pwm.debug_buffer_index = 0;
    pod_pwm.debug_buffer_ready = 0;
}
