/**
 * @file fuzzy_init.c
 * @brief Initialization functions for type-2 fuzzy logic controller
 * @author afuanandi
 */

#include "fuzzy_init.h"
#include "fuzzy_structures.h"
#include <stdlib.h>
#include <string.h>

/**
 * @brief Initialize the fuzzy system with membership functions and rules
 * @param system Pointer to fuzzy system structure
 * @return 0 if successful, -1 if error
 */
int InitializeFuzzySystem(FuzzySystem* system) {
    if (system == NULL) {
        return -1;
    }

    // Initialize Input 1: Error
    strcpy(system->inputs[0].name, "Error");
    system->inputs[0].min = -17.0f;
    system->inputs[0].max = 17.0f;
    system->inputs[0].numMFs = 7;
    system->inputs[0].mfs = (TriangularMF*)malloc(7 * sizeof(TriangularMF));

    if (system->inputs[0].mfs == NULL) {
        return -1;
    }

    // Define membership functions for Input 1: Error
    // MF1='NB'
    system->inputs[0].mfs[0].a = -21.7222f;
    system->inputs[0].mfs[0].b = -17.0f;
    system->inputs[0].mfs[0].c = -11.3333f;
    system->inputs[0].mfs[0].upper = 1.0f;     // Updated to 1.0
    system->inputs[0].mfs[0].lower = 0.5f;     // Added separate lower value
    system->inputs[0].mfs[0].lowerUncertainty = 0.2f;
    system->inputs[0].mfs[0].upperUncertainty = 0.2f;

    // MF2='NM'
    system->inputs[0].mfs[1].a = -17.0f;
    system->inputs[0].mfs[1].b = -11.3333f;
    system->inputs[0].mfs[1].c = -5.66667f;
    system->inputs[0].mfs[1].upper = 1.0f;     // Updated to 1.0
    system->inputs[0].mfs[1].lower = 0.5f;     // Added separate lower value
    system->inputs[0].mfs[1].lowerUncertainty = 0.45f;  // Updated to 0.45
    system->inputs[0].mfs[1].upperUncertainty = 0.45f;  // Updated to 0.45

    // MF3='NS'
    system->inputs[0].mfs[2].a = -11.3333f;
    system->inputs[0].mfs[2].b = -5.66667f;
    system->inputs[0].mfs[2].c = 0.0f;
    system->inputs[0].mfs[2].upper = 1.0f;     // Updated to 1.0
    system->inputs[0].mfs[2].lower = 0.5f;     // Added separate lower value
    system->inputs[0].mfs[2].lowerUncertainty = 0.7f;   // Updated to 0.7
    system->inputs[0].mfs[2].upperUncertainty = 0.7f;   // Updated to 0.7

    // MF4='Z'
    system->inputs[0].mfs[3].a = -5.66667f;
    system->inputs[0].mfs[3].b = 0.0f;
    system->inputs[0].mfs[3].c = 5.66667f;
    system->inputs[0].mfs[3].upper = 1.0f;     // Updated to 1.0
    system->inputs[0].mfs[3].lower = 0.5f;     // Added separate lower value
    system->inputs[0].mfs[3].lowerUncertainty = 0.95f;  // Updated to 0.95
    system->inputs[0].mfs[3].upperUncertainty = 0.95f;  // Updated to 0.95

    // MF5='PS'
    system->inputs[0].mfs[4].a = 0.0f;
    system->inputs[0].mfs[4].b = 5.66667f;
    system->inputs[0].mfs[4].c = 11.3333f;
    system->inputs[0].mfs[4].upper = 1.0f;     // Updated to 1.0
    system->inputs[0].mfs[4].lower = 0.5f;     // Added separate lower value
    system->inputs[0].mfs[4].lowerUncertainty = 0.7f;   // Updated to 0.7
    system->inputs[0].mfs[4].upperUncertainty = 0.7f;   // Updated to 0.7

    // MF6='PM'
    system->inputs[0].mfs[5].a = 5.66667f;
    system->inputs[0].mfs[5].b = 11.3333f;
    system->inputs[0].mfs[5].c = 17.0f;
    system->inputs[0].mfs[5].upper = 1.0f;     // Updated to 1.0
    system->inputs[0].mfs[5].lower = 0.5f;     // Added separate lower value
    system->inputs[0].mfs[5].lowerUncertainty = 0.45f;  // Updated to 0.45
    system->inputs[0].mfs[5].upperUncertainty = 0.45f;  // Updated to 0.45

    // MF7='PB'
    system->inputs[0].mfs[6].a = 11.3333f;
    system->inputs[0].mfs[6].b = 17.0f;
    system->inputs[0].mfs[6].c = 21.7222f;
    system->inputs[0].mfs[6].upper = 1.0f;     // Updated to 1.0
    system->inputs[0].mfs[6].lower = 0.5f;     // Added separate lower value
    system->inputs[0].mfs[6].lowerUncertainty = 0.2f;
    system->inputs[0].mfs[6].upperUncertainty = 0.2f;

    // Initialize Input 2: dError (following the same pattern)
    strcpy(system->inputs[1].name, "dError");
    system->inputs[1].min = -17.0f;
    system->inputs[1].max = 17.0f;
    system->inputs[1].numMFs = 7;
    system->inputs[1].mfs = (TriangularMF*)malloc(7 * sizeof(TriangularMF));

    if (system->inputs[1].mfs == NULL) {
        free(system->inputs[0].mfs);
        return -1;
    }

    // Define membership functions for Input 2: dError (same pattern as Input 1)
    // MF1='NB'
    system->inputs[1].mfs[0].a = -21.7222f;
    system->inputs[1].mfs[0].b = -17.0f;
    system->inputs[1].mfs[0].c = -11.3333f;
    system->inputs[1].mfs[0].upper = 1.0f;     // Updated to 1.0
    system->inputs[1].mfs[0].lower = 0.5f;     // Added separate lower value
    system->inputs[1].mfs[0].lowerUncertainty = 0.2f;
    system->inputs[1].mfs[0].upperUncertainty = 0.2f;

    // MF2='NM'
    system->inputs[1].mfs[1].a = -17.0f;
    system->inputs[1].mfs[1].b = -11.3333f;
    system->inputs[1].mfs[1].c = -5.66667f;
    system->inputs[1].mfs[1].upper = 1.0f;     // Updated to 1.0
    system->inputs[1].mfs[1].lower = 0.5f;     // Added separate lower value
    system->inputs[1].mfs[1].lowerUncertainty = 0.45f;  // Updated to 0.45
    system->inputs[1].mfs[1].upperUncertainty = 0.45f;  // Updated to 0.45

    // MF3='NS'
    system->inputs[1].mfs[2].a = -11.3333f;
    system->inputs[1].mfs[2].b = -5.66667f;
    system->inputs[1].mfs[2].c = 0.0f;
    system->inputs[1].mfs[2].upper = 1.0f;     // Updated to 1.0
    system->inputs[1].mfs[2].lower = 0.5f;     // Added separate lower value
    system->inputs[1].mfs[2].lowerUncertainty = 0.7f;   // Updated to 0.7
    system->inputs[1].mfs[2].upperUncertainty = 0.7f;   // Updated to 0.7

    // MF4='Z'
    system->inputs[1].mfs[3].a = -5.66667f;
    system->inputs[1].mfs[3].b = 0.0f;
    system->inputs[1].mfs[3].c = 5.66667f;
    system->inputs[1].mfs[3].upper = 1.0f;     // Updated to 1.0
    system->inputs[1].mfs[3].lower = 0.5f;     // Added separate lower value
    system->inputs[1].mfs[3].lowerUncertainty = 0.95f;  // Updated to 0.95
    system->inputs[1].mfs[3].upperUncertainty = 0.95f;  // Updated to 0.95

    // MF5='PS'
    system->inputs[1].mfs[4].a = 0.0f;
    system->inputs[1].mfs[4].b = 5.66667f;
    system->inputs[1].mfs[4].c = 11.3333f;
    system->inputs[1].mfs[4].upper = 1.0f;     // Updated to 1.0
    system->inputs[1].mfs[4].lower = 0.5f;     // Added separate lower value
    system->inputs[1].mfs[4].lowerUncertainty = 0.7f;   // Updated to 0.7
    system->inputs[1].mfs[4].upperUncertainty = 0.7f;   // Updated to 0.7

    // MF6='PM'
    system->inputs[1].mfs[5].a = 5.66667f;
    system->inputs[1].mfs[5].b = 11.3333f;
    system->inputs[1].mfs[5].c = 17.0f;
    system->inputs[1].mfs[5].upper = 1.0f;     // Updated to 1.0
    system->inputs[1].mfs[5].lower = 0.5f;     // Added separate lower value
    system->inputs[1].mfs[5].lowerUncertainty = 0.45f;  // Updated to 0.45
    system->inputs[1].mfs[5].upperUncertainty = 0.45f;  // Updated to 0.45

    // MF7='PB'
    system->inputs[1].mfs[6].a = 11.3333f;
    system->inputs[1].mfs[6].b = 17.0f;
    system->inputs[1].mfs[6].c = 21.7222f;
    system->inputs[1].mfs[6].upper = 1.0f;     // Updated to 1.0
    system->inputs[1].mfs[6].lower = 0.5f;     // Added separate lower value
    system->inputs[1].mfs[6].lowerUncertainty = 0.2f;
    system->inputs[1].mfs[6].upperUncertainty = 0.2f;

    // Initialize Output: mi (following same pattern)
    strcpy(system->output.name, "mi");
    system->output.min = 0.0f;
    system->output.max = 2.0f;
    system->output.numMFs = 7;
    system->output.mfs = (TriangularMF*)malloc(7 * sizeof(TriangularMF));

    if (system->output.mfs == NULL) {
        free(system->inputs[0].mfs);
        free(system->inputs[1].mfs);
        return -1;
    }

    // Define membership functions for Output: mi
    // MF1='NB'
    system->output.mfs[0].a = -0.277778f;
    system->output.mfs[0].b = 0.0f;
    system->output.mfs[0].c = 0.333333f;
    system->output.mfs[0].upper = 1.0f;     // Updated to 1.0
    system->output.mfs[0].lower = 0.5f;     // Added separate lower value
    system->output.mfs[0].lowerUncertainty = 0.2f;
    system->output.mfs[0].upperUncertainty = 0.2f;

    // MF2='NM'
    system->output.mfs[1].a = 0.0f;
    system->output.mfs[1].b = 0.333333f;
    system->output.mfs[1].c = 0.666667f;
    system->output.mfs[1].upper = 1.0f;     // Updated to 1.0
    system->output.mfs[1].lower = 0.5f;     // Added separate lower value
    system->output.mfs[1].lowerUncertainty = 0.45f;  // Updated to 0.45
    system->output.mfs[1].upperUncertainty = 0.45f;  // Updated to 0.45

    // MF3='NS'
    system->output.mfs[2].a = 0.333333f;
    system->output.mfs[2].b = 0.666667f;
    system->output.mfs[2].c = 1.0f;
    system->output.mfs[2].upper = 1.0f;     // Updated to 1.0
    system->output.mfs[2].lower = 0.5f;     // Added separate lower value
    system->output.mfs[2].lowerUncertainty = 0.7f;   // Updated to 0.7
    system->output.mfs[2].upperUncertainty = 0.7f;   // Updated to 0.7

    // MF4='Z'
    system->output.mfs[3].a = 0.666667f;
    system->output.mfs[3].b = 1.0f;
    system->output.mfs[3].c = 1.33333f;
    system->output.mfs[3].upper = 1.0f;     // Updated to 1.0
    system->output.mfs[3].lower = 0.5f;     // Added separate lower value
    system->output.mfs[3].lowerUncertainty = 0.95f;  // Updated to 0.95
    system->output.mfs[3].upperUncertainty = 0.95f;  // Updated to 0.95

    // MF5='PS'
    system->output.mfs[4].a = 1.0f;
    system->output.mfs[4].b = 1.33333f;
    system->output.mfs[4].c = 1.66667f;
    system->output.mfs[4].upper = 1.0f;     // Updated to 1.0
    system->output.mfs[4].lower = 0.5f;     // Added separate lower value
    system->output.mfs[4].lowerUncertainty = 0.7f;   // Updated to 0.7
    system->output.mfs[4].upperUncertainty = 0.7f;   // Updated to 0.7

    // MF6='PM'
    system->output.mfs[5].a = 1.33333f;
    system->output.mfs[5].b = 1.66667f;
    system->output.mfs[5].c = 2.0f;
    system->output.mfs[5].upper = 1.0f;     // Updated to 1.0
    system->output.mfs[5].lower = 0.5f;     // Added separate lower value
    system->output.mfs[5].lowerUncertainty = 0.45f;  // Updated to 0.45
    system->output.mfs[5].upperUncertainty = 0.45f;  // Updated to 0.45

    // MF7='PB'
    system->output.mfs[6].a = 1.66667f;
    system->output.mfs[6].b = 2.0f;
    system->output.mfs[6].c = 2.27778f;
    system->output.mfs[6].upper = 1.0f;     // Updated to 1.0
    system->output.mfs[6].lower = 0.5f;     // Added separate lower value
    system->output.mfs[6].lowerUncertainty = 0.2f;
    system->output.mfs[6].upperUncertainty = 0.2f;

    // Initialize rules
    system->numRules = 49;
    system->rules = (FuzzyRule*)malloc(49 * sizeof(FuzzyRule));

    if (system->rules == NULL) {
        free(system->inputs[0].mfs);
        free(system->inputs[1].mfs);
        free(system->output.mfs);
        return -1;
    }

    // Define rules based on your .fis file
    // Row 1
    system->rules[0] = (FuzzyRule){0, 0, 0, 1.0f};  // 1 1, 1
    system->rules[1] = (FuzzyRule){0, 1, 0, 1.0f};  // 1 2, 1
    system->rules[2] = (FuzzyRule){0, 2, 1, 1.0f};  // 1 3, 2
    system->rules[3] = (FuzzyRule){0, 3, 1, 1.0f};  // 1 4, 2
    system->rules[4] = (FuzzyRule){0, 4, 2, 1.0f};  // 1 5, 3 - Updated
    system->rules[5] = (FuzzyRule){0, 5, 2, 1.0f};  // 1 6, 3 - Updated
    system->rules[6] = (FuzzyRule){0, 6, 3, 1.0f};  // 1 7, 4 - Updated

    // Row 2
    system->rules[7] = (FuzzyRule){1, 0, 0, 1.0f};  // 2 1, 1
    system->rules[8] = (FuzzyRule){1, 1, 1, 1.0f};  // 2 2, 2 - Updated
    system->rules[9] = (FuzzyRule){1, 2, 1, 1.0f};  // 2 3, 2
    system->rules[10] = (FuzzyRule){1, 3, 2, 1.0f}; // 2 4, 3 - Updated
    system->rules[11] = (FuzzyRule){1, 4, 2, 1.0f}; // 2 5, 3
    system->rules[12] = (FuzzyRule){1, 5, 3, 1.0f}; // 2 6, 4 - Updated
    system->rules[13] = (FuzzyRule){1, 6, 4, 1.0f}; // 2 7, 5 - Updated

    // Row 3
    system->rules[14] = (FuzzyRule){2, 0, 1, 1.0f}; // 3 1, 2
    system->rules[15] = (FuzzyRule){2, 1, 1, 1.0f}; // 3 2, 2
    system->rules[16] = (FuzzyRule){2, 2, 2, 1.0f}; // 3 3, 3 - Updated
    system->rules[17] = (FuzzyRule){2, 3, 2, 1.0f}; // 3 4, 3 - Updated
    system->rules[18] = (FuzzyRule){2, 4, 3, 1.0f}; // 3 5, 4 - Updated
    system->rules[19] = (FuzzyRule){2, 5, 4, 1.0f}; // 3 6, 5 - Updated
    system->rules[20] = (FuzzyRule){2, 6, 4, 1.0f}; // 3 7, 5 - Updated

    // Row 4
    system->rules[21] = (FuzzyRule){3, 0, 1, 1.0f}; // 4 1, 2 - Updated
    system->rules[22] = (FuzzyRule){3, 1, 2, 1.0f}; // 4 2, 3 - Updated
    system->rules[23] = (FuzzyRule){3, 2, 3, 1.0f}; // 4 3, 4 - Updated
    system->rules[24] = (FuzzyRule){3, 3, 3, 1.0f}; // 4 4, 4 - Updated
    system->rules[25] = (FuzzyRule){3, 4, 3, 1.0f}; // 4 5, 4 - Updated
    system->rules[26] = (FuzzyRule){3, 5, 4, 1.0f}; // 4 6, 5 - Updated
    system->rules[27] = (FuzzyRule){3, 6, 5, 1.0f}; // 4 7, 6 - Updated

    // Row 5
    system->rules[28] = (FuzzyRule){4, 0, 2, 1.0f}; // 5 1, 3 - Updated
    system->rules[29] = (FuzzyRule){4, 1, 2, 1.0f}; // 5 2, 3 - Updated
    system->rules[30] = (FuzzyRule){4, 2, 3, 1.0f}; // 5 3, 4 - Updated
    system->rules[31] = (FuzzyRule){4, 3, 4, 1.0f}; // 5 4, 5 - Updated
    system->rules[32] = (FuzzyRule){4, 4, 4, 1.0f}; // 5 5, 5 - Updated
    system->rules[33] = (FuzzyRule){4, 5, 5, 1.0f}; // 5 6, 6 - Updated
    system->rules[34] = (FuzzyRule){4, 6, 5, 1.0f}; // 5 7, 6 - Updated

    // Row 6
    system->rules[35] = (FuzzyRule){5, 0, 2, 1.0f}; // 6 1, 3 - Updated
    system->rules[36] = (FuzzyRule){5, 1, 3, 1.0f}; // 6 2, 4 - Updated
    system->rules[37] = (FuzzyRule){5, 2, 4, 1.0f}; // 6 3, 5 - Updated
    system->rules[38] = (FuzzyRule){5, 3, 4, 1.0f}; // 6 4, 5 - Updated
    system->rules[39] = (FuzzyRule){5, 4, 5, 1.0f}; // 6 5, 6 - Updated
    system->rules[40] = (FuzzyRule){5, 5, 5, 1.0f}; // 6 6, 6 - Updated
    system->rules[41] = (FuzzyRule){5, 6, 6, 1.0f}; // 6 7, 7 - Updated

    // Row 7
    system->rules[42] = (FuzzyRule){6, 0, 3, 1.0f}; // 7 1, 4 - Updated
    system->rules[43] = (FuzzyRule){6, 1, 4, 1.0f}; // 7 2, 5 - Updated
    system->rules[44] = (FuzzyRule){6, 2, 4, 1.0f}; // 7 3, 5 - Updated
    system->rules[45] = (FuzzyRule){6, 3, 5, 1.0f}; // 7 4, 6 - Updated
    system->rules[46] = (FuzzyRule){6, 4, 5, 1.0f}; // 7 5, 6 - Updated
    system->rules[47] = (FuzzyRule){6, 5, 6, 1.0f}; // 7 6, 7 - Updated
    system->rules[48] = (FuzzyRule){6, 6, 6, 1.0f}; // 7 7, 7 - Updated

    // Set inference methods
    system->andMethod = AND_MIN;
    system->orMethod = OR_MAX;
    system->defuzzMethod = DEFUZZ_CENTROID;
    system->typeReductionMethod = TR_KARNIKMENDEL;

    return 0;
}

/**
 * @brief Free memory allocated for the fuzzy system
 * @param system Pointer to fuzzy system structure
 */
void DestroyFuzzySystem(FuzzySystem* system) {
    if (system == NULL) {
        return;
    }

    if (system->inputs[0].mfs != NULL) {
        free(system->inputs[0].mfs);
    }

    if (system->inputs[1].mfs != NULL) {
        free(system->inputs[1].mfs);
    }

    if (system->output.mfs != NULL) {
        free(system->output.mfs);
    }

    if (system->rules != NULL) {
        free(system->rules);
    }
}
