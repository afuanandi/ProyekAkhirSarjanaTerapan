/**
 * @file pwm_mlbc.c
 * @brief Multi-Level Boost Converter (MLBC) Control Implementation
 */

#include "pwm_mlbc.h"
#include "pod_pwm.h"  // For integration with inverter

/* Global MLBC structure */
MLBC_TypeDef mlbc;

/**
 * @brief Initialize MLBC system
 */
void MLBC_Init(void) {
    /* Initialize control structure */
    mlbc.duty_cycle = 0.0f;
    mlbc.target_duty_cycle = MLBC_NOMINAL_DUTY_CYCLE;  // Default 70%
    mlbc.state = MLBC_STATE_STOPPED;
    mlbc.mode = MLBC_MODE_MANUAL;

    /* Initialize button management */
    mlbc.start_button_pressed = 0;
    mlbc.stop_button_pressed = 0;
    mlbc.button_debounce_timer = 0;
    mlbc.button_state_prev = 0;

    /* Initialize measurements */
    mlbc.input_voltage = 0.0f;
    mlbc.output_voltage = 0.0f;
    mlbc.input_current = 0.0f;
    mlbc.fault_flags = MLBC_FAULT_NONE;

    /* Initialize system integration */
    mlbc.inverter_ready = 0;
    mlbc.enable_flag = 0;

    /* Initialize debug system */
    mlbc.debug_flag = 0;  // Debug disabled by default
    mlbc.debug_counter = 0;

    /* Initialize timing */
    mlbc.system_tick = 0;
    mlbc.last_update_tick = HAL_GetTick();

    /* Start PWM timer but with 0% duty cycle */
    HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_1);
    MLBC_Apply_PWM();
}

/**
 * @brief Main MLBC update function (call from main loop)
 */
void MLBC_Update(void) {
    /* Update system tick */
    mlbc.system_tick = HAL_GetTick();

    /* Button handling moved to main.c - no longer handled here */

    /* Check for fault conditions */
    mlbc.fault_flags = MLBC_Check_Faults();

    /* State machine */
    switch(mlbc.state) {
        case MLBC_STATE_STOPPED:
            /* System is stopped - wait for start command */
            mlbc.duty_cycle = 0.0f;
            break;

        case MLBC_STATE_RUNNING:
            /* Normal operation - use target duty cycle directly */
            mlbc.duty_cycle = mlbc.target_duty_cycle;

            /* Check if stop requested or fault occurred */
            if(mlbc.stop_button_pressed || mlbc.fault_flags != MLBC_FAULT_NONE) {
                MLBC_Stop();
            }
            break;

        case MLBC_STATE_SHUTDOWN:
            /* Shutdown sequence - immediate stop since no soft-start needed */
            mlbc.duty_cycle = 0.0f;
            mlbc.state = MLBC_STATE_STOPPED;
            break;

        case MLBC_STATE_FAULT:
            /* Fault condition - immediate stop */
            mlbc.duty_cycle = 0.0f;
            /* Stay in fault state until fault is cleared */
            if(mlbc.fault_flags == MLBC_FAULT_NONE) {
                mlbc.state = MLBC_STATE_STOPPED;
            }
            break;
    }

    /* Apply PWM output */
    MLBC_Apply_PWM();

    /* Increment debug counter */
    mlbc.debug_counter++;

    /* Update last tick */
    mlbc.last_update_tick = mlbc.system_tick;
}

/**
 * @brief Start the MLBC system
 */
void MLBC_Start(void) {
    if(mlbc.state == MLBC_STATE_STOPPED && mlbc.fault_flags == MLBC_FAULT_NONE) {
        /* Start immediately - no soft-start needed (hardware handles it) */
        mlbc.state = MLBC_STATE_RUNNING;
        mlbc.enable_flag = 1;

        /* Enable inverter after MLBC is running */
        POD_PWM_Enable(1);
    }
}

/**
 * @brief Stop the MLBC system
 */
void MLBC_Stop(void) {
    if(mlbc.state != MLBC_STATE_STOPPED && mlbc.state != MLBC_STATE_SHUTDOWN) {
        mlbc.state = MLBC_STATE_SHUTDOWN;
        mlbc.enable_flag = 0;

        /* Disable inverter immediately */
        POD_PWM_Enable(0);
    }
}

/**
 * @brief Emergency shutdown
 */
void MLBC_Emergency_Stop(void) {
    mlbc.state = MLBC_STATE_FAULT;
    mlbc.duty_cycle = 0.0f;
    mlbc.enable_flag = 0;

    /* Immediate hardware shutdown */
    MLBC_Apply_PWM();

    /* Disable inverter immediately */
    POD_PWM_Enable(0);
}

/**
 * @brief Set target duty cycle (for manual control)
 */
void MLBC_Set_Target_Duty_Cycle(float duty) {
    /* Clamp duty cycle to safe limits */
    if(duty < MLBC_MIN_DUTY_CYCLE) duty = MLBC_MIN_DUTY_CYCLE;
    if(duty > MLBC_MAX_DUTY_CYCLE) duty = MLBC_MAX_DUTY_CYCLE;

    mlbc.target_duty_cycle = duty;
}

/**
 * @brief Get target duty cycle
 */
float MLBC_Get_Target_Duty_Cycle(void) {
    return mlbc.target_duty_cycle;
}

/**
 * @brief Set debug flag
 */
void MLBC_Set_Debug(uint8_t flag) {
    mlbc.debug_flag = flag;
    if(flag) {
        mlbc.debug_counter = 0;  // Reset counter when enabling debug
    }
}

/**
 * @brief Get current duty cycle
 */
float MLBC_Get_Duty_Cycle(void) {
    return mlbc.duty_cycle;
}

/**
 * @brief Set operation mode
 */
void MLBC_Set_Mode(MLBC_Mode_t mode) {
    mlbc.mode = mode;
}

/**
 * @brief Handle start/stop button press - DEPRECATED
 * Button handling moved to main.c since it affects entire system
 */
void MLBC_Handle_Button_Press(void) {
    /* This function is now deprecated - button handling moved to main.c */
    /* Only handle software button flags for backward compatibility */

    /* Clear software button flags after processing */
    mlbc.start_button_pressed = 0;
    mlbc.stop_button_pressed = 0;
}

/**
 * @brief Update voltage and current measurements
 */
void MLBC_Update_Measurements(float v_in, float v_out, float i_in) {
    mlbc.input_voltage = v_in;
    mlbc.output_voltage = v_out;
    mlbc.input_current = i_in;
}

/**
 * @brief Check for fault conditions
 */
MLBC_Fault_t MLBC_Check_Faults(void) {
    MLBC_Fault_t faults = MLBC_FAULT_NONE;

    /* Check overvoltage */
    if(mlbc.output_voltage > MLBC_MAX_OUTPUT_VOLTAGE) {
        faults |= MLBC_FAULT_OVERVOLTAGE;
    }

    /* Check overcurrent */
    if(mlbc.input_current > MLBC_MAX_INPUT_CURRENT) {
        faults |= MLBC_FAULT_OVERCURRENT;
    }

    /* Check undervoltage (input) */
    if(mlbc.input_voltage < 20.0f && mlbc.input_voltage > 5.0f) {  // Valid range check
        faults |= MLBC_FAULT_UNDERVOLTAGE;
    }

    /* Check over duty cycle */
    if(mlbc.duty_cycle > MLBC_MAX_DUTY_CYCLE) {
        faults |= MLBC_FAULT_OVERDUTY;
    }

    return faults;
}

/**
 * @brief Clear specific fault
 */
void MLBC_Clear_Fault(MLBC_Fault_t fault) {
    mlbc.fault_flags &= ~fault;
}

/**
 * @brief Get current system state
 */
MLBC_State_t MLBC_Get_State(void) {
    return mlbc.state;
}

/**
 * @brief Set inverter ready signal
 */
void MLBC_Set_Inverter_Ready(uint8_t ready) {
    mlbc.inverter_ready = ready;
}

/**
 * @brief Apply PWM duty cycle to hardware timer
 */
void MLBC_Apply_PWM(void) {
    /* Calculate compare value for PWM */
    /* TIM2 period should be configured for 40kHz: Period = 90MHz / 40kHz - 1 = 2249 */
    uint32_t compare_value = (uint32_t)(mlbc.duty_cycle * (float)(htim2.Init.Period + 1));

    /* Clamp to valid range */
    if(compare_value > htim2.Init.Period) {
        compare_value = htim2.Init.Period;
    }

    /* Apply to hardware */
    __HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_1, compare_value);
}

/**
 * @brief Transmit debug data via UART (call from main loop)
 */
void MLBC_Debug_Transmit(void) {
    if(mlbc.debug_flag) {
        char debug_buffer[MLBC_DEBUG_BUFFER_SIZE];

        snprintf(debug_buffer, sizeof(debug_buffer),
            "MLBC,%lu,%.3f,%.3f,%.1f,%.1f,%.1f\r\n",
            mlbc.debug_counter,
            mlbc.target_duty_cycle,
            mlbc.duty_cycle,
            mlbc.input_voltage,
            mlbc.output_voltage,
            mlbc.input_current
        );

        HAL_UART_Transmit(&huart2, (uint8_t*)debug_buffer, strlen(debug_buffer), 100);
    }
}

/**
 * @brief Get system status string for debugging
 */
void MLBC_Get_Status_String(char* buffer, size_t buffer_size) {
    const char* state_strings[] = {
        "STOPPED", "RUNNING", "SHUTDOWN", "FAULT"
    };

    const char* mode_strings[] = {
        "MANUAL", "VOLTAGE_CTRL"
    };

    snprintf(buffer, buffer_size,
        "MLBC: %s,%s,Target:%.2f%%,Actual:%.2f%%,Vin:%.1fV,Vout:%.1fV,Iin:%.1fA,Faults:0x%02X",
        state_strings[mlbc.state],
        mode_strings[mlbc.mode],
        mlbc.target_duty_cycle * 100.0f,
        mlbc.duty_cycle * 100.0f,
        mlbc.input_voltage,
        mlbc.output_voltage,
        mlbc.input_current,
        mlbc.fault_flags
    );
}

/* Additional utility functions for external control */

/**
 * @brief Request start via software (for button simulation)
 */
void MLBC_Request_Start(void) {
    mlbc.start_button_pressed = 1;
}

/**
 * @brief Request stop via software (for button simulation)
 */
void MLBC_Request_Stop(void) {
    mlbc.stop_button_pressed = 1;
}
