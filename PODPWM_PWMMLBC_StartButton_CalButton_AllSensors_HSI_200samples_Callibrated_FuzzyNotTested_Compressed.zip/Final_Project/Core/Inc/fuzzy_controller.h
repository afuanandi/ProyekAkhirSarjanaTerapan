/**
 * @file fuzzy_controller.h
 * @brief Type-2 Fuzzy Logic Controller for 7-Level PUCI Inverter Voltage Regulation
 * @author afuanandi
 * @date 2025
 *
 * This module implements a Type-2 fuzzy logic controller for AC voltage regulation
 * in a 7-level Packed U-Cell Inverter system. The controller takes voltage error
 * and error derivative as inputs and outputs modulation index for PWM control.
 *
 * Features:
 * - Type-2 fuzzy logic with uncertainty handling
 * - Karnik-Mendel type reduction
 * - Direct error mapping (no scaling) for ±17V error range
 * - Derivative filtering for noise reduction
 * - Non-blocking startup delay
 * - Comprehensive debug output
 */

#ifndef FUZZY_CONTROLLER_H
#define FUZZY_CONTROLLER_H

#include "main.h"
#include "fuzzy_structures.h"
#include "ac_sensor.h"
#include <math.h>
#include <stdio.h>

/* Fuzzy Controller Internal Parameters */
#define DERIVATIVE_FILTER_ALPHA 0.7f            // Derivative filter coefficient (0.0-1.0)
#define FUZZY_STARTUP_DELAY_MS 1000             // Startup delay (ms)
#define FUZZY_INPUT_RANGE_MAX 17.0f             // Maximum fuzzy input range (±17V)
#define FUZZY_UPDATE_INTERVAL_MS 100            // Controller update interval (ms)

/* Debug Parameters */
#define FUZZY_DEBUG_BUFFER_SIZE 200             // Debug string buffer size

/**
 * @brief Fuzzy controller operation status
 */
typedef enum {
    FUZZY_STATUS_STARTUP,           // Controller in startup delay
    FUZZY_STATUS_NORMAL,            // Normal fuzzy control operation
    FUZZY_STATUS_SAFETY_FALLBACK,   // Safety fallback mode (inputs out of range)
    FUZZY_STATUS_SENSOR_ERROR       // AC sensor error detected
} FuzzyStatus_t;

/**
 * @brief Main Fuzzy Controller structure
 */
typedef struct {
    /* Control State */
    FuzzyStatus_t status;               // Current controller status
    uint8_t initialized;                // Initialization flag
    uint8_t ready;                      // Ready flag (after startup delay)

    /* Timing Management */
    uint32_t start_time;                // Startup timestamp
    uint32_t last_update_time;          // Last update timestamp

    /* Error Processing */
    float target_voltage;               // Target voltage setpoint (V RMS)
    float current_voltage;              // Current measured voltage (V RMS)
    float error;                        // Voltage error (target - actual)
    float previous_error;               // Previous error for derivative calculation
    float error_derivative;             // Raw error derivative
    float filtered_derivative;          // Filtered error derivative

    /* Direct Fuzzy System Inputs (No Scaling) */
    float fuzzy_error;                  // Direct error input to fuzzy system
    float fuzzy_derror;                 // Direct derivative input to fuzzy system

    /* Fuzzy System Outputs */
    float fuzzy_output_raw;             // Raw output from fuzzy inference
    float fuzzy_output_final;           // Final output after clamping

    /* Statistics and Monitoring */
    uint32_t update_count;              // Total updates performed
    uint32_t safety_fallback_count;     // Number of safety fallbacks
    uint32_t sensor_error_count;        // Number of sensor errors

    /* Debug System */
    uint8_t debug_enabled;              // Debug output flag
    char debug_buffer[FUZZY_DEBUG_BUFFER_SIZE];  // Debug message buffer

} FuzzyController_t;

/* External Variables */
extern FuzzyController_t fuzzy_controller;
extern FuzzySystem fuzzy_system;
extern UART_HandleTypeDef huart2;

/* Function Prototypes */

/**
 * @brief Initialize the fuzzy controller system
 * Initializes the fuzzy system, sets up parameters, and prepares for operation
 */
void Fuzzy_Controller_Init(void);

/**
 * @brief Main fuzzy controller update function
 * Call this from main loop every 100ms in closed loop mode
 * @return Modulation index for POD PWM system (0.75 - 1.25 range)
 */
float Fuzzy_Controller_Update(void);

/**
 * @brief Get current controller status
 * @return Current fuzzy controller status
 */
FuzzyStatus_t Fuzzy_Controller_Get_Status(void);

/**
 * @brief Reset the fuzzy controller to initial state
 * Clears error history and resets startup timing
 */
void Fuzzy_Controller_Reset(void);

/**
 * @brief Set target voltage setpoint
 * @param target_voltage: New target voltage in V RMS
 */
void Fuzzy_Controller_Set_Target_Voltage(float target_voltage);

/**
 * @brief Get current target voltage
 * @return Current target voltage setpoint in V RMS
 */
float Fuzzy_Controller_Get_Target_Voltage(void);

/**
 * @brief Enable/disable debug output
 * @param enable: 1 to enable debug output, 0 to disable
 */
void Fuzzy_Controller_Set_Debug(uint8_t enable);

/**
 * @brief Transmit debug data via UART
 * Call from main loop debug transmission section
 */
void Fuzzy_Controller_Debug_Transmit(void);

/**
 * @brief Get controller statistics string
 * @param buffer: Output buffer for statistics
 * @param buffer_size: Size of output buffer
 */
void Fuzzy_Controller_Get_Statistics(char* buffer, size_t buffer_size);

/* Internal Processing Functions */

/**
 * @brief Check if controller startup delay has completed
 * @return 1 if ready, 0 if still in startup
 */
uint8_t Fuzzy_Controller_Is_Ready(void);

/**
 * @brief Calculate voltage error and derivative
 */
void Fuzzy_Controller_Calculate_Error(void);

/**
 * @brief Apply derivative filtering to reduce noise
 */
void Fuzzy_Controller_Apply_Filtering(void);

/**
 * @brief Prepare inputs for fuzzy system (no scaling, direct mapping)
 */
void Fuzzy_Controller_Prepare_Inputs(void);

/**
 * @brief Check if inputs are within safe fuzzy range
 * @return 1 if inputs are safe, 0 if out of range
 */
uint8_t Fuzzy_Controller_Check_Input_Safety(void);

/**
 * @brief Apply safety clamping to fuzzy output
 * @param raw_output: Raw output from fuzzy inference
 * @return Clamped output within safe MI range
 */
float Fuzzy_Controller_Apply_Output_Clamping(float raw_output);

/**
 * @brief Update controller statistics
 */
void Fuzzy_Controller_Update_Statistics(void);

#endif /* FUZZY_CONTROLLER_H */
