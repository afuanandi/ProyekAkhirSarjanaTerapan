/**
 * @file pod_pwm.h
 * @brief Phase Opposition Disposition PWM for 7-Level PUCI Inverter
 * @author afuanandi
 * @date 2025
 *
 * This module handles the PWM generation for a 7-level Packed U-Cell Inverter
 * using Phase Opposition Disposition (POD) carrier arrangement.
 *
 * Features:
 * - 7-level output: +3, +2, +1, 0, -1, -2, -3
 * - 8 IGBT switches with complementary pairs
 * - Three switching patterns for natural capacitor balancing
 * - Manual and automatic modulation index control
 * - Debug output for telemetry viewer
 */

#ifndef POD_PWM_H
#define POD_PWM_H

#include "main.h"
#include "math.h"
#include <stdio.h>
#include <string.h>

/* Mathematical Constants */
#define PI 3.14159265359f
#define TWO_PI (2.0f * PI)

/* PWM Parameters */
#define FUNDAMENTAL_FREQ 50.0f      // 50 Hz output frequency
#define UPDATE_FREQ 10000.0f        // 10 kHz reference update frequency
#define CARRIER_FREQ 2500.0f        // 2.5 kHz carrier frequency
#define MODULATION_FREQUENCY (CARRIER_FREQ / FUNDAMENTAL_FREQ)  // 2500/50 = 50
#define PHASE_INCREMENT (TWO_PI * FUNDAMENTAL_FREQ / UPDATE_FREQ)
#define MAX_MODULATION_INDEX 2.0f   // Maximum modulation index from fuzzy controller
#define NORMAL_MODULATION_INDEX 1.0f // Normal/default modulation index

/* Switching Patterns - 7-Level PUCI */
#define NUM_PATTERNS 3
#define NUM_LEVELS 7
#define NUM_SWITCHES 8

/* Debug Parameters */
#define DEBUG_BUFFER_SIZE 200
#define DEBUG_SAMPLES_PER_CYCLE 200  // 200 samples per 50Hz cycle
#define DEBUG_CYCLES_TO_CAPTURE 6   // Capture 6 complete cycles (1200 total samples)

/* Debug buffer structure */
typedef struct {
    float reference;
    float carriers[6];
    int8_t level;
    uint8_t pattern_index;
} DebugSample;

/**
 * @brief Carrier band structure for POD arrangement
 */
typedef struct {
    float upper_limit;      // Upper voltage limit of the band
    float lower_limit;      // Lower voltage limit of the band
} CarrierBand;

/**
 * @brief POD PWM operation modes
 */
typedef enum {
    POD_PWM_MODE_OPEN_LOOP,      // Manual modulation index control
    POD_PWM_MODE_CLOSED_LOOP,    // Fuzzy controller modulation index
    POD_PWM_MODE_MANUAL_LEVEL    // Direct level control (testing/stop)
} POD_PWM_Mode_t;

/**
 * @brief Switching state for 8 IGBTs
 */
typedef struct {
    uint8_t S1, S2, S3, S4;     // Main switches
    uint8_t S5, S6, S7, S8;     // Complementary switches
} SwitchingState;

/**
 * @brief Main POD PWM control structure
 */
typedef struct {
    /* Reference and Carriers */
    float reference;            // Current sine reference value
    float carriers[6];          // Six triangular carriers
    float phase;                // Current phase angle (0 to 2π)

    /* Control Parameters */
    float modulation_index;     // Current modulation index (0.0 to 2.0)
    POD_PWM_Mode_t mode;        // Current operation mode

    /* Level and Pattern Management */
    int8_t current_level;       // Current output level (-3 to +3)
    int8_t target_level;        // Target level (for transition limiting)
    int8_t manual_level;        // Manual level setting
    uint8_t pattern_index;      // Current pattern (0, 1, 2)

    /* Debug System */
    uint32_t debug_counter;     // Debug sample counter
    uint8_t debug_flag;         // Enable/disable debug output

    /* Chunk-based debug collection */
    DebugSample debug_buffer[DEBUG_SAMPLES_PER_CYCLE * DEBUG_CYCLES_TO_CAPTURE];
    uint32_t debug_buffer_index;    // Current buffer position
    uint8_t debug_buffer_ready;     // Buffer ready for transmission
    uint32_t debug_cycles_count;    // Count of completed cycles

    /* System Status */
    uint8_t system_enabled;     // System enable/disable flag
} POD_PWM_TypeDef;

/* External Variables */
extern POD_PWM_TypeDef pod_pwm;
extern TIM_HandleTypeDef htim1;
extern TIM_HandleTypeDef htim8;
extern UART_HandleTypeDef huart2;

/* Function Prototypes */

/**
 * @brief Initialize POD PWM system
 */
void POD_PWM_Init(void);

/**
 * @brief Update reference and carriers (called from TIM3 interrupt)
 * This is the main update function called at 10 kHz
 */
void POD_PWM_Update_Reference(void);

/**
 * @brief Set operation mode
 * @param mode: POD_PWM_MODE_OPEN_LOOP, POD_PWM_MODE_CLOSED_LOOP, or POD_PWM_MODE_MANUAL_LEVEL
 */
void POD_PWM_Set_Mode(POD_PWM_Mode_t mode);

/**
 * @brief Set manual modulation index (open loop mode)
 * @param mi: Modulation index (0.0 to 1.0)
 */
void POD_PWM_Set_Manual_MI(float mi);

/**
 * @brief Set modulation index from fuzzy controller (closed loop mode)
 * @param mi: Modulation index from fuzzy controller (0.0 to 1.0)
 */
void POD_PWM_Set_Fuzzy_MI(float mi);

/**
 * @brief Set manual level directly (manual level mode)
 * @param level: Output level (-3 to +3)
 */
void POD_PWM_Set_Manual_Level(int8_t level);

/**
 * @brief Enable/disable the PWM system
 * @param enable: 1 to enable, 0 to disable (sets level to 0)
 */
void POD_PWM_Enable(uint8_t enable);

/**
 * @brief Set debug flag
 * @param flag: 1 to enable debug output, 0 to disable
 */
void POD_PWM_Set_Debug(uint8_t flag);

/**
 * @brief Generate triangular carriers for POD arrangement
 */
void POD_PWM_Generate_Carriers(void);

/**
 * @brief Determine output level based on reference and carrier comparison
 * @return: Output level (-3 to +3)
 */
int8_t POD_PWM_Determine_Level(void);

/**
 * @brief Handle pattern switching based on zero-crossing detection
 */
void POD_PWM_Handle_Pattern_Switching(void);

/**
 * @brief Apply switching states to hardware timers
 * @param level: Output level (-3 to +3)
 * @param pattern: Pattern index (0, 1, 2)
 */
void POD_PWM_Apply_Switching_States(int8_t level, uint8_t pattern);

/**
 * @brief Get switching state for given level and pattern
 * @param level: Output level (-3 to +3)
 * @param pattern: Pattern index (0, 1, 2)
 * @return: Switching state structure
 */
SwitchingState POD_PWM_Get_Switching_State(int8_t level, uint8_t pattern);

/**
 * @brief Transmit debug data via UART (call from main loop)
 */
void POD_PWM_Debug_Transmit(void);

/**
 * @brief Reset debug counter (call when starting system)
 */
void POD_PWM_Reset_Debug_Counter(void);

/**
 * @brief Limit level transitions to ±1 step maximum
 * @param target_level: Desired level
 * @return: Safe level considering transition limits
 */
int8_t POD_PWM_Limit_Level_Transition(int8_t target_level);

#endif /* POD_PWM_H */
