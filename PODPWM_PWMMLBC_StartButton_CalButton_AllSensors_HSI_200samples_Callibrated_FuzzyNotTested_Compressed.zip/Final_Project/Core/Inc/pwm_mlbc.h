/**
 * @file pwm_mlbc.h
 * @brief Multi-Level Boost Converter (MLBC) Control with Start/Stop Functionality
 * @author afuanandi
 * @date 2025
 *
 * This module handles the PWM control for the Multi-Level Boost Converter
 * that boosts 24V input to 312V output for the 7-level inverter.
 *
 * Features:
 * - Soft-start capability to prevent inrush current
 * - Start/Stop button functionality
 * - Duty cycle control and monitoring
 * - Safety shutdown integration with inverter
 * - Protection against overvoltage/overcurrent
 */

#ifndef PWM_MLBC_H
#define PWM_MLBC_H

#include "main.h"
#include <stdio.h>
#include <string.h>

/* MLBC Parameters */
#define MLBC_INPUT_VOLTAGE_NOMINAL 24.0f    // 24V input
#define MLBC_OUTPUT_VOLTAGE_NOMINAL 312.0f  // 312V output
#define MLBC_NOMINAL_DUTY_CYCLE 0.70f       // 70% duty cycle
#define MLBC_PWM_FREQUENCY 40000.0f         // 40 kHz PWM frequency
#define MLBC_TIMER_FREQUENCY 90000000.0f    // 90 MHz TIM2 frequency

/* Debug Parameters */
#define MLBC_DEBUG_BUFFER_SIZE 100          // Debug string buffer size

/* Safety Limits */
#define MLBC_MAX_DUTY_CYCLE 0.75f           // Maximum duty cycle for safety
#define MLBC_MIN_DUTY_CYCLE 0.25f           // Minimum duty cycle
#define MLBC_MAX_OUTPUT_VOLTAGE 350.0f      // Maximum output voltage limit
#define MLBC_MAX_INPUT_CURRENT 50.0f        // Maximum input current limit

/* Debounce Parameters */
#define MLBC_BUTTON_DEBOUNCE_MS 50          // 50ms button debounce time

/**
 * @brief MLBC operation states
 */
typedef enum {
    MLBC_STATE_STOPPED,          // System stopped, no PWM output
    MLBC_STATE_RUNNING,          // Normal operation
    MLBC_STATE_SHUTDOWN,         // Emergency shutdown in progress
    MLBC_STATE_FAULT            // Fault condition detected
} MLBC_State_t;

/**
 * @brief MLBC operation modes
 */
typedef enum {
    MLBC_MODE_MANUAL,            // Manual duty cycle control
    MLBC_MODE_VOLTAGE_CONTROL    // Target voltage control (future)
} MLBC_Mode_t;

/**
 * @brief MLBC fault conditions
 */
typedef enum {
    MLBC_FAULT_NONE = 0,
    MLBC_FAULT_OVERVOLTAGE = 1,
    MLBC_FAULT_OVERCURRENT = 2,
    MLBC_FAULT_UNDERVOLTAGE = 4,
    MLBC_FAULT_OVERDUTY = 8
} MLBC_Fault_t;

/**
 * @brief Main MLBC control structure
 */
typedef struct {
    /* Control Parameters */
    float duty_cycle;               // Current duty cycle (0.0 to 1.0)
    float target_duty_cycle;        // Target duty cycle (manually settable)
    MLBC_State_t state;             // Current system state
    MLBC_Mode_t mode;               // Operation mode

    /* Button Management */
    uint8_t start_button_pressed;   // Start button state
    uint8_t stop_button_pressed;    // Stop button state (can be same button)
    uint32_t button_debounce_timer; // Button debounce timer
    uint8_t button_state_prev;      // Previous button state for edge detection

    /* Safety and Monitoring */
    float input_voltage;            // Measured input voltage
    float output_voltage;           // Measured output voltage
    float input_current;            // Measured input current
    MLBC_Fault_t fault_flags;       // Current fault conditions

    /* System Integration */
    uint8_t inverter_ready;         // Inverter ready signal
    uint8_t enable_flag;            // Overall system enable

    /* Debug System */
    uint8_t debug_flag;             // Enable/disable debug output
    uint32_t debug_counter;         // Debug sample counter

    /* Timing */
    uint32_t system_tick;           // System tick counter for timing
    uint32_t last_update_tick;      // Last update timestamp

} MLBC_TypeDef;

/* External Variables */
extern MLBC_TypeDef mlbc;
extern TIM_HandleTypeDef htim2;

/* Function Prototypes */

/**
 * @brief Initialize MLBC system
 */
void MLBC_Init(void);

/**
 * @brief Main MLBC update function (call from main loop)
 * Handles state machine, soft-start, and safety monitoring
 */
void MLBC_Update(void);

/**
 * @brief Start the MLBC system
 * Initiates soft-start sequence
 */
void MLBC_Start(void);

/**
 * @brief Stop the MLBC system
 * Performs safe shutdown
 */
void MLBC_Stop(void);

/**
 * @brief Emergency shutdown
 * Immediate stop without soft shutdown
 */
void MLBC_Emergency_Stop(void);

/**
 * @brief Set manual duty cycle (for open loop control)
 * @param duty: Duty cycle (0.0 to 1.0)
 */
void MLBC_Set_Target_Duty_Cycle(float duty);

/**
 * @brief Get target duty cycle
 * @return Target duty cycle (0.0 to 1.0)
 */
float MLBC_Get_Target_Duty_Cycle(void);

/**
 * @brief Set debug flag
 * @param flag: 1 to enable debug output, 0 to disable
 */
void MLBC_Set_Debug(uint8_t flag);

/**
 * @brief Transmit debug data via UART (call from main loop)
 */
void MLBC_Debug_Transmit(void);

/**
 * @brief Get current duty cycle
 * @return Current duty cycle (0.0 to 1.0)
 */
float MLBC_Get_Duty_Cycle(void);

/**
 * @brief Set operation mode
 * @param mode: MLBC_MODE_MANUAL or MLBC_MODE_VOLTAGE_CONTROL
 */
void MLBC_Set_Mode(MLBC_Mode_t mode);

/**
 * @brief Handle start/stop button press
 * Call this from button interrupt or main loop
 */
void MLBC_Handle_Button_Press(void);

/**
 * @brief Update voltage and current measurements
 * @param v_in: Input voltage measurement
 * @param v_out: Output voltage measurement
 * @param i_in: Input current measurement
 */
void MLBC_Update_Measurements(float v_in, float v_out, float i_in);

/**
 * @brief Check for fault conditions
 * @return: Current fault flags
 */
MLBC_Fault_t MLBC_Check_Faults(void);

/**
 * @brief Clear specific fault
 * @param fault: Fault flag to clear
 */
void MLBC_Clear_Fault(MLBC_Fault_t fault);

/**
 * @brief Get current system state
 * @return: Current MLBC state
 */
MLBC_State_t MLBC_Get_State(void);

/**
 * @brief Set inverter ready signal
 * @param ready: 1 if inverter is ready, 0 if not
 */
void MLBC_Set_Inverter_Ready(uint8_t ready);

/**
 * @brief Apply PWM duty cycle to hardware timer
 */
void MLBC_Apply_PWM(void);

/**
 * @brief Get system status string for debugging
 * @param buffer: Output buffer for status string
 * @param buffer_size: Size of output buffer
 */
void MLBC_Get_Status_String(char* buffer, size_t buffer_size);

#endif /* PWM_MLBC_H */
