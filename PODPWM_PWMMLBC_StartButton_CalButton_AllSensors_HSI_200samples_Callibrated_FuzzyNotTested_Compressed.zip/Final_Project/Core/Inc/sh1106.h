/**
 * @file sh1106.h
 * @brief Non-blocking SH1106 OLED display driver
 * @author afuanandi & Claude
 * @date 2025
 *
 * This implementation uses chunked transmission to avoid blocking the main loop
 * during display updates. Perfect for real-time embedded systems.
 */

#ifndef SH1106_H
#define SH1106_H

#include "main.h"
#include "i2c.h"
#include <stdbool.h>

/* SH1106 I2C address */
#define SH1106_I2C_ADDR 0x3C

/* SH1106 commands (same as before) */
#define SH1106_SETCONTRAST 0x81
#define SH1106_DISPLAYALLON 0xA5
#define SH1106_DISPLAYALLON_RESUME 0xA4
#define SH1106_NORMALDISPLAY 0xA6
#define SH1106_INVERTDISPLAY 0xA7
#define SH1106_DISPLAYOFF 0xAE
#define SH1106_DISPLAYON 0xAF
#define SH1106_SETDISPLAYOFFSET 0xD3
#define SH1106_SETCOMPINS 0xDA
#define SH1106_SETVCOMDETECT 0xDB
#define SH1106_SETDISPLAYCLOCKDIV 0xD5
#define SH1106_SETPRECHARGE 0xD9
#define SH1106_SETMULTIPLEX 0xA8
#define SH1106_SETLOWCOLUMN 0x00
#define SH1106_SETHIGHCOLUMN 0x10
#define SH1106_SETSTARTLINE 0x40
#define SH1106_MEMORYMODE 0x20
#define SH1106_COLUMNADDR 0x21
#define SH1106_PAGEADDR 0x22
#define SH1106_COMSCANINC 0xC0
#define SH1106_COMSCANDEC 0xC8
#define SH1106_SEGREMAP 0xA0
#define SH1106_CHARGEPUMP 0x8D
#define SH1106_SETPAGEADDR 0xB0

/* Display dimensions */
#define SH1106_WIDTH 128
#define SH1106_HEIGHT 64
#define SH1106_PAGES 8

/* Non-blocking transmission parameters */
#define SH1106_I2C_TIMEOUT_MS 10         // Very short timeout to avoid blocking
#define SH1106_CHUNK_SIZE 32            // Transmit 32 bytes per update cycle
#define SH1106_MAX_RETRIES 3            // Maximum retries for failed transmissions

/* Display update state machine */
typedef enum {
    DISPLAY_STATE_IDLE,                 // Not updating
    DISPLAY_STATE_UPDATING,             // Update in progress
    DISPLAY_STATE_PAGE_SETUP,           // Setting up page commands
    DISPLAY_STATE_PAGE_DATA,            // Transmitting page data
    DISPLAY_STATE_COMPLETE              // Update complete
} DisplayUpdateState_t;

/* Display controller structure */
typedef struct {
    /* Display buffer */
    uint8_t buffer[SH1106_PAGES][SH1106_WIDTH];

    /* Update state machine */
    DisplayUpdateState_t update_state;
    uint8_t current_page;               // Current page being updated
    uint8_t current_column;             // Current column in page
    uint8_t update_pending;             // Update request flag
    uint8_t update_forced;              // Force immediate update flag

    /* Chunked transmission */
    uint8_t transmission_buffer[SH1106_CHUNK_SIZE + 1]; // +1 for control byte
    uint8_t chunk_size;                 // Current chunk size
    uint8_t retry_count;                // Current retry count

    /* Timing */
    uint32_t last_update_time;          // Last successful update
    uint32_t update_start_time;         // Current update start time

    /* Statistics */
    uint32_t successful_updates;        // Successful update count
    uint32_t failed_updates;            // Failed update count
    uint32_t i2c_errors;                // I2C error count

    /* Initialization */
    uint8_t initialized;                // Initialization complete flag

} SH1106_Controller_t;

/* External variables */
extern SH1106_Controller_t sh1106_ctrl;

/* Function prototypes */

/**
 * @brief Initialize the SH1106 display (blocking - only called once)
 */
void SH1106_Init(void);

/**
 * @brief Non-blocking update function - call from main loop frequently (1-5ms)
 * This function performs chunked transmission to avoid blocking
 */
void SH1106_Update(void);

/**
 * @brief Request a display update (non-blocking)
 * Call this after modifying the display buffer
 */
void SH1106_Request_Update(void);

/**
 * @brief Force immediate display update (still non-blocking)
 * Use sparingly - only for critical updates
 */
void SH1106_Force_Update(void);

/**
 * @brief Check if display update is in progress
 * @return 1 if updating, 0 if idle
 */
uint8_t SH1106_Is_Updating(void);

/**
 * @brief Clear the display buffer (does not update display)
 * Call SH1106_Request_Update() after this to update the display
 */
void SH1106_Clear(void);

/**
 * @brief Draw a pixel in the buffer (does not update display)
 */
void SH1106_DrawPixel(uint8_t x, uint8_t y, bool color);

/**
 * @brief Draw a character at specified position (does not update display)
 */
void SH1106_DrawChar(uint8_t x, uint8_t y, char c);

/**
 * @brief Draw a string at specified position (does not update display)
 */
void SH1106_DrawString(uint8_t x, uint8_t y, const char* str);

/**
 * @brief Draw a line between two points (does not update display)
 */
void SH1106_DrawLine(uint8_t x0, uint8_t y0, uint8_t x1, uint8_t y1);

/**
 * @brief Draw a rectangle outline (does not update display)
 */
void SH1106_DrawRect(uint8_t x, uint8_t y, uint8_t width, uint8_t height);

/**
 * @brief Fill a rectangle with white pixels (does not update display)
 */
void SH1106_FillRect(uint8_t x, uint8_t y, uint8_t width, uint8_t height);

/**
 * @brief Clear a rectangle (does not update display)
 */
void SH1106_ClearRect(uint8_t x, uint8_t y, uint8_t width, uint8_t height);

/**
 * @brief Set display contrast (blocking - use sparingly)
 */
void SH1106_SetContrast(uint8_t contrast);

/**
 * @brief Turn display on (blocking - use sparingly)
 */
void SH1106_DisplayOn(void);

/**
 * @brief Turn display off (blocking - use sparingly)
 */
void SH1106_DisplayOff(void);

/**
 * @brief Get display statistics for debugging
 * @param buffer Output buffer for statistics string
 * @param buffer_size Size of output buffer
 */
void SH1106_Get_Statistics(char* buffer, size_t buffer_size);

/**
 * @brief Test function to verify display works
 */
void SH1106_Test(void);

#endif /* SH1106_H */
