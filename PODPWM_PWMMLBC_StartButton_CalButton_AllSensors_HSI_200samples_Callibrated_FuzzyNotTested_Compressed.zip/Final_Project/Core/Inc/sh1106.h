/**
 * @file sh1106.h
 * @brief SH1106 OLED display driver header file
 * @author afuanandi & Claude
 */

#ifndef SH1106_H
#define SH1106_H

#include "main.h"
#include "i2c.h"
#include <stdbool.h>

/* SH1106 I2C address */
#define SH1106_I2C_ADDR         0x3C    // 7-bit address

/* SH1106 commands */
#define SH1106_SETCONTRAST      0x81
#define SH1106_DISPLAYALLON     0xA5
#define SH1106_DISPLAYALLON_RESUME 0xA4
#define SH1106_NORMALDISPLAY    0xA6
#define SH1106_INVERTDISPLAY    0xA7
#define SH1106_DISPLAYOFF       0xAE
#define SH1106_DISPLAYON        0xAF
#define SH1106_SETDISPLAYOFFSET 0xD3
#define SH1106_SETCOMPINS       0xDA
#define SH1106_SETVCOMDETECT    0xDB
#define SH1106_SETDISPLAYCLOCKDIV 0xD5
#define SH1106_SETPRECHARGE     0xD9
#define SH1106_SETMULTIPLEX     0xA8
#define SH1106_SETLOWCOLUMN     0x00
#define SH1106_SETHIGHCOLUMN    0x10
#define SH1106_SETSTARTLINE     0x40
#define SH1106_MEMORYMODE       0x20
#define SH1106_COLUMNADDR       0x21
#define SH1106_PAGEADDR         0x22
#define SH1106_COMSCANINC       0xC0
#define SH1106_COMSCANDEC       0xC8
#define SH1106_SEGREMAP         0xA0
#define SH1106_CHARGEPUMP       0x8D
#define SH1106_SETPAGEADDR      0xB0

/* Display dimensions */
#define SH1106_WIDTH            128
#define SH1106_HEIGHT           64
#define SH1106_PAGES            8

/* Control byte definitions */
#define SH1106_COMMAND          0x00
#define SH1106_DATA             0x40
#define SH1106_CONTROL_BYTE     0x00
#define SH1106_DATA_BYTE        0xC0

/* Function prototypes */
void SH1106_Init(void);
void SH1106_SendCommand(uint8_t cmd);
void SH1106_SendData(uint8_t data);
void SH1106_SetContrast(uint8_t contrast);
void SH1106_DisplayOn(void);
void SH1106_DisplayOff(void);
void SH1106_Clear(void);
void SH1106_SetCursor(uint8_t page, uint8_t column);
void SH1106_DrawPixel(uint8_t x, uint8_t y, bool color);
void SH1106_Update(void);
void SH1106_DrawChar(uint8_t x, uint8_t y, char c);
void SH1106_DrawString(uint8_t x, uint8_t y, const char* str);
void SH1106_DrawLine(uint8_t x0, uint8_t y0, uint8_t x1, uint8_t y1);
void SH1106_DrawRect(uint8_t x, uint8_t y, uint8_t width, uint8_t height);
void SH1106_FillRect(uint8_t x, uint8_t y, uint8_t width, uint8_t height);
void SH1106_ClearRect(uint8_t x, uint8_t y, uint8_t width, uint8_t height);

/* Test function */
void SH1106_Test(void);

#endif /* SH1106_H */
