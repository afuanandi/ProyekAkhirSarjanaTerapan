/**
 * @file dc_sensor.h
 * @brief DC Voltage and Current Sensor Module for MLBC System
 * @author afuanandi
 * @date 2025
 *
 * This module handles DC voltage and current sensing using ADC2 with simple polling.
 * Features dual operating modes: Normal (filtered readings) and Calibration (raw data).
 *
 * Hardware Configuration:
 * - ADC2 Channel 11 (PC1): DC Voltage sensing via AMC1100 (24V nominal, 28V max)
 * - ADC2 Channel 12 (PC2): DC Current sensing via AMC1100 (12A nominal, 25A protection)
 * - Continuous conversion mode with software triggering
 * - Simple polling approach (no DMA, no timer)
 *
 * Sampling Strategy:
 * - Continuous ADC conversion with rolling average filter
 * - 10ms update rate for fast protection response
 * - Simple averaging for noise reduction
 */

#ifndef DC_SENSOR_H
#define DC_SENSOR_H

#include "main.h"
#include "math.h"
#include <stdio.h>
#include <string.h>

/* DC Sensor Parameters */
#define DC_VOLTAGE_NOMINAL 24.0f             // 24V nominal DC voltage
#define DC_VOLTAGE_MAX 28.0f                 // 28V maximum DC voltage (voltage divider limit)
#define DC_CURRENT_NOMINAL 12.0f             // 12A nominal DC current
#define DC_CURRENT_PROTECTION 25.0f          // 25A overcurrent protection threshold

/* ADC Parameters */
#define DC_ADC_RESOLUTION 4096.0f            // 12-bit ADC (0-4095)
#define DC_ADC_VREF 3.3f                     // 3.3V reference voltage
#define DC_ADC_BITS 12                       // 12-bit resolution

/* Filtering and Averaging */
#define DC_AVERAGE_SAMPLES 10                // Number of samples for rolling average
#define DC_UPDATE_INTERVAL_MS 10             // Update every 10ms (fast response)

/* Protection Thresholds */
#define DC_OVERVOLTAGE_THRESHOLD 29.0f       // Overvoltage protection (V)
#define DC_OVERCURRENT_THRESHOLD 25.0f       // Overcurrent protection (A)
#define DC_UNDERVOLTAGE_THRESHOLD 20.0f      // Undervoltage warning (V)

/* Debug and Calibration */
#define DC_DEBUG_BUFFER_SIZE 100             // Debug string buffer size
#define DC_CALIBRATION_SAMPLES 20            // Samples to transmit in calibration mode

/**
 * @brief DC Sensor operation modes
 */
typedef enum {
    DC_SENSOR_MODE_NORMAL,                   // Normal operation with filtering
    DC_SENSOR_MODE_CALIBRATION              // Raw ADC data transmission
} DC_Sensor_Mode_t;

/**
 * @brief DC Sensor fault flags
 */
typedef enum {
    DC_SENSOR_FAULT_NONE = 0,
    DC_SENSOR_FAULT_OVERVOLTAGE = 1,
    DC_SENSOR_FAULT_OVERCURRENT = 2,
    DC_SENSOR_FAULT_UNDERVOLTAGE = 4,
    DC_SENSOR_FAULT_ADC_ERROR = 8
} DC_Sensor_Fault_t;

/**
 * @brief Main DC Sensor control structure
 */
typedef struct {
    /* Operation Mode */
    DC_Sensor_Mode_t mode;                   // Current operation mode

    /* Current Readings */
    float voltage;                           // Current DC voltage (V)
    float current;                           // Current DC current (A)

    /* Raw ADC Values */
    uint16_t voltage_adc_raw;                // Raw voltage ADC reading
    uint16_t current_adc_raw;                // Raw current ADC reading

    /* Rolling Average Buffers */
    uint16_t voltage_buffer[DC_AVERAGE_SAMPLES];  // Voltage averaging buffer
    uint16_t current_buffer[DC_AVERAGE_SAMPLES];  // Current averaging buffer
    uint8_t buffer_index;                    // Current buffer position
    uint8_t buffer_full;                     // Buffer filled flag

    /* Filtered ADC Values */
    float voltage_adc_filtered;              // Averaged voltage ADC reading
    float current_adc_filtered;              // Averaged current ADC reading

    /* Calibration Parameters */
    float voltage_scale_factor;              // Voltage scaling factor (V/ADC_count)
    float current_scale_factor;              // Current scaling factor (A/ADC_count)
    float voltage_offset;                    // Voltage offset compensation (ADC counts)
    float current_offset;                    // Current offset compensation (ADC counts)

    /* Protection and Monitoring */
    DC_Sensor_Fault_t fault_flags;          // Current fault conditions
    uint8_t protection_triggered;            // Protection flag for MLBC

    /* Statistics */
    uint32_t measurement_count;              // Total measurements completed
    uint32_t last_update_tick;               // Last update timestamp
    uint32_t fault_count;                    // Number of faults detected

    /* Debug and Calibration */
    uint8_t debug_flag;                      // Enable/disable debug output
    uint32_t calibration_counter;            // Calibration sample counter
    char debug_buffer[DC_DEBUG_BUFFER_SIZE]; // Debug message buffer

} DC_Sensor_TypeDef;

/* External Variables */
extern DC_Sensor_TypeDef dc_sensor;
extern ADC_HandleTypeDef hadc2;
extern UART_HandleTypeDef huart2;

/* Function Prototypes */

/**
 * @brief Initialize DC sensor system
 */
void DC_Sensor_Init(void);

/**
 * @brief Start DC sensor data acquisition
 */
void DC_Sensor_Start(void);

/**
 * @brief Stop DC sensor data acquisition
 */
void DC_Sensor_Stop(void);

/**
 * @brief Main update function (call from main loop every 10ms)
 * Reads ADC, applies filtering, and processes data
 */
void DC_Sensor_Update(void);

/**
 * @brief Set operation mode
 * @param mode: DC_SENSOR_MODE_NORMAL or DC_SENSOR_MODE_CALIBRATION
 */
void DC_Sensor_Set_Mode(DC_Sensor_Mode_t mode);

/**
 * @brief Get current operation mode
 * @return Current operation mode
 */
DC_Sensor_Mode_t DC_Sensor_Get_Mode(void);

/**
 * @brief Get DC voltage reading
 * @return DC voltage in Volts
 */
float DC_Sensor_Get_Voltage(void);

/**
 * @brief Get DC current reading
 * @return DC current in Amperes
 */
float DC_Sensor_Get_Current(void);

/**
 * @brief Get raw voltage ADC reading
 * @return Raw ADC value (0-4095)
 */
uint16_t DC_Sensor_Get_Voltage_Raw(void);

/**
 * @brief Get raw current ADC reading
 * @return Raw ADC value (0-4095)
 */
uint16_t DC_Sensor_Get_Current_Raw(void);

/**
 * @brief Set voltage calibration parameters
 * @param scale_factor: Scaling factor (V/ADC_count)
 * @param offset: Offset compensation (ADC counts)
 */
void DC_Sensor_Set_Voltage_Calibration(float scale_factor, float offset);

/**
 * @brief Set current calibration parameters
 * @param scale_factor: Scaling factor (A/ADC_count)
 * @param offset: Offset compensation (ADC counts)
 */
void DC_Sensor_Set_Current_Calibration(float scale_factor, float offset);

/**
 * @brief Check for fault conditions
 * @return Current fault flags
 */
DC_Sensor_Fault_t DC_Sensor_Check_Faults(void);

/**
 * @brief Clear specific fault
 * @param fault: Fault flag to clear
 */
void DC_Sensor_Clear_Fault(DC_Sensor_Fault_t fault);

/**
 * @brief Check if protection is triggered (for MLBC integration)
 * @return 1 if protection active, 0 if OK
 */
uint8_t DC_Sensor_Is_Protection_Triggered(void);

/**
 * @brief Set debug flag
 * @param flag: 1 to enable debug output, 0 to disable
 */
void DC_Sensor_Set_Debug(uint8_t flag);

/**
 * @brief Get sensor statistics string
 * @param buffer: Output buffer for statistics
 * @param buffer_size: Size of output buffer
 */
void DC_Sensor_Get_Statistics(char* buffer, size_t buffer_size);

/* Internal Processing Functions */

/**
 * @brief Read raw ADC values from both channels
 */
void DC_Sensor_Read_ADC(void);

/**
 * @brief Apply rolling average filter to ADC readings
 */
void DC_Sensor_Apply_Filter(void);

/**
 * @brief Apply calibration to convert ADC counts to real units
 */
void DC_Sensor_Apply_Calibration(void);

/**
 * @brief Process data in normal mode (filtering and calibration)
 */
void DC_Sensor_Process_Normal_Mode(void);

/**
 * @brief Process data in calibration mode (raw data transmission)
 */
void DC_Sensor_Process_Calibration_Mode(void);

/**
 * @brief Apply calibration to raw ADC value
 * @param raw_value: Raw ADC value
 * @param scale_factor: Scaling factor
 * @param offset: Offset compensation
 * @return Calibrated value
 */
float DC_Sensor_Apply_Single_Calibration(uint16_t raw_value, float scale_factor, float offset);

#endif /* DC_SENSOR_H */
