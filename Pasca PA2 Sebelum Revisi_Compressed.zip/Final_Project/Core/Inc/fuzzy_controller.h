/**
 * @file fuzzy_controller.h
 * @brief Simplified Type-1 Fuzzy Logic Controller
 * @author afuanandi & Claude
 * @date 2025
 *
 * SIMPLIFIED DESIGN:
 * - Type-1 fuzzy (removed Type-2 complexity)
 * - Variable-width MFs (Z narrow ±5V, edges wide)
 * - Error convention: Error = Vmeasured - Vsetpoint
 * - Input range: ±60V, Output range: [0, 2]
 */

#ifndef FUZZY_CONTROLLER_H
#define FUZZY_CONTROLLER_H

#include <stdint.h>
#include "main.h"

/* Configuration Parameters */
#define FUZZY_TARGET_VOLTAGE        220.0f      // AC RMS voltage setpoint (V)
#define FUZZY_INPUT_RANGE_MAX       60.0f       // Maximum error magnitude (V)
#define FUZZY_MAX_ERROR             60.0f       // Error limit for safety
#define FUZZY_DERIV_FILTER_ALPHA    0.75f        // Derivative filter coefficient
#define FUZZY_ERROR_GAIN            1.0f        // Error scaling factor
#define FUZZY_DERROR_GAIN           1.0f        // dError scaling factor
#define FUZZY_STARTUP_DELAY_ENABLE  0           // 1=Enable, 0=Disable
#define FUZZY_STARTUP_DELAY_MS      100         // Delay duration (ms)

/* ============================================================================
 * TYPE-1 FUZZY SYSTEM STRUCTURES
 * ============================================================================ */

/**
 * @brief Triangular Membership Function (Type-1)
 */
typedef struct {
    float a;                    // Left point
    float b;                    // Peak point
    float c;                    // Right point
    float upper;                // Upper membership (always 1.0 for Type-1)
    float lower;                // Lower membership (always 1.0 for Type-1)
    float lowerUncertainty;     // Not used in Type-1
    float upperUncertainty;     // Not used in Type-1
} TriangularMF;

/**
 * @brief Fuzzy Variable (Input or Output)
 */
typedef struct {
    char name[32];              // Variable name
    float min;                  // Minimum value
    float max;                  // Maximum value
    int numMFs;                 // Number of membership functions
    TriangularMF* mfs;          // Array of membership functions
} FuzzyVariable;

/**
 * @brief Fuzzy Rule
 */
typedef struct {
    int input1MF;               // Index of MF for input 1 (Error)
    int input2MF;               // Index of MF for input 2 (dError)
    int outputMF;               // Index of MF for output (mi)
    float weight;               // Rule weight (typically 1.0)
} FuzzyRule;

/**
 * @brief Complete Fuzzy System
 */
typedef struct {
    FuzzyVariable inputs[2];    // Error and dError
    FuzzyVariable output;       // Modulation Index (mi)
    FuzzyRule* rules;           // Array of rules
    int numRules;               // Number of rules (49 for 7x7)
} FuzzySystem;

/* ============================================================================
 * FUZZY CONTROLLER STATE MACHINE
 * ============================================================================ */

typedef enum {
    FUZZY_STATE_DISABLED    = 0,
    FUZZY_STATE_WAIT_MLBC   = 1,
    FUZZY_STATE_WAIT_STABLE = 2,
    FUZZY_STATE_NORMAL      = 3,
    FUZZY_STATE_FAULT       = 4
} FuzzyState_t;

/**
 * @brief Fuzzy Controller Structure
 */
typedef struct {
    /* State */
    FuzzyState_t state;
    uint8_t initialized;
    uint8_t new_data_available;

    /* Timing */
    uint32_t last_update_time;
    uint32_t startup_delay_start;

    /* Input signals */
    float voltage_measured;
    float error;
    float error_previous;
    float error_derivative;
    float error_derivative_filtered;

    /* Fuzzy processing */
    float fuzzy_error;
    float fuzzy_derror;
    float fuzzy_output_raw;
    float fuzzy_output_final;

    /* Statistics */
    uint32_t update_count;

    /* Debug */
    uint8_t debug_enabled;

} FuzzyController_t;

/* ============================================================================
 * FUNCTION PROTOTYPES
 * ============================================================================ */

extern FuzzySystem fuzzy_system;
extern FuzzyController_t fuzzy_controller;

/* Initialization */
void Fuzzy_Controller_Init(void);
int InitializeFuzzySystem(FuzzySystem* system);

/* Main control */
float Fuzzy_Controller_Update(void);

/* State management */
void Fuzzy_Controller_Enable(void);
void Fuzzy_Controller_Disable(void);
FuzzyState_t Fuzzy_Controller_Get_State(void);

/* Helper functions */
uint8_t Fuzzy_Controller_Is_Active(void);
float Fuzzy_Controller_Get_Output(void);
void Fuzzy_Controller_Get_Statistics(char* buffer, size_t buffer_size);
float Fuzzy_Controller_Get_Target_Voltage(void);
void Fuzzy_Controller_Set_Debug(uint8_t enable);

/* Debug */
void Fuzzy_Controller_Debug_Enable(void);
void Fuzzy_Controller_Debug_Disable(void);
void Fuzzy_Controller_Debug_Transmit(void);

#endif /* FUZZY_CONTROLLER_H */
