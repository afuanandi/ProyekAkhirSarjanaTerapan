/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32f4xx_hal.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */

/* System State Definitions */
typedef enum {
    SYSTEM_STATE_OFF,               // Everything off, relay open
    SYSTEM_STATE_STARTING,          // Relay closed, MLBC soft-starting
    SYSTEM_STATE_RUNNING,           // Normal operation
    SYSTEM_STATE_SHUTDOWN_DELAY,    // Relay open, discharging capacitors
    SYSTEM_STATE_SHUTDOWN_COMPLETE  // Discharge complete, ready to turn off
} SystemState_t;

/**
 * @brief System operation modes
 */
typedef enum {
    SYSTEM_MODE_OPEN_LOOP,      // Manual modulation index control
    SYSTEM_MODE_CLOSED_LOOP     // Fuzzy controller control
} SystemMode_t;

/**
 * @brief Sensor modes
 */
typedef enum {
    SENSOR_MODE_NORMAL,         // Normal operation
    SENSOR_MODE_CALIBRATION     // Calibration mode
} SensorMode_t;

/* Calibration state machine */
typedef enum {
    CALIB_STATE_IDLE,           // Not in calibration mode
    CALIB_STATE_AC_COLLECTING,  // AC sensor collecting data
    CALIB_STATE_AC_TRANSMIT,    // Transmitting AC data
    CALIB_STATE_DC_COLLECTING,  // DC sensor collecting data
    CALIB_STATE_DC_TRANSMIT,    // Transmitting DC data
    CALIB_STATE_COMPLETE        // Calibration complete
} CalibrationState_t;

/**
 * @brief Monitoring modes
 */
typedef enum {
    MONITORING_MODE_OFF,        // Normal operation, no CSV logging
    MONITORING_MODE_ON          // Real-time CSV data logging enabled
} MonitoringMode_t;

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
#define B1_Pin GPIO_PIN_13
#define B1_GPIO_Port GPIOC
#define DC_Voltage_Pin GPIO_PIN_1
#define DC_Voltage_GPIO_Port GPIOC
#define DC_Current_Pin GPIO_PIN_2
#define DC_Current_GPIO_Port GPIOC
#define AC_Voltage_Pin GPIO_PIN_1
#define AC_Voltage_GPIO_Port GPIOA
#define USART_TX_Pin GPIO_PIN_2
#define USART_TX_GPIO_Port GPIOA
#define USART_RX_Pin GPIO_PIN_3
#define USART_RX_GPIO_Port GPIOA
#define AC_Current_Pin GPIO_PIN_4
#define AC_Current_GPIO_Port GPIOA
#define LD2_Pin GPIO_PIN_5
#define LD2_GPIO_Port GPIOA
#define S7_Pin GPIO_PIN_7
#define S7_GPIO_Port GPIOA
#define S6_Pin GPIO_PIN_0
#define S6_GPIO_Port GPIOB
#define S5_Pin GPIO_PIN_13
#define S5_GPIO_Port GPIOB
#define S8_Pin GPIO_PIN_14
#define S8_GPIO_Port GPIOB
#define S3_Pin GPIO_PIN_6
#define S3_GPIO_Port GPIOC
#define S4_Pin GPIO_PIN_7
#define S4_GPIO_Port GPIOC
#define S1_Pin GPIO_PIN_8
#define S1_GPIO_Port GPIOA
#define S2_Pin GPIO_PIN_9
#define S2_GPIO_Port GPIOA
#define RELAY_CTRL_Pin GPIO_PIN_12
#define RELAY_CTRL_GPIO_Port GPIOA
#define TMS_Pin GPIO_PIN_13
#define TMS_GPIO_Port GPIOA
#define TCK_Pin GPIO_PIN_14
#define TCK_GPIO_Port GPIOA
#define SWO_Pin GPIO_PIN_3
#define SWO_GPIO_Port GPIOB
#define MONITORING_Pin GPIO_PIN_4
#define MONITORING_GPIO_Port GPIOB
#define SENSOR_MODE_Pin GPIO_PIN_5
#define SENSOR_MODE_GPIO_Port GPIOB
#define MODE_Pin GPIO_PIN_8
#define MODE_GPIO_Port GPIOB
#define START_STOP_Pin GPIO_PIN_9
#define START_STOP_GPIO_Port GPIOB

/* USER CODE BEGIN Private defines */

/* Debug Control */
#define ENABLE_POD_PWM_DEBUG 0			        // 1 = Enable POD PWM debug, 0 = Disable
#define ENABLE_MLBC_DEBUG  0 					// 1 = Enable MLBC debug, 0 = Disable
#define ENABLE_AC_SENSOR_DEBUG 0
#define ENABLE_DC_SENSOR_DEBUG 0
#define ENABLE_FUZZY_DEBUG 0
#define ENABLE_I2C_DEBUG 0              		// 1 = Enable I2C/OLED debug, 0 = Disable
#define ENABLE_EMI_DEBUG 0              		// 1 = Enable EMI filter debug, 0 = Disable

#define TRUE_PWM 0                     			// 0 = Step-wise method (original)
												// 1 = True carrier comparison (under development)

#define MANUAL_MODULATION_INDEX_DEFAULT 1.0f    // Default MI for open loop
#define MANUAL_DUTY_CYCLE_DEFAULT 0.692f        // Default duty cycle for MLBC
#define FUZZY_TARGET_VOLTAGE 220.0f             // Target voltage (V RMS)

/* Relay Control Macros - ACTIVE LOW LOGIC (L jumper setting) */
#define RELAY_ON()   HAL_GPIO_WritePin(RELAY_CTRL_GPIO_Port, RELAY_CTRL_Pin, GPIO_PIN_RESET)  // LOW
#define RELAY_OFF()  HAL_GPIO_WritePin(RELAY_CTRL_GPIO_Port, RELAY_CTRL_Pin, GPIO_PIN_SET)    // HIGH

/* Shutdown discharge time (5 seconds) */
#define SHUTDOWN_DISCHARGE_TIME_MS  5000

/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */
