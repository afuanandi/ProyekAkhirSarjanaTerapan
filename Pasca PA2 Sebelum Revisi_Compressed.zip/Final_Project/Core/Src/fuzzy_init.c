/**
 * @file fuzzy_init.c
 * @brief Simplified Type-1 Fuzzy System Initialization
 * @author afuanandi & Claude
 * @date 2025
 *
 * SIMPLIFIED DESIGN:
 * - Type-1 fuzzy (removed Type-2 complexity)
 * - Variable-width MFs: Z narrow (±5V), edges wide (±20-30V)
 * - Corrected rule base: Error negative → MI increase
 */

#include "fuzzy_controller.h"
#include <string.h>
#include <stdlib.h>
#include <stdio.h>

/**
 * @brief Initialize the Type-1 fuzzy logic system
 */
int InitializeFuzzySystem(FuzzySystem* system) {
    if (system == NULL) {
        return -1;
    }

    /* ========================================================================
     * INPUT 1: Error (Voltage Error)
     * Range: [-60, 60] volts
     * Variable-width MFs: narrow center (±5V), wide edges (±20-30V)
     * ======================================================================== */
    strcpy(system->inputs[0].name, "Error");
    system->inputs[0].min = -60.0f;
    system->inputs[0].max = 60.0f;
    system->inputs[0].numMFs = 7;
    system->inputs[0].mfs = (TriangularMF*)malloc(7 * sizeof(TriangularMF));

    if (system->inputs[0].mfs == NULL) {
        return -1;
    }

    /* Error MFs */
    system->inputs[0].mfs[0] = (TriangularMF){-60.0f, -50.0f, -30.0f, 1.0f, 1.0f, 0, 0};  // NB
    system->inputs[0].mfs[1] = (TriangularMF){-40.0f, -25.0f, -10.0f, 1.0f, 1.0f, 0, 0};  // NM
    system->inputs[0].mfs[2] = (TriangularMF){-15.0f, -5.0f, 0.0f, 1.0f, 1.0f, 0, 0};     // NS
    system->inputs[0].mfs[3] = (TriangularMF){-5.0f, 0.0f, 5.0f, 1.0f, 1.0f, 0, 0};       // Z
    system->inputs[0].mfs[4] = (TriangularMF){0.0f, 5.0f, 15.0f, 1.0f, 1.0f, 0, 0};       // PS
    system->inputs[0].mfs[5] = (TriangularMF){10.0f, 25.0f, 40.0f, 1.0f, 1.0f, 0, 0};     // PM
    system->inputs[0].mfs[6] = (TriangularMF){30.0f, 50.0f, 60.0f, 1.0f, 1.0f, 0, 0};     // PB

    /* ========================================================================
     * INPUT 2: dError (Error Derivative)
     * Same structure as Error input
     * ======================================================================== */
    strcpy(system->inputs[1].name, "dError");
    system->inputs[1].min = -60.0f;
    system->inputs[1].max = 60.0f;
    system->inputs[1].numMFs = 7;
    system->inputs[1].mfs = (TriangularMF*)malloc(7 * sizeof(TriangularMF));

    if (system->inputs[1].mfs == NULL) {
        free(system->inputs[0].mfs);
        return -1;
    }

    /* Copy same MF structure */
    memcpy(system->inputs[1].mfs, system->inputs[0].mfs, 7 * sizeof(TriangularMF));

    /* ========================================================================
     * OUTPUT: mi (Modulation Index)
     * Range: [0, 2] - NO NEGATIVE VALUES
     * ======================================================================== */
    strcpy(system->output.name, "mi");
    system->output.min = 0.0f;
    system->output.max = 2.0f;
    system->output.numMFs = 7;
    system->output.mfs = (TriangularMF*)malloc(7 * sizeof(TriangularMF));

    if (system->output.mfs == NULL) {
        free(system->inputs[0].mfs);
        free(system->inputs[1].mfs);
        return -1;
    }

    /* Output MFs - CORRECTED (no negative values) */
    system->output.mfs[0] = (TriangularMF){0.0f, 0.167f, 0.333f, 1.0f, 1.0f, 0, 0};      // NB
    system->output.mfs[1] = (TriangularMF){0.167f, 0.5f, 0.833f, 1.0f, 1.0f, 0, 0};      // NM
    system->output.mfs[2] = (TriangularMF){0.5f, 0.75f, 1.0f, 1.0f, 1.0f, 0, 0};         // NS
    system->output.mfs[3] = (TriangularMF){0.917f, 1.0f, 1.083f, 1.0f, 1.0f, 0, 0};      // Z
    system->output.mfs[4] = (TriangularMF){1.0f, 1.25f, 1.5f, 1.0f, 1.0f, 0, 0};         // PS
    system->output.mfs[5] = (TriangularMF){1.333f, 1.667f, 2.0f, 1.0f, 1.0f, 0, 0};      // PM
    system->output.mfs[6] = (TriangularMF){1.667f, 1.833f, 2.0f, 1.0f, 1.0f, 0, 0};      // PB

    /* ========================================================================
     * RULE BASE: 49 rules (7x7)
     * CORRECTED - Error = Vmeasured - Vsetpoint
     * Negative error → Voltage LOW → INCREASE MI
     * Positive error → Voltage HIGH → DECREASE MI
     * ======================================================================== */
    system->numRules = 49;
    system->rules = (FuzzyRule*)malloc(49 * sizeof(FuzzyRule));

    if (system->rules == NULL) {
        free(system->inputs[0].mfs);
        free(system->inputs[1].mfs);
        free(system->output.mfs);
        return -1;
    }

    /* Row 1: Error=NB (0) - Voltage VERY LOW → INCREASE MI */
    system->rules[0]  = (FuzzyRule){0, 0, 6, 1.0f};  // NB-NB → PB
    system->rules[1]  = (FuzzyRule){0, 1, 6, 1.0f};  // NB-NM → PB
    system->rules[2]  = (FuzzyRule){0, 2, 5, 1.0f};  // NB-NS → PM
    system->rules[3]  = (FuzzyRule){0, 3, 5, 1.0f};  // NB-Z  → PM
    system->rules[4]  = (FuzzyRule){0, 4, 4, 1.0f};  // NB-PS → PS
    system->rules[5]  = (FuzzyRule){0, 5, 4, 1.0f};  // NB-PM → PS
    system->rules[6]  = (FuzzyRule){0, 6, 3, 1.0f};  // NB-PB → Z

    /* Row 2: Error=NM (1) - Voltage LOW → INCREASE MI */
    system->rules[7]  = (FuzzyRule){1, 0, 6, 1.0f};  // NM-NB → PB
    system->rules[8]  = (FuzzyRule){1, 1, 5, 1.0f};  // NM-NM → PM
    system->rules[9]  = (FuzzyRule){1, 2, 5, 1.0f};  // NM-NS → PM
    system->rules[10] = (FuzzyRule){1, 3, 4, 1.0f};  // NM-Z  → PS
    system->rules[11] = (FuzzyRule){1, 4, 4, 1.0f};  // NM-PS → PS
    system->rules[12] = (FuzzyRule){1, 5, 3, 1.0f};  // NM-PM → Z
    system->rules[13] = (FuzzyRule){1, 6, 2, 1.0f};  // NM-PB → NS

    /* Row 3: Error=NS (2) - Voltage SLIGHTLY LOW → INCREASE MI */
    system->rules[14] = (FuzzyRule){2, 0, 5, 1.0f};  // NS-NB → PM
    system->rules[15] = (FuzzyRule){2, 1, 5, 1.0f};  // NS-NM → PM
    system->rules[16] = (FuzzyRule){2, 2, 4, 1.0f};  // NS-NS → PS
    system->rules[17] = (FuzzyRule){2, 3, 4, 1.0f};  // NS-Z  → PS
    system->rules[18] = (FuzzyRule){2, 4, 3, 1.0f};  // NS-PS → Z
    system->rules[19] = (FuzzyRule){2, 5, 2, 1.0f};  // NS-PM → NS
    system->rules[20] = (FuzzyRule){2, 6, 2, 1.0f};  // NS-PB → NS

    /* Row 4: Error=Z (3) - Voltage AT TARGET → DERIVATIVE CONTROL */
    system->rules[21] = (FuzzyRule){3, 0, 5, 1.0f};  // Z-NB  → PM
    system->rules[22] = (FuzzyRule){3, 1, 4, 1.0f};  // Z-NM  → PS
    system->rules[23] = (FuzzyRule){3, 2, 3, 1.0f};  // Z-NS  → Z
    system->rules[24] = (FuzzyRule){3, 3, 3, 1.0f};  // Z-Z   → Z ★ STEADY STATE
    system->rules[25] = (FuzzyRule){3, 4, 3, 1.0f};  // Z-PS  → Z
    system->rules[26] = (FuzzyRule){3, 5, 2, 1.0f};  // Z-PM  → NS
    system->rules[27] = (FuzzyRule){3, 6, 1, 1.0f};  // Z-PB  → NM

    /* Row 5: Error=PS (4) - Voltage SLIGHTLY HIGH → DECREASE MI */
    system->rules[28] = (FuzzyRule){4, 0, 4, 1.0f};  // PS-NB → PS
    system->rules[29] = (FuzzyRule){4, 1, 4, 1.0f};  // PS-NM → PS
    system->rules[30] = (FuzzyRule){4, 2, 3, 1.0f};  // PS-NS → Z
    system->rules[31] = (FuzzyRule){4, 3, 2, 1.0f};  // PS-Z  → NS
    system->rules[32] = (FuzzyRule){4, 4, 2, 1.0f};  // PS-PS → NS
    system->rules[33] = (FuzzyRule){4, 5, 1, 1.0f};  // PS-PM → NM
    system->rules[34] = (FuzzyRule){4, 6, 1, 1.0f};  // PS-PB → NM

    /* Row 6: Error=PM (5) - Voltage HIGH → DECREASE MI */
    system->rules[35] = (FuzzyRule){5, 0, 4, 1.0f};  // PM-NB → PS
    system->rules[36] = (FuzzyRule){5, 1, 3, 1.0f};  // PM-NM → Z
    system->rules[37] = (FuzzyRule){5, 2, 2, 1.0f};  // PM-NS → NS
    system->rules[38] = (FuzzyRule){5, 3, 2, 1.0f};  // PM-Z  → NS
    system->rules[39] = (FuzzyRule){5, 4, 1, 1.0f};  // PM-PS → NM
    system->rules[40] = (FuzzyRule){5, 5, 1, 1.0f};  // PM-PM → NM
    system->rules[41] = (FuzzyRule){5, 6, 0, 1.0f};  // PM-PB → NB

    /* Row 7: Error=PB (6) - Voltage VERY HIGH → DECREASE MI */
    system->rules[42] = (FuzzyRule){6, 0, 3, 1.0f};  // PB-NB → Z
    system->rules[43] = (FuzzyRule){6, 1, 2, 1.0f};  // PB-NM → NS
    system->rules[44] = (FuzzyRule){6, 2, 2, 1.0f};  // PB-NS → NS
    system->rules[45] = (FuzzyRule){6, 3, 1, 1.0f};  // PB-Z  → NM
    system->rules[46] = (FuzzyRule){6, 4, 1, 1.0f};  // PB-PS → NM
    system->rules[47] = (FuzzyRule){6, 5, 0, 1.0f};  // PB-PM → NB
    system->rules[48] = (FuzzyRule){6, 6, 0, 1.0f};  // PB-PB → NB

    printf("Fuzzy system initialized with %d rules\n", system->numRules);
    return 0;
}
