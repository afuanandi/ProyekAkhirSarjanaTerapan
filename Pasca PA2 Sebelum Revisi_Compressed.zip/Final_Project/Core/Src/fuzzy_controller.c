/**
 * @file fuzzy_controller.c
 * @brief Simplified Type-1 Fuzzy Logic Controller Implementation
 * @author afuanandi & Claude
 * @date 2025
 *
 * SIMPLIFIED DESIGN:
 * - Type-1 fuzzy (removed Type-2 complexity that was causing bugs)
 * - Standard Mamdani inference with centroid defuzzification
 * - Variable-width MFs (Z narrow ±5V, edges wide)
 * - Error convention: Error = Vmeasured - Vsetpoint
 */

#include "fuzzy_controller.h"
#include "ac_sensor.h"
#include <stdio.h>
#include <math.h>
#include <string.h>

/* Controller instance */
FuzzyController_t fuzzy_controller = {0};

/* Fuzzy system instance */
FuzzySystem fuzzy_system = {0};

/* Internal function prototypes */
static float Triangular_MF(float x, float a, float b, float c);
static float Fuzzy_Inference_Simple(float error, float derror);

/**
 * @brief Initialize fuzzy controller
 */
void Fuzzy_Controller_Init(void) {
    /* Initialize structure */
    memset(&fuzzy_controller, 0, sizeof(FuzzyController_t));

    fuzzy_controller.state = FUZZY_STATE_DISABLED;
    fuzzy_controller.voltage_measured = FUZZY_TARGET_VOLTAGE;
    fuzzy_controller.fuzzy_output_final = 1.0f;
    fuzzy_controller.debug_enabled = 0;

    /* Initialize Type-1 fuzzy system */
    if(InitializeFuzzySystem(&fuzzy_system) == 0) {
        fuzzy_controller.initialized = 1;
        printf("Fuzzy Controller: Simplified Type-1 Mamdani\n");
        printf("Input: +/-%.0fV, Output: [0-2]\n", FUZZY_INPUT_RANGE_MAX);
        printf("Gains: Error=%.1f, dError=%.1f\n", FUZZY_ERROR_GAIN, FUZZY_DERROR_GAIN);
    } else {
        fuzzy_controller.state = FUZZY_STATE_FAULT;
        printf("ERROR: Fuzzy system initialization failed\n");
    }
}

/**
 * @brief Enable fuzzy controller
 */
void Fuzzy_Controller_Enable(void) {
    if(!fuzzy_controller.initialized) return;

    fuzzy_controller.fuzzy_output_raw = 1.0f;
    fuzzy_controller.fuzzy_output_final = 1.0f;
    fuzzy_controller.voltage_measured = AC_Sensor_Get_Voltage_RMS();
    fuzzy_controller.error = 0.0f;
    fuzzy_controller.error_previous = 0.0f;
    fuzzy_controller.error_derivative = 0.0f;
    fuzzy_controller.error_derivative_filtered = 0.0f;
    fuzzy_controller.last_update_time = HAL_GetTick();
    fuzzy_controller.startup_delay_start = HAL_GetTick();
    fuzzy_controller.state = FUZZY_STATE_WAIT_MLBC;
    fuzzy_controller.new_data_available = 1;

    printf("Fuzzy: Enabled with bumpless transfer (MI=1.0)\n");
}

/**
 * @brief Disable fuzzy controller
 */
void Fuzzy_Controller_Disable(void) {
    fuzzy_controller.state = FUZZY_STATE_DISABLED;
    fuzzy_controller.new_data_available = 0;
    printf("Fuzzy: Disabled\n");
}

/**
 * @brief Main fuzzy controller update
 */
float Fuzzy_Controller_Update(void) {
    uint32_t current_time = HAL_GetTick();

    if(fuzzy_controller.state == FUZZY_STATE_DISABLED ||
       fuzzy_controller.state == FUZZY_STATE_FAULT) {
        return fuzzy_controller.fuzzy_output_final;
    }

    /* State machine */
    switch(fuzzy_controller.state) {
        case FUZZY_STATE_WAIT_MLBC:
            #if FUZZY_STARTUP_DELAY_ENABLE && (FUZZY_STARTUP_DELAY_MS > 0)
            fuzzy_controller.startup_delay_start = current_time;
            fuzzy_controller.state = FUZZY_STATE_WAIT_STABLE;
            fuzzy_controller.new_data_available = 1;
            printf("Fuzzy: Entering startup delay\n");
            #else
            fuzzy_controller.state = FUZZY_STATE_NORMAL;
            fuzzy_controller.new_data_available = 1;
            printf("Fuzzy: Regulation active (delay disabled)\n");
            #endif
            return fuzzy_controller.fuzzy_output_final;

        case FUZZY_STATE_WAIT_STABLE:
            if((current_time - fuzzy_controller.startup_delay_start) >= FUZZY_STARTUP_DELAY_MS) {
                fuzzy_controller.state = FUZZY_STATE_NORMAL;
                fuzzy_controller.new_data_available = 1;
                printf("Fuzzy: Startup delay complete, regulation active\n");
            }
            return fuzzy_controller.fuzzy_output_final;

        case FUZZY_STATE_NORMAL:
            break;

        default:
            return fuzzy_controller.fuzzy_output_final;
    }

    /* Get measured voltage - already filtered by AC sensor */
    fuzzy_controller.voltage_measured = AC_Sensor_Get_Voltage_RMS();

    /* Calculate error directly (no filterg) */
    fuzzy_controller.error = fuzzy_controller.voltage_measured - FUZZY_TARGET_VOLTAGE;

    /* Calculate derivative */
    fuzzy_controller.error_derivative =
        fuzzy_controller.error - fuzzy_controller.error_previous;

    /* Filter derivative only (derivatives amplify noise) */
    fuzzy_controller.error_derivative_filtered =
        FUZZY_DERIV_FILTER_ALPHA * fuzzy_controller.error_derivative +
        (1.0f - FUZZY_DERIV_FILTER_ALPHA) * fuzzy_controller.error_derivative_filtered;

    fuzzy_controller.error_previous = fuzzy_controller.error;

    /* Scale inputs */
    fuzzy_controller.fuzzy_error = fuzzy_controller.error * FUZZY_ERROR_GAIN;
    fuzzy_controller.fuzzy_derror = fuzzy_controller.error_derivative_filtered * FUZZY_DERROR_GAIN;

    /* Safety check */
    if(fabsf(fuzzy_controller.fuzzy_error) > FUZZY_MAX_ERROR) {
        fuzzy_controller.state = FUZZY_STATE_FAULT;
        fuzzy_controller.new_data_available = 1;
        printf("FAULT: Error magnitude %.1fV exceeds limit %.1fV\n",
               fabsf(fuzzy_controller.fuzzy_error), FUZZY_MAX_ERROR);
        return fuzzy_controller.fuzzy_output_final;
    }

    /* Perform fuzzy inference */
    fuzzy_controller.fuzzy_output_raw = Fuzzy_Inference_Simple(
        fuzzy_controller.fuzzy_error,
        fuzzy_controller.fuzzy_derror);

    /* Direct assignment */
    fuzzy_controller.fuzzy_output_final = fuzzy_controller.fuzzy_output_raw;

    /* Clamp to valid range [0, 2] */
    if(fuzzy_controller.fuzzy_output_final < 0.0f) {
        fuzzy_controller.fuzzy_output_final = 0.0f;
    }
    if(fuzzy_controller.fuzzy_output_final > 2.0f) {
        fuzzy_controller.fuzzy_output_final = 2.0f;
    }

    fuzzy_controller.update_count++;
    fuzzy_controller.last_update_time = current_time;
    fuzzy_controller.new_data_available = 1;

    return fuzzy_controller.fuzzy_output_final;
}

/**
 * @brief Simplified fuzzy inference engine
 */
static float Fuzzy_Inference_Simple(float error, float derror) {
    /* Input MF membership grades */
    float error_memberships[7] = {0};
    float derror_memberships[7] = {0};

    /* Calculate error memberships */
    for(int i = 0; i < 7; i++) {
        error_memberships[i] = Triangular_MF(error,
            fuzzy_system.inputs[0].mfs[i].a,
            fuzzy_system.inputs[0].mfs[i].b,
            fuzzy_system.inputs[0].mfs[i].c);
    }

    /* Calculate derror memberships */
    for(int i = 0; i < 7; i++) {
        derror_memberships[i] = Triangular_MF(derror,
            fuzzy_system.inputs[1].mfs[i].a,
            fuzzy_system.inputs[1].mfs[i].b,
            fuzzy_system.inputs[1].mfs[i].c);
    }

    /* Rule evaluation with weighted sum defuzzification */
    float numerator = 0.0f;
    float denominator = 0.0f;

    for(int r = 0; r < fuzzy_system.numRules; r++) {
        FuzzyRule* rule = &fuzzy_system.rules[r];

        /* Get memberships for this rule's antecedents */
        float mu_error = error_memberships[rule->input1MF];
        float mu_derror = derror_memberships[rule->input2MF];

        /* Rule firing strength (MIN operator) */
        float firing_strength = fminf(mu_error, mu_derror) * rule->weight;

        /* Get consequent center */
        float output_center = fuzzy_system.output.mfs[rule->outputMF].b;

        /* Accumulate weighted sum */
        numerator += firing_strength * output_center;
        denominator += firing_strength;
    }

    /* Centroid defuzzification */
    float crisp_output = 1.0f;  // Default
    if(denominator > 0.0001f) {
        crisp_output = numerator / denominator;
    }

    return crisp_output;
}

/**
 * @brief Triangular membership function
 */
static float Triangular_MF(float x, float a, float b, float c) {
    if(x <= a || x >= c) {
        return 0.0f;
    } else if(x == b) {
        return 1.0f;
    } else if(x < b) {
        return (x - a) / (b - a);
    } else {
        return (c - x) / (c - b);
    }
}

/* Accessor functions */
FuzzyState_t Fuzzy_Controller_Get_State(void) {
    return fuzzy_controller.state;
}

uint8_t Fuzzy_Controller_Is_Active(void) {
    return (fuzzy_controller.state == FUZZY_STATE_NORMAL);
}

float Fuzzy_Controller_Get_Output(void) {
    return fuzzy_controller.fuzzy_output_final;
}

float Fuzzy_Controller_Get_Target_Voltage(void) {
    return FUZZY_TARGET_VOLTAGE;
}

void Fuzzy_Controller_Set_Debug(uint8_t enable) {
    if(enable) {
        Fuzzy_Controller_Debug_Enable();
    } else {
        Fuzzy_Controller_Debug_Disable();
    }
}

void Fuzzy_Controller_Debug_Enable(void) {
    fuzzy_controller.debug_enabled = 1;
    printf("Fuzzy: Debug enabled\n");
}

void Fuzzy_Controller_Debug_Disable(void) {
    fuzzy_controller.debug_enabled = 0;
    printf("Fuzzy: Debug disabled\n");
}

void Fuzzy_Controller_Debug_Transmit(void) {
    if(!fuzzy_controller.debug_enabled || !fuzzy_controller.new_data_available) {
        return;
    }

    printf("FUZZY,%.1f,%.3f,%.3f,%.3f,%.3f,%.3f,%.3f,%.3f,%d\r\n",
           fuzzy_controller.voltage_measured,
           fuzzy_controller.error,
           fuzzy_controller.error_derivative,
           fuzzy_controller.error_derivative_filtered,
           fuzzy_controller.fuzzy_error,
           fuzzy_controller.fuzzy_derror,
           fuzzy_controller.fuzzy_output_raw,
           fuzzy_controller.fuzzy_output_final,
           fuzzy_controller.state);

    fuzzy_controller.new_data_available = 0;
}

void Fuzzy_Controller_Get_Statistics(char* buffer, size_t buffer_size) {
    snprintf(buffer, buffer_size,
             "Fuzzy Controller: State=%d, Updates=%lu, MI=%.3f, Error=%.2fV",
             fuzzy_controller.state,
             fuzzy_controller.update_count,
             fuzzy_controller.fuzzy_output_final,
             fuzzy_controller.error);
}
