/**
 * @file emi_filter.c
 * @brief Simplified EMI filtering implementation
 */

#include "emi_filter.h"
#include <stdio.h>
#include <string.h>

/* Global EMI filter instance */
EMI_Filter_t emi_filter;

/**
 * @brief Initialize EMI filter system
 */
void EMI_Filter_Init(void) {
    memset(&emi_filter, 0, sizeof(EMI_Filter_t));
    emi_filter.debug_enabled = 0;
    printf("EMI Filter initialized (simplified)\r\n");
}

/**
 * @brief Process I2C operation result through EMI filter
 */
EMI_Result_t EMI_Filter_Process_Result(HAL_StatusTypeDef operation_result, uint8_t retry_count) {
    emi_filter.total_operations++;

    if(operation_result == HAL_OK) {
        // SUCCESS
        return EMI_RESULT_SUCCESS;
    } else {
        // FAILURE
        emi_filter.total_failures++;

        if(emi_filter.debug_enabled) {
            printf("EMI: I2C operation failed (retry %d/%d)\r\n", retry_count, EMI_MAX_RETRY_ATTEMPTS);
        }

        // Check max retries
        if(retry_count >= EMI_MAX_RETRY_ATTEMPTS) {
            emi_filter.skipped_operations++;
            if(emi_filter.debug_enabled) {
                printf("EMI: Operation skipped after %d retries\r\n", retry_count);
            }
            return EMI_RESULT_SKIP_CHUNK;
        }

        // Setup simple retry delay
        emi_filter.retry_delay_start = HAL_GetTick();
        emi_filter.in_retry_delay = 1;

        if(emi_filter.debug_enabled) {
            printf("EMI: Retrying in %dms\r\n", EMI_RETRY_DELAY_MS);
        }

        return EMI_RESULT_RETRY_LATER;
    }
}

/**
 * @brief Check if retry delay has completed
 */
uint8_t EMI_Filter_Is_Retry_Ready(void) {
    if(!emi_filter.in_retry_delay) {
        return 1;
    }

    uint32_t elapsed = HAL_GetTick() - emi_filter.retry_delay_start;
    if(elapsed >= EMI_RETRY_DELAY_MS) {
        emi_filter.in_retry_delay = 0;
        return 1;
    }

    return 0;
}

void EMI_Filter_Set_Debug(uint8_t enable) {
    emi_filter.debug_enabled = enable;
    printf("EMI Filter debug %s\r\n", enable ? "enabled" : "disabled");
}

void EMI_Filter_Get_Statistics(char* buffer, size_t buffer_size) {
    float success_rate = emi_filter.total_operations > 0 ?
        (100.0f * (emi_filter.total_operations - emi_filter.total_failures) / emi_filter.total_operations) : 0.0f;

    snprintf(buffer, buffer_size,
        "EMI: Success=%.1f%%, Failures=%lu, Skipped=%lu",
        success_rate,
        emi_filter.total_failures,
        emi_filter.skipped_operations);
}

void EMI_Filter_Reset(void) {
    memset(&emi_filter, 0, sizeof(EMI_Filter_t));
    printf("EMI Filter reset\r\n");
}
