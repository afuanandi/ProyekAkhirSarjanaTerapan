/**
 * @file dc_sensor.c
 * @brief DC Voltage and Current Sensor Module Implementation
 */

#include "dc_sensor.h"

/* Global DC Sensor structure */
DC_Sensor_TypeDef dc_sensor;

/**
 * @brief Initialize DC sensor system
 */
void DC_Sensor_Init(void) {
    /* Initialize structure */
    dc_sensor.mode = DC_SENSOR_MODE_NORMAL;
    dc_sensor.voltage = 0.0f;
    dc_sensor.current = 0.0f;
    dc_sensor.voltage_adc_raw = 0;
    dc_sensor.current_adc_raw = 0;
    dc_sensor.voltage_adc_filtered = 0.0f;
    dc_sensor.current_adc_filtered = 0.0f;

    /* Initialize averaging buffers */
    memset(dc_sensor.voltage_buffer, 0, sizeof(dc_sensor.voltage_buffer));
    memset(dc_sensor.current_buffer, 0, sizeof(dc_sensor.current_buffer));
    dc_sensor.buffer_index = 0;
    dc_sensor.buffer_full = 0;

    /* Initialize calibration parameters (default estimates) */
    /* These should be calibrated based on your AMC1100 conditioning circuit */
    /* TODO: Callibrate */
    dc_sensor.voltage_scale_factor = DC_VOLTAGE_NOMINAL / (DC_ADC_RESOLUTION * 0.7f);  // Rough estimate
    dc_sensor.current_scale_factor = DC_CURRENT_NOMINAL / (DC_ADC_RESOLUTION * 0.7f);  // Rough estimate
    dc_sensor.voltage_offset = 0.0f;  // Assume no offset for DC
    dc_sensor.current_offset = 0.0f;  // Assume no offset for DC

    /* Initialize protection and monitoring */
    dc_sensor.fault_flags = DC_SENSOR_FAULT_NONE;
    dc_sensor.protection_triggered = 0;
    dc_sensor.measurement_count = 0;
    dc_sensor.last_update_tick = HAL_GetTick();
    dc_sensor.fault_count = 0;

    /* Initialize debug */
    dc_sensor.debug_flag = 0;
    dc_sensor.calibration_counter = 0;

    printf("DC Sensor initialized\r\n");
}

/**
 * @brief Start DC sensor data acquisition
 */
void DC_Sensor_Start(void) {
    /* Start ADC2 in continuous mode */
    HAL_ADC_Start(&hadc2);

    printf("DC Sensor started - Continuous ADC acquisition active\r\n");
}

/**
 * @brief Stop DC sensor data acquisition
 */
void DC_Sensor_Stop(void) {
    /* Stop ADC2 */
    HAL_ADC_Stop(&hadc2);

    printf("DC Sensor stopped\r\n");
}

/**
 * @brief Main update function (call from main loop every 10ms)
 */
void DC_Sensor_Update(void) {
    /* Read raw ADC values */
    DC_Sensor_Read_ADC();

    /* Process data based on current mode */
    switch(dc_sensor.mode) {
        case DC_SENSOR_MODE_NORMAL:
            DC_Sensor_Process_Normal_Mode();
            break;

        case DC_SENSOR_MODE_CALIBRATION:
        	// Comment and uncomment back and forth to callibrate between AC and DC
//            DC_Sensor_Process_Calibration_Mode();
            break;
    }

    /* Check for fault conditions */
    dc_sensor.fault_flags = DC_Sensor_Check_Faults();

    /* Update protection flag */
    dc_sensor.protection_triggered = (dc_sensor.fault_flags != DC_SENSOR_FAULT_NONE) ? 1 : 0;

    /* Update statistics */
    dc_sensor.measurement_count++;
    dc_sensor.last_update_tick = HAL_GetTick();

    /* Debug output */
    if(dc_sensor.debug_flag && dc_sensor.mode == DC_SENSOR_MODE_NORMAL) {
        printf("DC: V=%.1fV, I=%.1fA, Faults=0x%02X\r\n",
               dc_sensor.voltage, dc_sensor.current, dc_sensor.fault_flags);
    }
}

/**
 * @brief Set operation mode
 */
void DC_Sensor_Set_Mode(DC_Sensor_Mode_t mode) {
    if(dc_sensor.mode != mode) {
        dc_sensor.mode = mode;
        dc_sensor.calibration_counter = 0;

        printf("DC Sensor mode changed to: %s\r\n",
               (mode == DC_SENSOR_MODE_NORMAL) ? "NORMAL" : "CALIBRATION");
    }
}

/**
 * @brief Get current operation mode
 */
DC_Sensor_Mode_t DC_Sensor_Get_Mode(void) {
    return dc_sensor.mode;
}

/**
 * @brief Get DC voltage reading
 */
float DC_Sensor_Get_Voltage(void) {
    return dc_sensor.voltage;
}

/**
 * @brief Get DC current reading
 */
float DC_Sensor_Get_Current(void) {
    return dc_sensor.current;
}

/**
 * @brief Get raw voltage ADC reading
 */
uint16_t DC_Sensor_Get_Voltage_Raw(void) {
    return dc_sensor.voltage_adc_raw;
}

/**
 * @brief Get raw current ADC reading
 */
uint16_t DC_Sensor_Get_Current_Raw(void) {
    return dc_sensor.current_adc_raw;
}

/**
 * @brief Set voltage calibration parameters
 */
void DC_Sensor_Set_Voltage_Calibration(float scale_factor, float offset) {
    dc_sensor.voltage_scale_factor = scale_factor;
    dc_sensor.voltage_offset = offset;

    printf("DC Voltage calibration updated: Scale=%.6f, Offset=%.1f\r\n",
           scale_factor, offset);
}

/**
 * @brief Set current calibration parameters
 */
void DC_Sensor_Set_Current_Calibration(float scale_factor, float offset) {
    dc_sensor.current_scale_factor = scale_factor;
    dc_sensor.current_offset = offset;

    printf("DC Current calibration updated: Scale=%.6f, Offset=%.1f\r\n",
           scale_factor, offset);
}

/**
 * @brief Check for fault conditions
 */
DC_Sensor_Fault_t DC_Sensor_Check_Faults(void) {
    DC_Sensor_Fault_t faults = DC_SENSOR_FAULT_NONE;

    /* Check overvoltage */
    if(dc_sensor.voltage > DC_OVERVOLTAGE_THRESHOLD) {
        faults |= DC_SENSOR_FAULT_OVERVOLTAGE;
    }

    /* Check overcurrent */
    if(dc_sensor.current > DC_OVERCURRENT_THRESHOLD) {
        faults |= DC_SENSOR_FAULT_OVERCURRENT;
    }

    /* Check undervoltage */
    if(dc_sensor.voltage < DC_UNDERVOLTAGE_THRESHOLD && dc_sensor.voltage > 5.0f) {
        faults |= DC_SENSOR_FAULT_UNDERVOLTAGE;
    }

    /* Check ADC error (reading out of reasonable range) */
    if(dc_sensor.voltage_adc_raw == 0 || dc_sensor.voltage_adc_raw >= 4090 ||
       dc_sensor.current_adc_raw >= 4090) {
        faults |= DC_SENSOR_FAULT_ADC_ERROR;
    }

    return faults;
}

/**
 * @brief Clear specific fault
 */
void DC_Sensor_Clear_Fault(DC_Sensor_Fault_t fault) {
    dc_sensor.fault_flags &= ~fault;
}

/**
 * @brief Check if protection is triggered (for MLBC integration)
 */
uint8_t DC_Sensor_Is_Protection_Triggered(void) {
    return dc_sensor.protection_triggered;
}

/**
 * @brief Set debug flag
 */
void DC_Sensor_Set_Debug(uint8_t flag) {
    dc_sensor.debug_flag = flag;
    if(flag) {
        printf("DC Sensor debug enabled\r\n");
    } else {
        printf("DC Sensor debug disabled\r\n");
    }
    printf("====================\r\n");
}

/**
 * @brief Read raw ADC values from both channels
 */
void DC_Sensor_Read_ADC(void) {
    /* Start conversion for channel 11 (voltage) */
    HAL_ADC_Start(&hadc2);

    /* Wait for conversion to complete */
    if(HAL_ADC_PollForConversion(&hadc2, 10) == HAL_OK) {
        dc_sensor.voltage_adc_raw = HAL_ADC_GetValue(&hadc2);
    }

    /* The ADC should automatically move to next channel (current) */
    /* Wait for second conversion to complete */
    if(HAL_ADC_PollForConversion(&hadc2, 10) == HAL_OK) {
        dc_sensor.current_adc_raw = HAL_ADC_GetValue(&hadc2);
    }

    HAL_ADC_Stop(&hadc2);
}

/**
 * @brief Apply rolling average filter to ADC readings
 */
void DC_Sensor_Apply_Filter(void) {
    /* Add new readings to circular buffers */
    dc_sensor.voltage_buffer[dc_sensor.buffer_index] = dc_sensor.voltage_adc_raw;
    dc_sensor.current_buffer[dc_sensor.buffer_index] = dc_sensor.current_adc_raw;

    /* Update buffer index */
    dc_sensor.buffer_index = (dc_sensor.buffer_index + 1) % DC_AVERAGE_SAMPLES;

    /* Mark buffer as full after first complete cycle */
    if(dc_sensor.buffer_index == 0 && !dc_sensor.buffer_full) {
        dc_sensor.buffer_full = 1;
    }

    /* Calculate averages */
    uint32_t voltage_sum = 0;
    uint32_t current_sum = 0;
    uint8_t samples_to_use = dc_sensor.buffer_full ? DC_AVERAGE_SAMPLES : (dc_sensor.buffer_index + 1);

    for(uint8_t i = 0; i < samples_to_use; i++) {
        voltage_sum += dc_sensor.voltage_buffer[i];
        current_sum += dc_sensor.current_buffer[i];
    }

    dc_sensor.voltage_adc_filtered = (float)voltage_sum / (float)samples_to_use;
    dc_sensor.current_adc_filtered = (float)current_sum / (float)samples_to_use;
}

/**
 * @brief Apply calibration to convert ADC counts to real units
 */
void DC_Sensor_Apply_Calibration(void) {
    /* Convert filtered ADC values to real units */
    dc_sensor.voltage = DC_Sensor_Apply_Single_Calibration(
        (uint16_t)dc_sensor.voltage_adc_filtered,
        dc_sensor.voltage_scale_factor,
        dc_sensor.voltage_offset);

    dc_sensor.current = DC_Sensor_Apply_Single_Calibration(
        (uint16_t)dc_sensor.current_adc_filtered,
        dc_sensor.current_scale_factor,
        dc_sensor.current_offset);

    /* Ensure values are non-negative */
    if(dc_sensor.voltage < 0.0f) dc_sensor.voltage = 0.0f;
    if(dc_sensor.current < 0.0f) dc_sensor.current = 0.0f;
}

/**
 * @brief Process data in normal mode (filtering and calibration)
 */
void DC_Sensor_Process_Normal_Mode(void) {
    /* Apply rolling average filter */
    DC_Sensor_Apply_Filter();

    /* Apply calibration to get real values */
    DC_Sensor_Apply_Calibration();
}

/**
 * @brief Process data in calibration mode (raw data transmission)
 */
void DC_Sensor_Process_Calibration_Mode(void) {
    /* Transmit raw ADC values for calibration */
    static uint32_t last_transmission = 0;
    uint32_t current_tick = HAL_GetTick();

    /* Transmit every 100ms in calibration mode */
    if((current_tick - last_transmission) >= 100) {
        printf("DC_RAW,%lu,%d,%d\r\n",
               dc_sensor.calibration_counter,
               dc_sensor.voltage_adc_raw,
               dc_sensor.current_adc_raw);

        dc_sensor.calibration_counter++;
        last_transmission = current_tick;
    }
}

/**
 * @brief Apply calibration to raw ADC value
 */
float DC_Sensor_Apply_Single_Calibration(uint16_t raw_value, float scale_factor, float offset) {
    /* Apply offset and scaling */
    return ((float)raw_value - offset) * scale_factor;
}

/**
 * @brief Get sensor statistics string
 */
void DC_Sensor_Get_Statistics(char* buffer, size_t buffer_size) {
    const char* mode_str = (dc_sensor.mode == DC_SENSOR_MODE_NORMAL) ? "NORMAL" : "CALIBRATION";

    snprintf(buffer, buffer_size,
        "DC_SENSOR: %s,V:%.1fV,I:%.1fA,Measurements:%lu,Faults:0x%02X,Protection:%s",
        mode_str,
        dc_sensor.voltage, dc_sensor.current,
        dc_sensor.measurement_count, dc_sensor.fault_flags,
        dc_sensor.protection_triggered ? "ACTIVE" : "OK");
}
