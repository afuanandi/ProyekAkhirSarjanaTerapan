/**
 * @file ac_sensor.h
 * @brief AC Voltage and Current Sensor - 20ms Dual Buffer Implementation
 * @author afuanandi & Claude
 * @date 2025
 *
 * High-performance AC sensor for 7-level PUCI inverter with 20ms control updates.
 * Uses proven restart-based DMA approach with dual buffer sizing.
 *
 * Hardware Configuration:
 * - ADC1 Channel 1 (PA1): AC Voltage sensing via AMC1100
 * - ADC1 Channel 4 (PA4): AC Current sensing via AMC1100
 * - TIM3: 10kHz trigger for synchronized sampling
 * - DMA2 Stream0: Circular buffer with restart-based management
 *
 * Dual Buffer System:
 * - Normal Mode: 400 samples (1 cycle/20ms) for fast control response
 * - Calibration Mode: 2000 samples (5 cycles/100ms) for detailed analysis
 * - DMAContinuousRequests = DISABLE (restart-based approach)
 */

#ifndef AC_SENSOR_H
#define AC_SENSOR_H

#include "main.h"
#include "math.h"
#include <stdio.h>
#include <string.h>

/* AC System Parameters */
#define AC_FUNDAMENTAL_FREQ 50.0f           // 50 Hz AC frequency
#define AC_SAMPLING_FREQ 10000.0f           // 10 kHz sampling rate (TIM3)
#define AC_SAMPLES_PER_CYCLE 200            // 200 samples per 20ms cycle

/* Normal Mode - Fast 20ms Updates */
#define AC_NORMAL_CYCLES 1                  // 1 cycle for fast response
#define AC_NORMAL_TOTAL_SAMPLES 400         // 200V + 200I samples
#define AC_NORMAL_SIGNAL_SAMPLES 200        // 200 samples per signal

/* Calibration Mode - Detailed 100ms Analysis */
#define AC_CALIB_CYCLES 5                   // 5 cycles for high accuracy
#define AC_CALIB_TOTAL_SAMPLES 2000         // 1000V + 1000I samples
#define AC_CALIB_SIGNAL_SAMPLES 1000        // 1000 samples per signal

/* Buffer Management */
#define AC_MAX_TOTAL_SAMPLES AC_CALIB_TOTAL_SAMPLES    // Allocate for largest mode
#define AC_MAX_SIGNAL_SAMPLES AC_CALIB_SIGNAL_SAMPLES  // Max samples per signal

/* ADC Parameters */
#define AC_ADC_RESOLUTION 4096.0f           // 12-bit ADC (0-4095)
#define AC_ADC_VREF 3.3f                    // 3.3V reference voltage

/**
 * @brief AC Sensor operation modes
 */
typedef enum {
    AC_MODE_NORMAL,                         // Fast RMS for control (20ms)
    AC_MODE_CALIBRATION                     // Raw data for analysis (100ms)
} AC_Mode_t;

/**
 * @brief AC Sensor status
 */
typedef enum {
    AC_STATUS_IDLE,                         // Not running
    AC_STATUS_COLLECTING,                   // DMA collecting data
    AC_STATUS_READY,                        // Data ready for processing
    AC_STATUS_ERROR                         // Error condition
} AC_Status_t;

/**
 * @brief Main AC Sensor Structure - 20ms Optimized
 */
typedef struct {
    /* Operation Control */
    AC_Mode_t mode;                         // Current mode
    AC_Status_t status;                     // Current status
    uint8_t initialized;                    // Initialization flag
    uint8_t buffer_ready;                   // Buffer ready flag

    /* Dynamic Buffer Configuration */
    uint16_t active_total_samples;          // Current total samples (400 or 2000)
    uint16_t active_signal_samples;         // Current samples per signal (200 or 1000)
    uint8_t active_cycles;                  // Current cycles (1 or 5)

    /* DMA Buffer - Single allocation for both modes */
    uint16_t dma_buffer[AC_MAX_TOTAL_SAMPLES];  // Raw interleaved ADC data

    /* Extracted Signal Arrays */
    uint16_t voltage_raw[AC_MAX_SIGNAL_SAMPLES];  // Voltage samples
    uint16_t current_raw[AC_MAX_SIGNAL_SAMPLES];  // Current samples

    /* RMS Results (Normal Mode) */
    float voltage_rms;                      // Voltage RMS (V)
    float current_rms;                      // Current RMS (A)

    /* Signal Analysis Data */
    uint16_t v_peak, v_trough;              // Voltage ADC extremes
    uint16_t i_peak, i_trough;              // Current ADC extremes
    float v_midpoint, i_midpoint;           // DC offset points
    float v_rms_raw, i_rms_raw;             // Raw ADC RMS values

    /* Calibration Parameters */
    float v_scale;                          // Voltage scale factor (V/ADC)
    float i_scale;                          // Current scale factor (A/ADC)
    float v_offset;                         // Voltage offset (V)
    float i_offset;                         // Current offset (A)

    /* Statistics and Monitoring */
    uint32_t measurement_count;             // Total measurements
    uint32_t dma_complete_count;            // DMA completion counter
    uint32_t error_count;                   // Error counter

    /* Calibration Mode Control */
    uint8_t calib_data_sent;                // Calibration data sent flag
    uint8_t mode_switch_pending;            // Mode switch in progress

    /* Debug System */
    uint8_t debug_enabled;                  // Debug output flag

} AC_Sensor_t;

/* External Variables */
extern AC_Sensor_t ac_sensor;
extern ADC_HandleTypeDef hadc1;
extern DMA_HandleTypeDef hdma_adc1;
extern TIM_HandleTypeDef htim3;
extern UART_HandleTypeDef huart2;

/* Core Functions */

/**
 * @brief Initialize AC sensor system
 * Sets up ADC, DMA, and prepares for restart-based operation
 */
void AC_Sensor_Init(void);

/**
 * @brief Start AC sensor acquisition
 * Begins DMA collection based on current mode
 */
void AC_Sensor_Start(void);

/**
 * @brief Stop AC sensor acquisition
 * Stops DMA and timer safely
 */
void AC_Sensor_Stop(void);

/**
 * @brief Main update function (call every 20ms from main loop)
 * Processes data when ready and restarts DMA for next cycle
 */
void AC_Sensor_Update(void);

/**
 * @brief Set operation mode with automatic buffer reconfiguration
 * @param mode: AC_MODE_NORMAL (20ms) or AC_MODE_CALIBRATION (100ms)
 */
void AC_Sensor_Set_Mode(AC_Mode_t mode);

/* Data Access Functions */

/**
 * @brief Get voltage RMS (primary output for fuzzy controller)
 * @return Voltage RMS in Volts
 */
float AC_Sensor_Get_Voltage_RMS(void);

/**
 * @brief Get current RMS
 * @return Current RMS in Amperes
 */
float AC_Sensor_Get_Current_RMS(void);

/**
 * @brief Get current operation mode
 * @return Current mode
 */
AC_Mode_t AC_Sensor_Get_Mode(void);

/**
 * @brief Get current status
 * @return Current status
 */
AC_Status_t AC_Sensor_Get_Status(void);

/**
 * @brief Check if data is ready for processing
 * @return 1 if ready, 0 if still collecting
 */
uint8_t AC_Sensor_Is_Ready(void);

/* Configuration Functions */

/**
 * @brief Set voltage calibration parameters
 * @param scale: Scale factor (V/ADC_count)
 * @param offset: Linear offset (V)
 */
void AC_Sensor_Set_Voltage_Calibration(float scale, float offset);

/**
 * @brief Set current calibration parameters
 * @param scale: Scale factor (A/ADC_count)
 * @param offset: Linear offset (A)
 */
void AC_Sensor_Set_Current_Calibration(float scale, float offset);

/**
 * @brief Enable/disable debug output
 * @param enable: 1 to enable, 0 to disable
 */
void AC_Sensor_Set_Debug(uint8_t enable);

/* DMA Callback Functions */

/**
 * @brief DMA transfer complete callback
 * Call this from HAL_ADC_ConvCpltCallback() in main.c
 */
void AC_Sensor_DMA_Complete_Callback(void);

/**
 * @brief Get sensor statistics for debugging
 * @param buffer: Output buffer
 * @param size: Buffer size
 */
void AC_Sensor_Get_Statistics(char* buffer, size_t size);

#endif /* AC_SENSOR_H */
