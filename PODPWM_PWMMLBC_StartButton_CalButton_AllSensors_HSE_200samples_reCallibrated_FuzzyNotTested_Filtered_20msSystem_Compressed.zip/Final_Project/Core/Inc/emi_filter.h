/**
 * @file emi_filter.h
 * @brief Simplified EMI filtering for I2C reliability
 * @author afuanandi
 * @date 2025
 */

#ifndef EMI_FILTER_H
#define EMI_FILTER_H

#include "main.h"
#include <stdint.h>

/* Simplified EMI Filter Configuration */
#define EMI_MAX_RETRY_ATTEMPTS 3
#define EMI_RETRY_DELAY_MS 5

/* EMI Analysis Results */
typedef enum {
    EMI_RESULT_SUCCESS = 0,      // Operation successful
    EMI_RESULT_RETRY_LATER = 1,  // Should retry with delay
    EMI_RESULT_SKIP_CHUNK = 2    // Skip this operation
} EMI_Result_t;

/* Simplified EMI Filter State */
typedef struct {
    /* Retry management */
    uint32_t retry_delay_start;
    uint8_t in_retry_delay;

    /* Simple statistics */
    uint32_t total_operations;
    uint32_t total_failures;
    uint32_t skipped_operations;

    /* Debug */
    uint8_t debug_enabled;
} EMI_Filter_t;

/* Global EMI filter instance */
extern EMI_Filter_t emi_filter;

/* Function Prototypes */

/**
 * @brief Initialize EMI filter system
 */
void EMI_Filter_Init(void);

/**
 * @brief Process I2C operation result through EMI filter
 * @param operation_result: HAL_StatusTypeDef from I2C operation
 * @param retry_count: Current retry attempt (0 = first attempt)
 * @return EMI_Result_t indicating what action to take
 */
EMI_Result_t EMI_Filter_Process_Result(HAL_StatusTypeDef operation_result, uint8_t retry_count);

/**
 * @brief Check if retry delay has completed
 * @return 1 if ready to retry, 0 if still waiting
 */
uint8_t EMI_Filter_Is_Retry_Ready(void);

/**
 * @brief Enable/disable debug output
 * @param enable: 1 to enable, 0 to disable
 */
void EMI_Filter_Set_Debug(uint8_t enable);

/**
 * @brief Get EMI filter statistics
 * @param buffer: Output buffer
 * @param buffer_size: Buffer size
 */
void EMI_Filter_Get_Statistics(char* buffer, size_t buffer_size);

/**
 * @brief Reset EMI filter state
 */
void EMI_Filter_Reset(void);

#endif /* EMI_FILTER_H */
