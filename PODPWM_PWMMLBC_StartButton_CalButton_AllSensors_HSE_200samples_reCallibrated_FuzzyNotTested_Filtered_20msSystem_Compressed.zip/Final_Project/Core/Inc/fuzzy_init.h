/**
 * @file fuzzy_init.h
 * @brief Header file for fuzzy system initialization functions
 * @author afuanandi
 * @date 2025
 */

#ifndef FUZZY_INIT_H
#define FUZZY_INIT_H

#include "fuzzy_structures.h"

/**
 * @brief Initialize the fuzzy system with membership functions and rules
 * @param system Pointer to fuzzy system structure
 * @return 0 if successful, -1 if error
 */
int InitializeFuzzySystem(FuzzySystem* system);

/**
 * @brief Free memory allocated for the fuzzy system
 * @param system Pointer to fuzzy system structure
 */
void DestroyFuzzySystem(FuzzySystem* system);

/**
 * @brief Main fuzzy inference function
 * @param system: Pointer to fuzzy system structure
 * @param input1: First input value (error)
 * @param input2: Second input value (error derivative)
 * @return: Crisp output value (modulation index)
 */
float FuzzyInference(FuzzySystem* system, float input1, float input2);

#endif /* FUZZY_INIT_H */
