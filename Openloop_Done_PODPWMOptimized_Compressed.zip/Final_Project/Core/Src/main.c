/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "adc.h"
#include "dma.h"
#include "i2c.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "stdio.h"
#include "string.h"
#include "math.h"
#include "button_handler.h"
#include "pod_pwm.h"
#include "pwm_mlbc.h"
#include "ac_sensor.h"
#include "dc_sensor.h"
#include "emi_filter.h"
#include "oled_display.h"
#include "fuzzy_controller.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* System Timing */
#define MAIN_LOOP_INTERVAL_MS 20       // Main loop execution interval
#define DEBUG_TRANSMIT_INTERVAL_MS 100   // Debug data transmission interval
#define BUTTON_CHECK_INTERVAL_MS 5      // Button checking interval

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */

/* System State Variables */
SystemMode_t system_mode = SYSTEM_MODE_OPEN_LOOP;      // Default to open loop
SensorMode_t sensor_mode = SENSOR_MODE_NORMAL;         // Default to normal mode
MonitoringMode_t monitoring_mode = MONITORING_MODE_OFF; // Default to off
uint8_t system_initialized = 0;                        // System initialization flag

/* Button State Management */
uint8_t mode_button_prev = 0;                          // Previous mode button state
uint32_t mode_button_debounce_timer = 0;               // Mode button debounce timer
uint8_t system_running = 0;                            // Overall system running state                           // Overall system running state

/* Timing Variables */
static uint32_t main_loop_timer = 0;
static uint32_t debug_transmit_timer = 0;
static uint32_t button_check_timer = 0;
static uint32_t dc_sensor_timer = 0;
static uint32_t oled_nonblocking_timer = 0;
static uint32_t oled_update_timer = 0;

/* Manual Control Variables */
float manual_modulation_index = MANUAL_MODULATION_INDEX_DEFAULT;
float manual_duty_cycle = MANUAL_DUTY_CYCLE_DEFAULT;

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */

/* System Initialization */
void System_Initialize(void);

/* Button and Switch Handling */
void Handle_Button_Inputs(void);
void Handle_Start_Stop_Button_NonBlocking(void);
void Handle_Mode_Button_NonBlocking(void);
void Update_System_Modes(void);

/* Manual Control Functions */
void Update_Manual_Controls(void);
void Apply_System_Settings(void);

/* Debug and Status Functions */
void Realtime_CSV_Log(void);
void print_float_comma_decimal(float value, int precision);
void Transmit_Debug_Data(void);
void Print_System_Status(void);

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
int _write(int file, char *ptr, int len) {
    HAL_UART_Transmit(&huart2, (uint8_t*)ptr, len, HAL_MAX_DELAY);
    return len;
}
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_USART2_UART_Init();
  MX_TIM1_Init();
  MX_TIM3_Init();
  MX_TIM8_Init();
  MX_I2C1_Init();
  MX_TIM2_Init();
  MX_ADC1_Init();
  MX_ADC2_Init();
  MX_TIM4_Init();
  /* USER CODE BEGIN 2 */
  Print_System_Status();
  System_Initialize();
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
	  uint32_t current_tick = HAL_GetTick();

      /* OLED non-blocking update (1ms) */
      if((current_tick - oled_nonblocking_timer) >= 1) {
          OLED_Display_Update_NonBlocking();  // Process chunked I2C transmission
          oled_nonblocking_timer = current_tick;
      }

	  /* Handle button inputs (10ms) */
	  if((current_tick - button_check_timer) >= BUTTON_CHECK_INTERVAL_MS) {
		  Handle_Button_Inputs();
		  button_check_timer = current_tick;
	  }

	  /* DC Sensor updates (10ms) */
	  if((current_tick - dc_sensor_timer) >= 10) {
		  DC_Sensor_Update();
		  dc_sensor_timer = current_tick;
	  }

	  /* Main system update loop (20ms) */
	  if((current_tick - main_loop_timer) >= MAIN_LOOP_INTERVAL_MS) {
		  /* Update system modes based on switches */
		  Update_System_Modes();

		  /* Update manual control parameters */
		  Update_Manual_Controls();

		  /* Apply settings to subsystems */
		  Apply_System_Settings();

		  /* Update MLBC state machine */
		  MLBC_Update();

		  /* AC Sensor */
		  AC_Sensor_Update();

          /* Real-time CSV logging if monitoring enabled - KEEP AT 100ms FOR NOW */
          if(monitoring_mode == MONITORING_MODE_ON && system_running) {
              // Only log every 5th iteration (100ms) to prevent UART overflow
              static uint8_t csv_counter = 0;
              csv_counter++;
              if(csv_counter >= 5) {  // 5 × 20ms = 100ms
                  Realtime_CSV_Log();
                  csv_counter = 0;
              }
          }

		  main_loop_timer = current_tick;
	  }

	  /* OLED update loop (500ms) */
	  if((current_tick - oled_update_timer) >= 500) {
	      OLED_Display_UpdateFromSystem(
	          DC_Sensor_Get_Voltage(),         // Your DC sensor
	          DC_Sensor_Get_Current(),         // Your DC sensor
	          AC_Sensor_Get_Voltage_RMS(),     // Your AC sensor
	          AC_Sensor_Get_Current_RMS(),     // Your AC sensor
	          manual_modulation_index,         // From main.c variable
	          system_running,                  // From main.c variable
	          (system_mode == SYSTEM_MODE_CLOSED_LOOP) ? 1 : 0,
	          sensor_mode                      // From main.c variable
	      );
	      oled_update_timer = current_tick;
	  }

	  /* Transmit debug data (100ms)*/
	  if((current_tick - debug_transmit_timer) >= DEBUG_TRANSMIT_INTERVAL_MS) {
		  Transmit_Debug_Data();
		  debug_transmit_timer = current_tick;
	  }
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 4;
  RCC_OscInitStruct.PLL.PLLN = 180;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 2;
  RCC_OscInitStruct.PLL.PLLR = 2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Activate the Over-Drive mode
  */
  if (HAL_PWREx_EnableOverDrive() != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_5) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */

/**
 * @brief Initialize the complete system
 */
void System_Initialize(void) {
	/* Initialize Button Handler */
	Button_Handler_Init();

	/* Initialize POD PWM system */
    POD_PWM_Init();

    /* Initialize MLBC system */
    MLBC_Init();

    /* Initialize EMI Filter */
    EMI_Filter_Init();

    /* Start TIM3 interrupt for POD PWM reference generation and AC Sensor*/
    HAL_TIM_Base_Start_IT(&htim3);

    /* Configure initial system settings */
    POD_PWM_Set_Mode(POD_PWM_MODE_OPEN_LOOP);
    POD_PWM_Set_Manual_MI(manual_modulation_index);
    if(ENABLE_POD_PWM_DEBUG) {
        POD_PWM_Set_Debug(1);
    } else {
        POD_PWM_Set_Debug(0);
    }

    MLBC_Set_Target_Duty_Cycle(manual_duty_cycle);
    if(ENABLE_MLBC_DEBUG) {
        MLBC_Set_Debug(1);
    } else {
        MLBC_Set_Debug(0);
    }

    /* Initialize DC Sensor */
    DC_Sensor_Init();
    DC_Sensor_Start();

    if(ENABLE_DC_SENSOR_DEBUG){
    	DC_Sensor_Set_Debug(1);
    } else {
    	DC_Sensor_Set_Debug(0);
    }

    /* Initialize AC Sensor */
    AC_Sensor_Init();
    AC_Sensor_Start();

    if(ENABLE_AC_SENSOR_DEBUG){
    	AC_Sensor_Set_Debug(1);
    } else {
    	AC_Sensor_Set_Debug(0);
    }

    /* Initialize Fuzzy Controller */
    Fuzzy_Controller_Init();

    /* Initialize OLED */
    OLED_Display_Init();

    /* Apply debug settings for EMI Filter */
    if(ENABLE_EMI_DEBUG) {
        EMI_Filter_Set_Debug(1);
    } else {
        EMI_Filter_Set_Debug(0);
    }

    /* Initialize timing variables */
    main_loop_timer = HAL_GetTick();
    debug_transmit_timer = HAL_GetTick();
    button_check_timer = HAL_GetTick();
    oled_nonblocking_timer = HAL_GetTick();
    oled_update_timer = HAL_GetTick();

    system_initialized = 1;
    printf("System Initialization Complete\r\n");
}

/**
 * @brief Handle all button inputs using non-blocking method
 */
void Handle_Button_Inputs(void) {
    /* Update button states (this is fast and non-blocking) */
    Button_Handler_Update();

    /* Handle start/stop button events */
    Handle_Start_Stop_Button_NonBlocking();

    /* Handle mode button events */
    Handle_Mode_Button_NonBlocking();
}

/**
 * @brief Handle start/stop button using non-blocking method
 */
void Handle_Start_Stop_Button_NonBlocking(void) {
    ButtonEvent_t event = Button_Handler_Get_Event(BUTTON_START_STOP);

    if(event == BUTTON_EVENT_PRESS) {
        /* Clear the event first */
        Button_Handler_Clear_Event(BUTTON_START_STOP);

        /* Toggle system state */
        uint8_t new_state = !system_running;

        printf("Start/Stop button pressed! Switching to: %s\r\n",
               new_state ? "RUNNING" : "STOPPED");

        if(new_state) {
            /* Start the entire system */
            printf("Starting entire system...\r\n");

            POD_PWM_Reset_Debug_Counter();

            /* Start MLBC first */
            MLBC_Start();

            /* Mark system as running */
            system_running = 1;

            printf("System started successfully\r\n");
        } else {
            /* Stop the entire system */
            printf("Stopping entire system...\r\n");

            /* Stop MLBC (this also stops inverter) */
            MLBC_Stop();

            /* Disable inverter explicitly */
            POD_PWM_Enable(0);

            /* Mark system as stopped */
            system_running = 0;

            printf("System stopped successfully\r\n");
        }
    }
}

/**
 * @brief Handle mode button using non-blocking method
 */
void Handle_Mode_Button_NonBlocking(void) {
    ButtonEvent_t event = Button_Handler_Get_Event(BUTTON_MODE);

    if(event == BUTTON_EVENT_PRESS) {
        /* Clear the event first */
        Button_Handler_Clear_Event(BUTTON_MODE);

        printf("Mode button pressed! Current mode: %s\r\n",
               (system_mode == SYSTEM_MODE_OPEN_LOOP) ? "OPEN_LOOP" : "CLOSED_LOOP");

        if(system_mode == SYSTEM_MODE_OPEN_LOOP) {
            system_mode = SYSTEM_MODE_CLOSED_LOOP;
            printf("Switched to CLOSED LOOP mode\r\n");

            /* Only enable fuzzy debug if monitoring is OFF */
            if(monitoring_mode == MONITORING_MODE_OFF) {
                Fuzzy_Controller_Set_Debug(1);  // Enable fuzzy debug
            } else {
                printf("Fuzzy debug disabled (monitoring mode active)\r\n");
            }
        } else {
            system_mode = SYSTEM_MODE_OPEN_LOOP;
            printf("Switched to OPEN LOOP mode\r\n");
            Fuzzy_Controller_Set_Debug(0); // Always disable in open loop
        }
    }
}

/**
 * @brief Update system modes based on DIP switches
 */
void Update_System_Modes(void) {
    /* Read sensor mode DIP switch (PB5) */
    uint8_t calibration_switch = !HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_5);  // Active low

    if(calibration_switch) {
        sensor_mode = SENSOR_MODE_CALIBRATION;
    } else {
        sensor_mode = SENSOR_MODE_NORMAL;
    }

    /* Read monitoring mode DIP switch (PB4) */
    uint8_t monitoring_switch = !HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_4);  // Active low

    if(monitoring_switch) {
        if(monitoring_mode == MONITORING_MODE_OFF) {
            /* Just switched TO monitoring mode */
            monitoring_mode = MONITORING_MODE_ON;
            Fuzzy_Controller_Set_Debug(0);  // Disable fuzzy debug
            printf("Monitoring mode ON - Fuzzy debug disabled\r\n");
        }
    } else {
        if(monitoring_mode == MONITORING_MODE_ON) {
            /* Just switched FROM monitoring mode */
            monitoring_mode = MONITORING_MODE_OFF;
            /* Restore fuzzy debug based on system mode */
            if(system_mode == SYSTEM_MODE_CLOSED_LOOP) {
                Fuzzy_Controller_Set_Debug(1);  // Re-enable if in closed loop
                printf("Monitoring mode OFF - Fuzzy debug restored\r\n");
            }
        }
    }
}

/**
 * @brief Update manual control parameters (adjustable in code)
 */
void Update_Manual_Controls(void) {
    /* TODO: These values can be modified during debugging */
}

/**
 * @brief Apply system settings to subsystems
 */
void Apply_System_Settings(void) {
    /* Apply POD PWM settings based on system mode */
    if(system_mode == SYSTEM_MODE_OPEN_LOOP) {
        POD_PWM_Set_Mode(POD_PWM_MODE_OPEN_LOOP);

        /* Reset to default manual MI when switching to open loop */
        manual_modulation_index = MANUAL_MODULATION_INDEX_DEFAULT;
        POD_PWM_Set_Manual_MI(manual_modulation_index);

    } else {
        POD_PWM_Set_Mode(POD_PWM_MODE_CLOSED_LOOP);
        float fuzzy_mi = Fuzzy_Controller_Update();
        POD_PWM_Set_Fuzzy_MI(fuzzy_mi);
        manual_modulation_index = fuzzy_mi;
    }

    /* Apply MLBC settings */
    MLBC_Set_Target_Duty_Cycle(manual_duty_cycle);

    /* Apply sensor mode settings */
    if(sensor_mode == SENSOR_MODE_CALIBRATION) {
        AC_Sensor_Set_Mode(AC_MODE_CALIBRATION);
    } else {
        AC_Sensor_Set_Mode(AC_MODE_NORMAL);
    }

    if(sensor_mode == SENSOR_MODE_CALIBRATION) {
        DC_Sensor_Set_Mode(DC_SENSOR_MODE_CALIBRATION);
    } else {
        DC_Sensor_Set_Mode(DC_SENSOR_MODE_NORMAL);
    }
}

/**
 * @brief ADC conversion complete callback
 */
void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef* hadc) {
    if(hadc->Instance == ADC1) {
        AC_Sensor_DMA_Complete_Callback();  // This should be called
    }
}

/**
 * @brief Real-time CSV data logging
 */
void Realtime_CSV_Log(void) {
    static uint8_t header_sent = 0;
    static uint32_t sample_counter = 0;

    /* Send CSV header once when monitoring starts */
    if(!header_sent) {
        printf("Time_ms;System_Mode;AC_Voltage;Modulation_Index;Fuzzy_Error;Fuzzy_dError\r\n");
        header_sent = 1;
        sample_counter = 0;
    }

    /* Get current data */
    float ac_voltage = AC_Sensor_Get_Voltage_RMS();
    float current_mi = (system_mode == SYSTEM_MODE_OPEN_LOOP) ?
                       manual_modulation_index :
                       fuzzy_controller.fuzzy_output_final;

    /* Log data in simple CSV format */
    if(system_mode == SYSTEM_MODE_OPEN_LOOP) {
        // Use custom print function for float with comma decimal separator
        printf("%lu;OPEN;", sample_counter * 100);  // Time in ms, System Mode
        print_float_comma_decimal(ac_voltage, 2);   // AC voltage RMS
        printf(";");
        print_float_comma_decimal(current_mi, 3);   // Current modulation index
        printf(";0,000;0,000\r\n");                 // Fuzzy error, Fuzzy dError (fixed to 0)
    } else {
        // Use custom print function for float with comma decimal separator
        printf("%lu;CLOSED;", sample_counter * 100);                    // Time in ms, System Mode
        print_float_comma_decimal(ac_voltage, 2);                       // AC voltage RMS
        printf(";");
        print_float_comma_decimal(current_mi, 3);                       // Current modulation index
        printf(";");
        print_float_comma_decimal(fuzzy_controller.error, 3);           // Voltage error
        printf(";");
        print_float_comma_decimal(fuzzy_controller.filtered_derivative, 3); // Filtered derivative
        printf("\r\n");
    }

    sample_counter++;

    /* Reset when monitoring mode is turned off */
    if(monitoring_mode == MONITORING_MODE_OFF) {
        header_sent = 0;
        sample_counter = 0;
    }
}

/**
 * @brief Helper function to print float with comma as decimal separator
 * @param value The float value to print
 * @param precision The number of decimal places
 */
void print_float_comma_decimal(float value, int precision) {
    // Handle negative numbers
    if (value < 0) {
        printf("-");
        value = -value;
    }

    // Extract integer part
    int integer_part = (int)value;
    printf("%d", integer_part);

    // Extract fractional part
    printf(",");
    float fractional_part = value - integer_part;
    for (int i = 0; i < precision; i++) {
        fractional_part *= 10;
        int digit = (int)fractional_part;
        printf("%d", digit);
        fractional_part -= digit;
    }
}

/**
 * @brief Transmit debug data from all subsystems
 */
void Transmit_Debug_Data(void) {
    /* Only transmit debug data if system is running */
    if(system_running) {
        /* Transmit POD PWM debug data */
        if(ENABLE_POD_PWM_DEBUG) {
            POD_PWM_Debug_Transmit();
        }

        /* Transmit MLBC debug data */
        if(ENABLE_MLBC_DEBUG) {
            MLBC_Debug_Transmit();
        }

        if(system_mode == SYSTEM_MODE_CLOSED_LOOP) {
            Fuzzy_Controller_Debug_Transmit();
        }

        /* Add OLED and EMI statistics based on debug flags */
        static uint32_t oled_stats_timer = 0;
        if((HAL_GetTick() - oled_stats_timer) >= 5000) {

            if(ENABLE_I2C_DEBUG) {
                char oled_stats[100];
                SH1106_Get_Statistics(oled_stats, sizeof(oled_stats));
                printf("OLED_STATS: %s\r\n", oled_stats);
            }

            if(ENABLE_EMI_DEBUG) {
            	EMI_Filter_Set_Debug(1);
                char emi_stats[150];
                EMI_Filter_Get_Statistics(emi_stats, sizeof(emi_stats));
                printf("EMI_STATS: %s\r\n", emi_stats);
            }

            oled_stats_timer = HAL_GetTick();
        }
    }
}

/**
 * @brief Print current system status
 */
void Print_System_Status(void) {
    printf("=== SYSTEM STATUS ===\r\n");
    printf("System Mode: %s\r\n", (system_mode == SYSTEM_MODE_OPEN_LOOP) ? "OPEN LOOP" : "CLOSED LOOP");
    printf("Sensor Mode: %s\r\n", (sensor_mode == SENSOR_MODE_NORMAL) ? "NORMAL" : "CALIBRATION");
    printf("Monitoring Mode: %s\r\n", (monitoring_mode == MONITORING_MODE_OFF) ? "OFF" : "ON");
    printf("Manual MI: %.3f\r\n", manual_modulation_index);
    printf("Manual Duty Cycle: %.3f\r\n", manual_duty_cycle);
    printf("POD PWM Debug: %s\r\n", ENABLE_POD_PWM_DEBUG ? "ENABLED" : "DISABLED");
    printf("MLBC Debug: %s\r\n", ENABLE_MLBC_DEBUG ? "ENABLED" : "DISABLED");

    if(system_mode == SYSTEM_MODE_CLOSED_LOOP) {
        char fuzzy_status[200];
        Fuzzy_Controller_Get_Statistics(fuzzy_status, sizeof(fuzzy_status));
        printf("%s\r\n", fuzzy_status);
        printf("Fuzzy Target: %.1fV\r\n", Fuzzy_Controller_Get_Target_Voltage());
    }

    printf("====================\r\n");
}
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
