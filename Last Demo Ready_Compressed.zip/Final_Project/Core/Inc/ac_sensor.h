/**
 * @file ac_sensor.h
 * @brief AC Voltage & Current Sensor Driver - Continuous Circular DMA
 * @author afuanandi & Claude
 * @version 2.1 (2026 - Optimized)

 * This module uses STM32 DMA in Circular Mode to create a "Ping-Pong" buffer.
 * It ensures continuous sampling without stopping the ADC, guaranteeing that
 * every single microsecond of the inverter AC output waveform is captured and processed.
 *
 * TIMING & DATA FLOW:
 * 1. TRIGGER:   TIM3 fires at 10 kHz (Every 100us).
 * 2. ACQUIRE:   ADC1 samples Voltage (PA1) & Current (PA4).
 * 3. TRANSFER:  DMA writes 2x uint16_t to the buffer (Interleaved [V, I]).
 * 4. INTERRUPT (Ping-Pong):
 * - @ 20ms:  Half-Transfer (HT) fires. Buffer[0..399] is ready (Cycle A).
 * Hardware immediately starts filling Buffer[400..799].
 * - @ 40ms:  Transfer-Complete (TC) fires. Buffer[400..799] is ready (Cycle B).
 * Hardware immediately wraps back to Buffer[0..399].
 *
 * PROCESSING LOOP (AC_Sensor_Update):
 * - Runs in main while(1).
 * - Polls HT/TC flags set by ISRs.
 * - Calculates RMS over exactly one full grid cycle (20ms).
 * - Triggers the registered control callback (Fuzzy Logic) at 50Hz.
 */

#ifndef AC_SENSOR_H
#define AC_SENSOR_H

#include "main.h"
#include <math.h>

/* System Parameters */
#define AC_FUNDAMENTAL_FREQ     50.0f           // Target Grid Frequency
#define AC_SAMPLING_FREQ        10000.0f        // Sampling Rate (TIM3)
#define AC_SAMPLES_PER_CYCLE    200             // 10kHz / 50Hz = 200 samples
#define AC_CHANNELS             2               // Voltage (ADC1_IN1) + Current (ADC1_IN4)

/* Buffer Sizing (Double Buffer / Ping-Pong) */
#define AC_NORMAL_SAMPLES_PER_HALF  (AC_SAMPLES_PER_CYCLE * AC_CHANNELS) // 400 uint16_t
#define AC_NORMAL_BUFFER_SIZE       (AC_NORMAL_SAMPLES_PER_HALF * 2)      // 800 uint16_t total

/* Calibration Mode (Linear Snapshot) */
#define AC_CALIB_CYCLES			5
#define AC_CALIB_BUFFER_SIZE	(AC_SAMPLES_PER_CYCLE * AC_CHANNELS * AC_CALIB_CYCLES)

/* Signal Processing */
#define AC_IIR_FILTER_ALPHA     0.25f           // Smoothing factor (0.0=Static, 1.0=Raw)
#define AC_ADC_RESOLUTION       4096.0f         // 12-bit ADC
#define AC_ADC_VREF             3.3f

/* ==========================================================================
 * DATA STRUCTURES
 * ========================================================================== */

typedef enum {
    AC_MODE_NORMAL,         // Continuous Circular Control (Default)
    AC_MODE_CALIBRATION     // One-shot snapshot for analysis
} AC_Mode_t;

typedef enum {
    AC_STATUS_IDLE,
    AC_STATUS_RUNNING,      // DMA active
    AC_STATUS_ERROR
} AC_Status_t;

/**
 * @brief Main AC Sensor Control Structure
 */
typedef struct {
    /* State Machine */
    AC_Mode_t mode;
    volatile AC_Status_t status;
    uint8_t initialized;

    /* DMA Flags (Set by ISR, Cleared by Update) */
    volatile uint8_t half_transfer_ready;   // First half (0-399) ready
    volatile uint8_t full_transfer_ready;   // Second half (400-799) ready

    /* Data Buffers */
    uint16_t dma_buffer[AC_CALIB_BUFFER_SIZE];  // Raw interleaved data
    uint16_t voltage_raw[AC_SAMPLES_PER_CYCLE]; // De-interleaved Voltage (1 cycle)
    uint16_t current_raw[AC_SAMPLES_PER_CYCLE]; // De-interleaved Current (1 cycle)

    /* Results (RMS) */
    float voltage_rms;      // Filtered RMS Voltage
    float current_rms;      // Filtered RMS Current

    /* Internal Analysis */
    float v_midpoint;       // Calculated DC offset
    float i_midpoint;
    float v_rms_raw;        // Instantaneous RMS (pre-filter)
    float i_rms_raw;

    /* Calibration Constants */
    float v_scale;          // Slope (Units/Count)
    float i_scale;
    float v_offset;         // Intercept
    float i_offset;

    /* Diagnostics */
    uint32_t process_count; // Total cycles processed
    uint8_t debug_enabled;
    uint8_t debug_data_ready;

} AC_Sensor_t;

/* External Handles */
extern AC_Sensor_t ac_sensor;
extern ADC_HandleTypeDef hadc1;
extern DMA_HandleTypeDef hdma_adc1;
extern TIM_HandleTypeDef htim3;

/* ==========================================================================
 * PUBLIC FUNCTIONS
 * ========================================================================== */

/* Lifecycle */
void AC_Sensor_Init(void);
void AC_Sensor_Start(void); // Starts DMA & Timer
void AC_Sensor_Stop(void);  // Stops DMA & Timer

/* Control & Config */
void AC_Sensor_Set_Debug(uint8_t flag);
void AC_Sensor_Register_Callback(void (*callback)(float, float));

/**
 * @brief Set operation mode
 * @param mode: AC_MODE_NORMAL or AC_MODE_CALIBRATION
 */
void AC_Sensor_Set_Mode(AC_Mode_t mode);


/**
 * @brief Main Processing Loop
 * Checks DMA flags -> Processes Data -> Calls Registered Callback.
 * Called inside main while(1).
 */
void AC_Sensor_Update(void);

/* Data Access */
float AC_Sensor_Get_Voltage_RMS(void);
float AC_Sensor_Get_Current_RMS(void);

/* Interrupt Callbacks */
void AC_Sensor_HalfTransfer_Callback(void);
void AC_Sensor_FullTransfer_Callback(void);

/* Calibration Utilities */
void AC_Transmit_Calibration_Data(void);
void AC_Sensor_Debug_Transmit(void);

#endif /* AC_SENSOR_H */
