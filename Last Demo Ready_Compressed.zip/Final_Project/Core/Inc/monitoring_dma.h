/**
 * @file monitoring_dma.h
 * @brief DMA-based non-blocking CSV monitoring for UART2 (ST-LINK VCP)
 * @author afuanandi & Claude
 * @date 2026
 * @version 4.0 - Double-buffer with Native UART Interrupt Synchronization
 *
 * This module provides zero-blocking telemetry output using DMA with
 * double-buffering to eliminate sample loss, achieving a perfect 50Hz logging rate.
 *
 * KEY HARDWARE CONCEPT:
 * DMA completion is NOT UART completion. The DMA finishes moving bytes to the
 * UART Data Register (DR) quickly, but the UART shift register still needs time
 * to clock the final bits out. By enabling the USART2 global interrupt in the NVIC,
 * the HAL natively catches the UART Transmission Complete (TC) flag, instantly
 * clearing the HAL_UART_STATE_BUSY_TX state and triggering our callback
 * without relying on software timeouts.
 *
 * UART Configuration:
 * - USART2: ST-LINK Virtual COM Port (PA2/PA3)
 * - Interrupts: DMA1_Stream6 (TX), USART2_IRQn (Global)
 */

#ifndef MONITORING_DMA_H
#define MONITORING_DMA_H

#include "main.h"
#include <stdint.h>
#include <stddef.h>

/* Configuration */
#define CSV_BUFFER_SIZE 256              // Maximum CSV line length
#define MONITORING_TIMEOUT_MS 50         // DMA timeout detection (reduced from 100ms)

/* Monitoring state structure */
typedef struct {
    /* Double buffers */
    char csv_buffer_a[CSV_BUFFER_SIZE];     // Buffer A
    char csv_buffer_b[CSV_BUFFER_SIZE];     // Buffer B
    char *active_buffer;                     // Currently being transmitted by DMA
    char *idle_buffer;                       // Currently being written to by CPU

    /* Idle buffer state */
    uint16_t idle_len;                       // Length of data in idle buffer (0 = empty)
    uint8_t idle_has_data;                   // 1 = idle buffer has formatted data waiting

    /* DMA state */
    volatile uint8_t dma_busy;               // DMA busy flag (set by start, cleared by ISR)
    uint8_t header_sent;                     // Header transmission flag

    /* Statistics */
    uint32_t sample_counter;                 // Samples successfully sent
    uint32_t samples_skipped;                // Samples lost due to DMA busy at swap time
    uint32_t dma_errors;                     // DMA/UART error count
    uint32_t last_dma_start_time;            // Timestamp for timeout detection
} Monitoring_t;

/* Global instance */
extern Monitoring_t monitoring;

/* Function Prototypes */

/**
 * @brief Initialize monitoring system
 * Call this once during system initialization
 */
void Monitoring_Init(void);

/**
 * @brief Non-blocking CSV logging with DMA double-buffer
 * Call this every 20ms in main loop when monitoring is enabled
 *
 * This function:
 * 1. Formats CSV data into the idle buffer (always succeeds)
 * 2. If DMA is idle, swaps buffers and starts transmission
 * 3. If DMA is busy, data waits in idle buffer for next call
 *
 * @return 1 if DMA transfer started, 0 if data buffered (waiting for DMA)
 */
uint8_t Monitoring_CSV_Log_DMA(void);

/**
 * @brief DMA transmit complete callback
 * Call this from HAL_UART_TxCpltCallback() in main.c
 * Clears the busy flag directly from ISR context.
 */
void Monitoring_DMA_TxComplete_Callback(void);

/**
 * @brief Check if DMA transmission is in progress
 * Includes timeout detection to recover from stuck DMA
 * @return 1 if busy, 0 if idle
 */
uint8_t Monitoring_Is_DMA_Busy(void);

/**
 * @brief Reset monitoring state (when switching modes)
 * Aborts any ongoing DMA transfer and resets counters
 */
void Monitoring_Reset(void);

/**
 * @brief Get skip statistics
 * @return Number of samples skipped due to DMA busy
 */
uint32_t Monitoring_Get_Skipped_Count(void);

/**
 * @brief Get DMA error count
 * @return Number of DMA errors encountered
 */
uint32_t Monitoring_Get_Error_Count(void);

/**
 * @brief Get monitoring statistics string
 * @param buffer Output buffer for statistics
 * @param buffer_size Size of output buffer
 */
void Monitoring_Get_Statistics(char* buffer, size_t buffer_size);

#endif /* MONITORING_DMA_H */
