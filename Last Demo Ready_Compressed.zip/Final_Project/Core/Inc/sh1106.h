/**
 * @file sh1106.h
 * @brief Non-blocking SH1106 OLED driver using blocking I2C (no DMA)
 * @author afuanandi & Claude
 * @date 2025
 *
 * Features:
 * - Non-blocking state machine for display updates
 * - Blocking I2C with short timeout (fail-fast, system continues)
 * - Chunked transmission (32 bytes per call)
 * - Simple retry and recovery logic
 * - No DMA, no interrupt dependencies
 */

#ifndef SH1106_H
#define SH1106_H

#include "main.h"
#include <stdbool.h>
#include <stddef.h>

/* ==================== CONFIGURATION ==================== */

/* SH1106 I2C address (7-bit) */
#define SH1106_I2C_ADDR         0x3C

/* Display dimensions */
#define SH1106_WIDTH            128
#define SH1106_HEIGHT           64
#define SH1106_PAGES            8

/* I2C timing */
#define SH1106_I2C_TIMEOUT_MS   10      /* Timeout per I2C operation */

/* Chunked transmission */
#define SH1106_CHUNK_SIZE       32      /* Bytes per update cycle */

/* Retry configuration */
#define SH1106_MAX_RETRIES      3       /* Retries per chunk before skip */
#define SH1106_MAX_CONSECUTIVE_FAILURES 10  /* Failures before recovery attempt */

/* Recovery cooldown */
#define SH1106_RECOVERY_COOLDOWN_MS 2000    /* Wait before retry after recovery */

/* ==================== SH1106 COMMANDS ==================== */

#define SH1106_DISPLAYOFF           0xAE
#define SH1106_DISPLAYON            0xAF
#define SH1106_SETDISPLAYCLOCKDIV   0xD5
#define SH1106_SETMULTIPLEX         0xA8
#define SH1106_SETDISPLAYOFFSET     0xD3
#define SH1106_SETSTARTLINE         0x40
#define SH1106_CHARGEPUMP           0x8D
#define SH1106_MEMORYMODE           0x20
#define SH1106_SEGREMAP             0xA0
#define SH1106_COMSCANDEC           0xC8
#define SH1106_SETCOMPINS           0xDA
#define SH1106_SETCONTRAST          0x81
#define SH1106_SETPRECHARGE         0xD9
#define SH1106_SETVCOMDETECT        0xDB
#define SH1106_DISPLAYALLON_RESUME  0xA4
#define SH1106_NORMALDISPLAY        0xA6
#define SH1106_SETPAGEADDR          0xB0
#define SH1106_SETLOWCOLUMN         0x00
#define SH1106_SETHIGHCOLUMN        0x10

/* ==================== TYPE DEFINITIONS ==================== */

/**
 * @brief Display update state machine states
 */
typedef enum {
    DISPLAY_STATE_IDLE = 0,         /* No update in progress */
    DISPLAY_STATE_PAGE_SETUP,       /* Setting up page address */
    DISPLAY_STATE_PAGE_DATA,        /* Transmitting page data */
    DISPLAY_STATE_NEXT_PAGE,        /* Moving to next page */
    DISPLAY_STATE_COMPLETE,         /* Update complete */
    DISPLAY_STATE_RECOVERY,         /* Recovery in progress */
    DISPLAY_STATE_RECOVERY_COOLDOWN /* Waiting after failed recovery */
} SH1106_State_t;

/**
 * @brief Display controller structure
 */
typedef struct {
    /* Display buffer */
    uint8_t buffer[SH1106_PAGES][SH1106_WIDTH];

    /* State machine */
    SH1106_State_t state;
    uint8_t current_page;
    uint8_t current_column;
    uint8_t update_pending;

    /* Retry tracking */
    uint8_t retry_count;
    uint8_t consecutive_failures;

    /* Recovery */
    uint32_t recovery_start_time;

    /* Transmission buffer (+1 for control byte) */
    uint8_t tx_buffer[SH1106_CHUNK_SIZE + 1];

    /* Statistics */
    uint32_t successful_updates;
    uint32_t failed_updates;
    uint32_t i2c_errors;
    uint32_t recoveries_attempted;
    uint32_t recoveries_successful;

    /* Status flags */
    uint8_t initialized;
    uint8_t debug_enabled;

} SH1106_Controller_t;

/* Global controller instance */
extern SH1106_Controller_t sh1106;

/* ==================== PUBLIC FUNCTIONS ==================== */

/**
 * @brief Initialize SH1106 display (blocking, call once at startup)
 */
void SH1106_Init(void);

/**
 * @brief Process display update state machine (non-blocking)
 *        Call this from main loop every 5-20ms
 */
void SH1106_Update(void);

/**
 * @brief Request a display refresh
 *        Call after modifying the buffer
 */
void SH1106_RequestUpdate(void);

/**
 * @brief Check if update is in progress
 * @return 1 if updating, 0 if idle
 */
uint8_t SH1106_IsUpdating(void);

/**
 * @brief Clear display buffer (does not update display)
 */
void SH1106_Clear(void);

/**
 * @brief Draw a single pixel
 * @param x X coordinate (0-127)
 * @param y Y coordinate (0-63)
 * @param color true=white, false=black
 */
void SH1106_DrawPixel(uint8_t x, uint8_t y, bool color);

/**
 * @brief Draw a character at position
 * @param x X coordinate
 * @param y Y coordinate
 * @param c ASCII character (32-127)
 */
void SH1106_DrawChar(uint8_t x, uint8_t y, char c);

/**
 * @brief Draw a string at position
 * @param x X coordinate
 * @param y Y coordinate
 * @param str Null-terminated string
 */
void SH1106_DrawString(uint8_t x, uint8_t y, const char* str);

/**
 * @brief Draw a line between two points
 */
void SH1106_DrawLine(uint8_t x0, uint8_t y0, uint8_t x1, uint8_t y1);

/**
 * @brief Draw rectangle outline
 */
void SH1106_DrawRect(uint8_t x, uint8_t y, uint8_t width, uint8_t height);

/**
 * @brief Fill rectangle with white pixels
 */
void SH1106_FillRect(uint8_t x, uint8_t y, uint8_t width, uint8_t height);

/**
 * @brief Clear rectangle (fill with black)
 */
void SH1106_ClearRect(uint8_t x, uint8_t y, uint8_t width, uint8_t height);

/**
 * @brief Set display contrast
 * @param contrast 0-255
 */
void SH1106_SetContrast(uint8_t contrast);

/**
 * @brief Turn display on
 */
void SH1106_DisplayOn(void);

/**
 * @brief Turn display off
 */
void SH1106_DisplayOff(void);

/**
 * @brief Enable/disable debug output
 * @param enable 1=enable, 0=disable
 */
void SH1106_Set_Debug(uint8_t enable);

/**
 * @brief Get statistics string for debugging
 * @param buffer Output buffer
 * @param size Buffer size
 */
void SH1106_GetStats(char* buffer, size_t size);

/**
 * @brief Test pattern display
 */
void SH1106_Test(void);

/**
 * @brief Print I2C and OLED debug info (call periodically when debugging)
 *        Only prints if debug is enabled
 */
void SH1106_I2C_Debug_Transmit(void);

#endif /* SH1106_H */
