/**
 * @file fuzzy_controller.h
 * @brief Interval Type-2 Fuzzy Logic Controller with Nie-Tan Type-Reduction
 * @author afuanandi & Claude
 * @date 2025
 *
 * DESIGN:
 * - Interval Type-2 (IT2) fuzzy system
 * - Footprint of Uncertainty (FOU) with upper and lower MFs
 * - Nie-Tan type-reduction method (closed-form, non-iterative)
 * - 7x7 rule base (49 rules)
 * - Input range: +/-60V, Output range: [0, 2]
 * - Parallel integral term for zero steady-state error
 *
 * CONTROL LAW:
 *   MI_final = MI_fuzzy(e, de) + Ki * integral(e * dt)
 *
 * DECOUPLED DESIGN:
 * - Controller receives measured voltage as parameter (no sensor dependency)
 * - Caller (main.c) decides when to call based on system state
 * - Inference engine lives in fuzzy_init module
 */

#ifndef FUZZY_CONTROLLER_H
#define FUZZY_CONTROLLER_H

#include "main.h"
#include "fuzzy_structures.h"
#include <stdint.h>

/* Configuration Parameters */
#define FUZZY_INPUT_RANGE_MAX       60.0f       // Maximum error magnitude (V)
#define FUZZY_MAX_ERROR             60.0f       // Error limit for safety
#define FUZZY_DERIV_FILTER_ALPHA    0.25f       // Derivative filter coefficient
#define FUZZY_ERROR_GAIN            1.0f        // Error scaling factor
#define FUZZY_DERROR_GAIN           1.0f        // dError scaling factor

/* Integral Parameters */
#define FUZZY_KI_GAIN               0.01f     // Integral gain
#define FUZZY_INTEGRAL_MAX          0.1f      // Max integral contribution to MI
#define FUZZY_INTEGRAL_MIN         -0.1f      // Min integral contribution to MI
#define FUZZY_DT                    0.020f    // Control loop period (20ms)

/**
 * @brief Fuzzy Controller State Machine
 */
typedef enum {
    FUZZY_STATE_DISABLED    = 0,
    FUZZY_STATE_NORMAL      = 1,
    FUZZY_STATE_FAULT       = 2
} FuzzyState_t;

/**
 * @brief Fuzzy Controller Structure
 */
typedef struct {
    /* State */
    FuzzyState_t state;
    uint8_t initialized;
    uint8_t new_data_available;

    /* Timing */
    uint32_t last_update_time;

    /* Input signals */
    float voltage_measured;
    float error;
    float error_previous;
    float error_derivative;
    float error_derivative_filtered;

    /* Fuzzy processing */
    float fuzzy_error;
    float fuzzy_derror;
    float fuzzy_output_raw;
    float fuzzy_output_final;

    /* IT2 Type-Reduction Results */
    float y_upper;                      // Upper centroid
    float y_lower;                      // Lower centroid

    /* Parallel integral term */
    float error_integral;               // Accumulated integral of error
    float integral_contribution;        // Ki * error_integral (for debug)
    float ki_gain;                      // Runtime-adjustable integral gain

    /* Statistics */
    uint32_t update_count;

    /* Debug */
    uint8_t debug_enabled;

} FuzzyController_t;

/* ============================================================================
 * FUNCTION PROTOTYPES
 * ============================================================================ */

extern FuzzySystem fuzzy_system;
extern FuzzyController_t fuzzy_controller;

/* Initialization */
void Fuzzy_Controller_Init(void);

/**
 * @brief Enable fuzzy controller
 * @param initial_voltage: Current AC voltage RMS for derivative initialization
 */
void Fuzzy_Controller_Enable(float initial_voltage);

/**
 * @brief Disable fuzzy controller
 */
void Fuzzy_Controller_Disable(void);

/**
 * @brief Main controller update - call every 20ms when system is running
 * @param measured_voltage: Current AC voltage RMS from sensor
 * @return Modulation index [0, 2]
 */
float Fuzzy_Controller_Update(float measured_voltage);

/* State management */
FuzzyState_t Fuzzy_Controller_Get_State(void);

/* Helper functions */
uint8_t Fuzzy_Controller_Is_Active(void);
float Fuzzy_Controller_Get_Output(void);
float Fuzzy_Controller_Get_Error(void);
float Fuzzy_Controller_Get_Error_Derivative(void);
void Fuzzy_Controller_Get_Statistics(char* buffer, size_t buffer_size);
float Fuzzy_Controller_Get_Target_Voltage(void);
void Fuzzy_Controller_Set_Debug(uint8_t enable);
void Fuzzy_Controller_Set_Ki(float ki);

/* Debug */
void Fuzzy_Controller_Debug_Transmit(void);

#endif /* FUZZY_CONTROLLER_H */
