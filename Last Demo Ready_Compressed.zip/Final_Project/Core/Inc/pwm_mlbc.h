/**
 * @file pwm_mlbc.h
 * @brief Multi-Level Boost Converter (MLBC) PWM Control with Soft-Start
 * @author afuanandi
 * @date 2025
 *
 * This module handles pure PWM control for the Multi-Level Boost Converter.
 * It is decoupled from sensor modules — fault detection is handled by main.c.
 *
 * Features:
 * - Software soft-start with configurable duration
 * - Linear duty cycle ramp from 0% to target
 * - Non-blocking operation concurrent with POD PWM
 * - Duty cycle control and monitoring
 *
 * Dependencies:
 * - pod_pwm.h: For POD_PWM_Enable() integration during start/stop
 *
 * Architecture:
 * - main.c feeds measurements and triggers fault shutdowns
 * - This module only manages PWM state machine and hardware output
 */

#ifndef PWM_MLBC_H
#define PWM_MLBC_H

#include "main.h"
#include <stdio.h>
#include <string.h>

/* MLBC Parameters */
#define MLBC_INPUT_VOLTAGE_NOMINAL 24.0f    // 24V input
#define MLBC_OUTPUT_VOLTAGE_NOMINAL 312.0f  // 312V output
#define MLBC_PWM_FREQUENCY 40000.0f         // 40 kHz PWM frequency
#define MLBC_TIMER_FREQUENCY 90000000.0f    // 90 MHz TIM2 frequency

/* Soft-Start Parameters */
#define MLBC_SOFT_START_INITIAL_DUTY 0.0f   // Start from 0%

/* Debug Parameters */
#define MLBC_DEBUG_BUFFER_SIZE 100          // Debug string buffer size

/* Safety Limits */
#define MLBC_MAX_DUTY_CYCLE 0.75f           // Maximum duty cycle for safety
#define MLBC_MIN_DUTY_CYCLE 0.25f           // Minimum duty cycle

/**
 * @brief MLBC operation states
 */
typedef enum {
    MLBC_STATE_STOPPED,          // System stopped, no PWM output
    MLBC_STATE_SOFT_START,       // Software soft-start in progress
    MLBC_STATE_RUNNING,          // Normal operation
    MLBC_STATE_SHUTDOWN          // Shutdown in progress (duty → 0 → stopped)
} MLBC_State_t;

/**
 * @brief Main MLBC control structure
 */
typedef struct {
    /* Control Parameters */
    float duty_cycle;               // Current duty cycle (0.0 to 1.0)
    float target_duty_cycle;        // Target duty cycle (manually settable)
    MLBC_State_t state;             // Current system state

    /* Soft-Start Parameters */
    uint32_t soft_start_duration_ms;   // Soft-start duration (default 5000ms)
    uint32_t soft_start_begin_time;    // Timestamp when soft-start began
    float soft_start_target_duty;      // Target duty cycle to reach during soft-start
    uint8_t soft_start_active;         // 1 = soft-start in progress, 0 = not active

    /* Measurements (fed by main.c from DC sensor) */
    float input_voltage;            // For monitoring/debug only
    float input_current;            // For monitoring/debug only

    /* Debug System */
    uint8_t debug_flag;             // Enable/disable debug output
#if ENABLE_MLBC_DEBUG
    uint32_t debug_counter;         // Debug sample counter
#endif

    /* Timing */
    uint32_t system_tick;           // System tick counter for timing

} MLBC_TypeDef;

/* External Variables */
extern MLBC_TypeDef mlbc;
extern TIM_HandleTypeDef htim2;

/* Function Prototypes */

/**
 * @brief Initialize MLBC system
 */
void MLBC_Init(void);

/**
 * @brief Main MLBC update function (call from main loop)
 * Handles state machine and soft-start progression.
 */
void MLBC_Update(void);

/**
 * @brief Start the MLBC system with soft-start
 * Initiates soft-start sequence from 0% to target duty cycle.
 * Also enables POD PWM immediately for concurrent operation.
 */
void MLBC_Start(void);

/**
 * @brief Stop the MLBC system
 * Sets duty to 0 and disables POD PWM.
 */
void MLBC_Stop(void);

/**
 * @brief Set manual duty cycle (for open loop control)
 * @param duty: Duty cycle (0.0 to 1.0), clamped to MLBC_MIN/MAX
 */
void MLBC_Set_Target_Duty_Cycle(float duty);

/**
 * @brief Get target duty cycle
 * @return Target duty cycle (0.0 to 1.0)
 */
float MLBC_Get_Target_Duty_Cycle(void);

/**
 * @brief Set soft-start duration
 * @param duration_ms: Soft-start duration in milliseconds
 */
void MLBC_Set_Soft_Start_Duration(uint32_t duration_ms);

/**
 * @brief Get soft-start progress percentage
 * @return Progress percentage (0.0 to 100.0), 0.0 if not in soft-start
 */
float MLBC_Get_Soft_Start_Progress(void);

/**
 * @brief Set debug flag
 * @param flag: 1 to enable debug output, 0 to disable
 */
void MLBC_Set_Debug(uint8_t flag);

/**
 * @brief Transmit debug data via UART (call from main loop)
 */
void MLBC_Debug_Transmit(void);

/**
 * @brief Get current duty cycle
 * @return Current duty cycle (0.0 to 1.0)
 */
float MLBC_Get_Duty_Cycle(void);

/**
 * @brief Get current system state
 * @return: Current MLBC state
 */
MLBC_State_t MLBC_Get_State(void);

/**
 * @brief Apply PWM duty cycle to hardware timer
 */
void MLBC_Apply_PWM(void);

#endif /* PWM_MLBC_H */
