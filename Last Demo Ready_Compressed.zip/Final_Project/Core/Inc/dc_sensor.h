/**
 * @file dc_sensor.h
 * @brief DC Voltage and Current Sensor Module (Input Side of MLBC)
 * @author afuanandi
 * @date 2025
 *
 * This module handles DC voltage and current sensing using ADC2 with DMA.
 * It is a pure measurement module — no fault logic, no MLBC dependency.
 * Fault detection is handled by the system orchestrator (main.c).
 *
 * Sampling Strategy:
 * - Continuous ADC conversion with DMA circular buffering
 * - Buffer is constantly refreshed at high speed (~microseconds per cycle)
 * - Main loop reads current buffer contents every 20ms
 * - Simple averaging provides noise reduction
 *
 * DC sensor uses continuous sampling since DC signals have no phase relationship.
 * The DMA callback is used only to confirm DMA is operational, not for timing.
 */

#ifndef DC_SENSOR_H
#define DC_SENSOR_H

#include "main.h"
#include "math.h"
#include <stdio.h>
#include <string.h>

/* DC Sensor Parameters */
#define DC_VOLTAGE_NOMINAL 24.0f             // 24V nominal DC voltage
#define DC_CURRENT_NOMINAL 12.0f             // 12A nominal DC current

/* IIR Filter Configuration */
#define DC_IIR_FILTER_ALPHA 0.2f    // 0.0 = max smoothing, 1.0 = no smoothing

/* ADC Parameters */
#define DC_ADC_RESOLUTION 4096.0f            // 12-bit ADC (0-4095)
#define DC_ADC_VREF 3.3f                     // 3.3V reference voltage

/* DMA Buffer Configuration */
#define DC_AVERAGE_SAMPLES 100               		// Number of samples for rolling average
#define DC_DMA_BUFFER_SIZE (DC_AVERAGE_SAMPLES * 2)	// 100 samples × 2 channels = 200

/* Debug and Calibration */
#define DC_DEBUG_BUFFER_SIZE 100             // Debug string buffer size
#define DC_CALIBRATION_SAMPLES 20            // Samples to transmit in calibration mode

/* DMA Health Check */
#define DC_DMA_HEALTH_TIMEOUT_MS 1000        // Max time without DMA callback before error

/**
 * @brief DC Sensor operation modes
 */
typedef enum {
    DC_SENSOR_MODE_NORMAL,                   // Normal operation with filtering
    DC_SENSOR_MODE_CALIBRATION              // Raw ADC data transmission
} DC_Sensor_Mode_t;

/**
 * @brief Main DC Sensor control structure
 */
typedef struct {
    /* Operation Mode */
    DC_Sensor_Mode_t mode;

    /* Current Readings */
    float voltage;
    float current;

    /* DMA Buffer - Circular buffer with interleaved V/I samples */
    uint16_t dma_buffer[DC_DMA_BUFFER_SIZE]; // [V0,I0,V1,I1,...,V99,I99]

    /* DMA Health Monitoring
     * Note: For circular DMA with continuous ADC, the callback fires rapidly.
     * We use it only to confirm DMA is operational, not for timing.
     */
    volatile uint32_t dma_callback_count;    // Incremented by ISR
    uint32_t last_dma_callback_count;        // Snapshot for health check
    uint32_t last_health_check_time;         // Timestamp of last health check
    uint8_t dma_healthy;                     // 1 = DMA operational, 0 = timeout detected

    /* Filtered ADC Values */
    float voltage_adc_filtered;
    float current_adc_filtered;

    /* Calibration Parameters */
    float voltage_scale_factor;
    float current_scale_factor;
    float voltage_offset;
    float current_offset;

    /* IIR Filter State */
    float voltage_iir_filtered;             // IIR filtered voltage
    float current_iir_filtered;             // IIR filtered current
    uint8_t filter_initialized;             // Filter initialization

    /* Statistics */
    uint32_t measurement_count;

    /* Debug and Calibration */
    uint8_t debug_flag;
    uint32_t calibration_counter;
    char debug_buffer[DC_DEBUG_BUFFER_SIZE];
    uint8_t debug_data_ready;

} DC_Sensor_TypeDef;

/* External Variables */
extern DC_Sensor_TypeDef dc_sensor;
extern ADC_HandleTypeDef hadc2;
extern DMA_HandleTypeDef hdma_adc2;
extern UART_HandleTypeDef huart2;

/* Function Prototypes */

/**
 * @brief Initialize DC sensor system
 */
void DC_Sensor_Init(void);

/**
 * @brief Start DC sensor data acquisition
 */
void DC_Sensor_Start(void);

/**
 * @brief Stop DC sensor data acquisition
 */
void DC_Sensor_Stop(void);

/**
 * @brief Main update function (call from main loop every 20ms)
 * Reads current DMA buffer contents, applies filtering, and updates measurements.
 * Does NOT wait for DMA callback - buffer is always valid with circular DMA.
 */
void DC_Sensor_Update(void);

/**
 * @brief Set operation mode
 * @param mode: DC_SENSOR_MODE_NORMAL or DC_SENSOR_MODE_CALIBRATION
 */
void DC_Sensor_Set_Mode(DC_Sensor_Mode_t mode);

/**
 * @brief Get current operation mode
 * @return Current operation mode
 */
DC_Sensor_Mode_t DC_Sensor_Get_Mode(void);

/**
 * @brief Get DC voltage reading
 * @return DC voltage in Volts
 */
float DC_Sensor_Get_Voltage(void);

/**
 * @brief Get DC current reading
 * @return DC current in Amperes
 */
float DC_Sensor_Get_Current(void);

/**
 * @brief Check if DMA is healthy (operational)
 * @return 1 if DMA is operational, 0 if timeout detected
 */
uint8_t DC_Sensor_Is_DMA_Healthy(void);

/**
 * @brief Set voltage calibration parameters
 * @param scale_factor: Scaling factor (V/ADC_count)
 * @param offset: Offset compensation (ADC counts)
 */
void DC_Sensor_Set_Voltage_Calibration(float scale_factor, float offset);

/**
 * @brief Set current calibration parameters
 * @param scale_factor: Scaling factor (A/ADC_count)
 * @param offset: Offset compensation (ADC counts)
 */
void DC_Sensor_Set_Current_Calibration(float scale_factor, float offset);

/**
 * @brief Set debug flag
 * @param flag: 1 to enable debug output, 0 to disable
 */
void DC_Sensor_Set_Debug(uint8_t flag);

/**
 * @brief Transmit DC sensor debug data via UART (call from main loop)
 * Only transmits when monitoring mode is OFF to prevent conflicts
 */
void DC_Sensor_Debug_Transmit(void);

/**
 * @brief Transmit DC calibration data via UART (called from main calibration sequence)
 */
void DC_Transmit_Calibration_Data(void);

/**
 * @brief Get sensor statistics string
 * @param buffer: Output buffer for statistics
 * @param buffer_size: Size of output buffer
 */
void DC_Sensor_Get_Statistics(char* buffer, size_t buffer_size);

/**
 * @brief DMA conversion complete callback
 * Call this from HAL_ADC_ConvCpltCallback() in main.c
 * Note: For circular DMA, this fires rapidly. Used only for health monitoring.
 */
void DC_Sensor_DMA_Complete_Callback(void);

/* Internal Processing Functions */
void DC_Sensor_Apply_Filter(void);
void DC_Sensor_Apply_Calibration(void);
void DC_Sensor_Process_Normal_Mode(void);
float DC_Sensor_Apply_Single_Calibration(float raw_value, float scale_factor, float offset);

#endif /* DC_SENSOR_H */
