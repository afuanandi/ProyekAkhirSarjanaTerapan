/**
 * @file pod_pwm.h
 * @brief Phase Opposition Disposition PWM for 7-Level PUCI Inverter
 * @version 3.3 - Dual Mode Implementation
 * @author afuanandi & Claude
 * @date 2025
 *
 * This module implements two distinct modulation strategies:
 *
 * TRUE_PWM = 0: Fixed Threshold Method
 *   - Direct threshold comparison at ±0.5, ±1.5, ±2.5
 *   - Rate limiting (±1 level per ISR call)
 *   - Efficient CPU usage
 *   - Best for production use
 *
 * TRUE_PWM = 1: Multi-Carrier POD Method
 *   - 6 software carriers at 2.5kHz
 *   - POD phase arrangement (positive carriers in-phase, negative opposite)
 *   - Carrier-based comparison allowing natural PWM behavior
 *   - Higher CPU usage
 */

#ifndef POD_PWM_H
#define POD_PWM_H

#include "main.h"
#include "math.h"
#include <stdio.h>
#include <string.h>

/* ========== CONFIGURATION PARAMETERS ========== */

/* Mathematical Constants */
#define PI 3.14159265359f
#define TWO_PI (2.0f * PI)

/* System Frequencies */
#define FUNDAMENTAL_FREQ 50.0f      // Output AC frequency (Hz)
#define UPDATE_FREQ 5000.0f         // ISR frequency (Hz) - TIM1 center-aligned fires 2x per period
#define CARRIER_FREQ 2500.0f        // Carrier frequency (Hz) - for TRUE_PWM=1 mode

/* Modulation Parameters */
#define MAX_MODULATION_INDEX 2.0f
#define NORMAL_MODULATION_INDEX 1.0f

/* Switching Configuration */
#define NUM_PATTERNS 3              // Number of switching patterns for capacitor balancing
#define NUM_LEVELS 7                // Output voltage levels (-3 to +3)
#define NUM_SWITCHES 8              // Total number of switches (S1-S8)

/* Debug System */
#define DEBUG_SAMPLES_PER_CYCLE 200 // Samples per 50Hz cycle (5000Hz / 50Hz / 2.5 cycles)
#define DEBUG_CYCLES_TO_CAPTURE 2   // Number of cycles to capture

/* ========== TYPE DEFINITIONS ========== */

/**
 * @brief Operation modes for POD PWM system
 */
typedef enum {
    POD_PWM_MODE_OPEN_LOOP,     // Manual modulation index control
    POD_PWM_MODE_CLOSED_LOOP,   // Fuzzy controller sets modulation index
    POD_PWM_MODE_MANUAL_LEVEL   // Direct level control (testing only)
} POD_PWM_Mode_t;

/**
 * @brief Switching state for all 8 switches
 *
 * Switch pairs (complementary):
 * - S1/S5: TIM1 CH1 and CH1N
 * - S2/S6: TIM1 CH2 and CH2N
 * - S3/S7: TIM8 CH1 and CH1N
 * - S4/S8: TIM8 CH2 and CH2N
 */
typedef struct {
    uint8_t S1, S2, S3, S4;     // Main switches
    uint8_t S5, S6, S7, S8;     // Complementary switches
} SwitchingState;

/**
 * @brief Debug sample structure for waveform capture
 */
#if ENABLE_POD_PWM_DEBUG
typedef struct {
    float reference;
    int8_t level;
    uint8_t pattern_index;
#if TRUE_PWM == 1
    uint8_t carrier_state;
#endif
} DebugSample;
#endif

/**
 * @brief Main POD PWM control structure
 */
typedef struct {
    /* System Status */
    uint8_t system_enabled;            // Global enable flag (0=disabled, 1=enabled)

	/* Reference Generation */
    float reference;                    // Current reference value (-3.0 to +3.0)
    float reference_phase;              // Phase accumulator (0.0 to 1.0)

#if TRUE_PWM == 1
    /* Multi-Carrier POD Variables (TRUE_PWM = 1 only) */
    float carriers[6];                  // 6 software carriers for multi-level comparison
    uint8_t carrier_state;              // Current carrier state (0 or 1)
#endif

    /* Control Parameters */
    volatile float modulation_index;    // Current modulation index (0.0 to 2.0)
    POD_PWM_Mode_t mode;               // Current operation mode

    /* Level State */
    int8_t current_level;              // Current output level (-3 to +3)
    int8_t target_level;               // Target level (for rate limiting in TRUE_PWM=0)
    int8_t manual_level;               // Manual level override (testing mode)
    int8_t last_level;                 // Previous level for rate limiting

    /* Pattern Management */
    uint8_t pattern_index;             // Current switching pattern (0-2)

    /* Debug System */
    uint8_t debug_flag;                // Debug data collection enable flag
#if ENABLE_POD_PWM_DEBUG
    uint32_t debug_counter;            // Total ISR call counter
    DebugSample debug_buffer[DEBUG_SAMPLES_PER_CYCLE * DEBUG_CYCLES_TO_CAPTURE];
    uint32_t debug_buffer_index;       // Current position in debug buffer
    uint8_t debug_buffer_ready;        // Flag indicating buffer is full and ready to transmit
#endif
} POD_PWM_TypeDef;

/* ========== EXTERNAL VARIABLES ========== */

extern POD_PWM_TypeDef pod_pwm;
extern TIM_HandleTypeDef htim1;     // Master timer (S1, S2)
extern TIM_HandleTypeDef htim8;     // Slave timer (S3, S4)

/* ========== FUNCTION PROTOTYPES ========== */

/**
 * @brief Initialize POD PWM system
 *
 * Initializes data structures, starts timers, and sets up PWM channels.
 * Call this once during system initialization.
 */
void POD_PWM_Init(void);

/**
 * @brief Main PWM update function
 *
 * Called from TIM1 ISR at 5kHz rate. Generates reference, determines output level,
 * and applies switching states. This is the core modulation engine.
 */
void POD_PWM_Update_Reference(void);

/**
 * @brief Set operation mode
 * @param mode: Desired operation mode
 */
void POD_PWM_Set_Mode(POD_PWM_Mode_t mode);

/**
 * @brief Set modulation index, either openloop or closeloop
 * @param mi: Modulation index (0.0 to 2.0)
 */
void POD_PWM_Set_MI(float mi);

/**
 * @brief Get current modulation index
 * @return: Current modulation index value
 */
float POD_PWM_Get_Current_MI(void);

/**
 * @brief Set manual output level (testing mode)
 * @param level: Desired output level (-3 to +3)
 */
void POD_PWM_Set_Manual_Level(int8_t level);

/**
 * @brief Enable or disable PWM system
 * @param enable: 1 to enable, 0 to disable
 *
 * When disabled, output is forced to level 0 (all switches OFF)
 */
void POD_PWM_Enable(uint8_t enable);

/**
 * @brief Enable or disable debug data collection
 * @param flag: 1 to enable, 0 to disable
 */
void POD_PWM_Set_Debug(uint8_t flag);

/**
 * @brief Handle switching pattern rotation
 *
 * Called automatically at zero crossing (once per 50Hz cycle).
 * Rotates through 3 patterns for capacitor voltage balancing.
 */
void POD_PWM_Handle_Pattern_Switching(void);

/**
 * @brief Apply switching states to hardware
 * @param level: Voltage level to output (-3 to +3)
 * @param pattern: Switching pattern to use (0-2)
 *
 * Looks up switching states and writes CCR values to timer registers.
 */
void POD_PWM_Apply_Switching_States(int8_t level, uint8_t pattern);

/**
 * @brief Get switching state from lookup table
 * @param level: Voltage level (-3 to +3)
 * @param pattern: Pattern index (0-2)
 * @return: Switching state structure with S1-S8 values
 */
SwitchingState POD_PWM_Get_Switching_State(int8_t level, uint8_t pattern);

/**
 * @brief Transmit debug data via UART
 *
 * Sends captured waveform data as CSV format. Call this when
 * debug_buffer_ready flag is set.
 */
void POD_PWM_Debug_Transmit(void);

/**
 * @brief Reset debug counter and buffer
 */
void POD_PWM_Reset_Debug_Counter(void);

#endif /* POD_PWM_H */
