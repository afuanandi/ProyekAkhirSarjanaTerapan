/**
 * @file fuzzy_structures.h
 * @brief Data structures for Interval Type-2 Fuzzy Logic Controller
 * @author afuanandi & Claude
 * @date 2025
 */

#ifndef FUZZY_STRUCTURES_H
#define FUZZY_STRUCTURES_H

#include <stdint.h>

/**
 * @brief Type definition for floating point type used in fuzzy calculations
 * Note: Can be changed to float for memory optimization if needed
 */
typedef float fuzzy_t;

/**
 * @brief Interval Type-2 Triangular Membership Function
 *
 * UMF: Triangle [a, b, c] with peak = 1.0
 * LMF: Triangle [a_lower, b, c_lower] with peak = lower_height
 * FOU: Area between UMF and LMF
 */
typedef struct {
    /* Upper MF (UMF) parameters */
    float a;                    // Left point
    float b;                    // Center point (peak)
    float c;                    // Right point

    /* Lower MF (LMF) parameters */
    float a_lower;              // LMF left point (narrower than UMF)
    float c_lower;              // LMF right point (narrower than UMF)
    float lower_height;         // LMF peak height (typically 0.5)
} TriangularMF;

/**
 * @brief IT2 Firing Interval
 * Contains upper and lower firing strengths for a rule
 */
typedef struct {
    float upper;                // Upper firing strength (from UMF)
    float lower;                // Lower firing strength (from LMF)
} IT2_FiringInterval;

/**
 * @brief Input structure
 */
typedef struct {
    char name[20];     // Name of the input
    fuzzy_t min;       // Minimum value of range
    fuzzy_t max;       // Maximum value of range
    uint8_t numMFs;    // Number of membership functions
    TriangularMF* mfs; // Array of membership functions
} FuzzyInput;

/**
 * @brief Output structure
 */
typedef struct {
    char name[20];     // Name of the output
    fuzzy_t min;       // Minimum value of range
    fuzzy_t max;       // Maximum value of range
    uint8_t numMFs;    // Number of membership functions
    TriangularMF* mfs; // Array of membership functions
} FuzzyOutput;

/**
 * @brief Rule antecedent and consequent structure
 */
typedef struct {
    uint8_t input1MF;  // Index of input 1 membership function
    uint8_t input2MF;  // Index of input 2 membership function
    uint8_t outputMF;  // Index of output membership function
    fuzzy_t weight;    // Rule weight (typically 1.0)
} FuzzyRule;

/**
 * @brief Type-2 fuzzy system structure
 */
typedef struct {
    FuzzyInput inputs[2];     // Array of inputs
    FuzzyOutput output;       // Output
    FuzzyRule* rules;         // Array of rules
    uint8_t numRules;         // Number of rules

    // Inference methods
    enum {
        AND_MIN,
        AND_PROD
    } andMethod;

    enum {
        OR_MAX,
        OR_PROBOR
    } orMethod;

    enum {
        DEFUZZ_CENTROID,
        DEFUZZ_BISECTOR,
        DEFUZZ_MOM,
        DEFUZZ_SOM,
        DEFUZZ_LOM
    } defuzzMethod;

    enum {
        TR_KARNIKMENDEL,
        TR_ENHANCED_KARNIKMENDEL,
        TR_ITERATIVE
    } typeReductionMethod;
} FuzzySystem;

#endif /* FUZZY_STRUCTURES_H */
