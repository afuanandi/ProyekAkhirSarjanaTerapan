/**
 * @file fuzzy_init.h
 * @brief IT2 Fuzzy System Initialization and Inference Engine
 * @author afuanandi & Claude
 * @date 2025
 *
 * This module owns:
 * - Fuzzy system data (MFs, rules, static storage)
 * - System initialization (UMF/LMF definitions, rule base)
 * - Inference engine (fuzzification, rule evaluation, type reduction)
 *
 * The controller module (fuzzy_controller) handles:
 * - State machine, error calculation, output clamping, debug
 */

#ifndef FUZZY_INIT_H
#define FUZZY_INIT_H

#include "fuzzy_structures.h"

/**
 * @brief Initialize the fuzzy system with membership functions and rules
 * @param system Pointer to fuzzy system structure
 * @return 0 if successful, -1 if error
 */
int InitializeFuzzySystem(FuzzySystem* system);

/**
 * @brief IT2 fuzzy inference with Nie-Tan type-reduction
 *
 * Process:
 * 1. Fuzzify inputs using IT2 MFs -> firing intervals [f_lower, f_upper]
 * 2. Apply rules using meet (min) operator on intervals
 * 3. Type-reduce using Nie-Tan: y = (y_upper + y_lower) / 2
 *
 * @param system: Pointer to initialized fuzzy system
 * @param input1: First input value (error)
 * @param input2: Second input value (error derivative)
 * @param y_upper: Output pointer for upper centroid (NULL if not needed)
 * @param y_lower: Output pointer for lower centroid (NULL if not needed)
 * @return Crisp output value (modulation index)
 */
float FuzzyInference(FuzzySystem* system, float input1, float input2,
                     float* y_upper, float* y_lower);

#endif /* FUZZY_INIT_H */
