/**
 * @file monitoring_dma.c
 * @brief DMA-based non-blocking CSV monitoring implementation
 * @author afuanandi & Claude
 * @date 2026
 * @version 4.0 - Double-buffer with Native UART Interrupt Synchronization
 *
 * Uses USART2 (ST-LINK Virtual COM Port) for telemetry output.
 * CPU formats data into an idle buffer while DMA concurrently transmits
 * the active buffer. Buffer swapping occurs at 50Hz, synchronized by
 * the HAL_UART_TxCpltCallback.
 */

#include "monitoring_dma.h"
#include "usart.h"
#include "ac_sensor.h"
#include "dc_sensor.h"
#include "fuzzy_controller.h"
#include "pwm_mlbc.h"
#include "pod_pwm.h"
#include <stdio.h>
#include <string.h>

/* Global monitoring instance */
Monitoring_t monitoring;

/* ========== INTERNAL HELPERS ========== */

/**
 * @brief Start DMA transmission for the active buffer
 * @param len: Number of bytes to transmit
 * @return 1 if successfully started, 0 if error
 *
 * Note: We rely on the HAL's native state machine here.
 * When the previous DMA transfer finishes, the USART2 global interrupt
 * fires, the HAL clears huart2.gState, and calls our TxCpltCallback
 * which clears monitoring.dma_busy.
 */
static uint8_t Monitoring_Start_DMA(uint16_t len) {
    if (HAL_UART_Transmit_DMA(&huart2, (uint8_t*)monitoring.active_buffer, len) == HAL_OK) {
        monitoring.dma_busy = 1;
        monitoring.last_dma_start_time = HAL_GetTick();
        return 1;
    } else {
        monitoring.dma_errors++;
        return 0;
    }
}

/**
 * @brief Swap active and idle buffer pointers
 */
static void Monitoring_Swap_Buffers(void) {
    char *temp = monitoring.active_buffer;
    monitoring.active_buffer = monitoring.idle_buffer;
    monitoring.idle_buffer = temp;
}

/* ========== PUBLIC FUNCTIONS ========== */

/**
 * @brief Initialize monitoring system
 */
void Monitoring_Init(void) {
    memset(&monitoring, 0, sizeof(Monitoring_t));

    /* Initialize double-buffer pointers */
    monitoring.active_buffer = monitoring.csv_buffer_a;
    monitoring.idle_buffer = monitoring.csv_buffer_b;

    monitoring.idle_len = 0;
    monitoring.idle_has_data = 0;
    monitoring.dma_busy = 0;
    monitoring.header_sent = 0;
    monitoring.sample_counter = 0;
    monitoring.samples_skipped = 0;
    monitoring.dma_errors = 0;
    monitoring.last_dma_start_time = 0;
}

/**
 * @brief DMA transmit complete callback
 * Called from HAL_UART_TxCpltCallback() in main.c (ISR context).
 * This is the critical fix: clears busy flag directly, no gState dependency.
 */
void Monitoring_DMA_TxComplete_Callback(void) {
    monitoring.dma_busy = 0;
}

/**
 * @brief Check if DMA transmission is in progress
 * Includes timeout detection to recover from stuck DMA
 */
uint8_t Monitoring_Is_DMA_Busy(void) {
    if (monitoring.dma_busy) {
        uint32_t elapsed = HAL_GetTick() - monitoring.last_dma_start_time;
        if (elapsed > MONITORING_TIMEOUT_MS) {
            /* DMA appears stuck — force abort and reset */
            HAL_UART_AbortTransmit(&huart2);
            monitoring.dma_busy = 0;
            monitoring.dma_errors++;
        }
    }

    return monitoring.dma_busy;
}

/**
 * @brief Reset monitoring state
 * Aborts any ongoing DMA transfer and resets counters
 */
void Monitoring_Reset(void) {
    if (monitoring.dma_busy || huart2.gState != HAL_UART_STATE_READY) {
        HAL_UART_AbortTransmit(&huart2);
    }

    monitoring.dma_busy = 0;
    monitoring.idle_len = 0;
    monitoring.idle_has_data = 0;
    monitoring.sample_counter = 0;
    monitoring.samples_skipped = 0;
    monitoring.header_sent = 0;

    /* Reset buffer pointers to known state */
    monitoring.active_buffer = monitoring.csv_buffer_a;
    monitoring.idle_buffer = monitoring.csv_buffer_b;
}

/**
 * @brief Get skip statistics
 */
uint32_t Monitoring_Get_Skipped_Count(void) {
    return monitoring.samples_skipped;
}

/**
 * @brief Get DMA error count
 */
uint32_t Monitoring_Get_Error_Count(void) {
    return monitoring.dma_errors;
}

/**
 * @brief Get monitoring statistics string
 */
void Monitoring_Get_Statistics(char* buffer, size_t buffer_size) {
    snprintf(buffer, buffer_size,
        "MON: Sent=%lu, Skip=%lu, Err=%lu",
        monitoring.sample_counter,
        monitoring.samples_skipped,
        monitoring.dma_errors);
}

/**
 * @brief Non-blocking CSV logging with DMA double-buffer
 *
 * Algorithm:
 *   1. If header not sent yet → format header into idle buffer, try to send
 *   2. Format data into idle buffer (always succeeds — overwrites any pending)
 *   3. If DMA idle → swap buffers, start DMA on new active buffer
 *   4. If DMA busy → data sits in idle buffer, will be sent next cycle
 *      (the overwritten pending data counts as 1 skip)
 */
uint8_t Monitoring_CSV_Log_DMA(void) {
    int len;

    /* ========== STEP 1: SEND HEADER IF NEEDED ========== */
    if (!monitoring.header_sent) {
        /* Check timeout on any stuck DMA from previous session */
        Monitoring_Is_DMA_Busy();

        if (!monitoring.dma_busy) {
#if LIGHT_MONITORING
            len = snprintf(monitoring.active_buffer, CSV_BUFFER_SIZE,
                "Index,Time_ms,Target_V,AC_V,MI,Err,dErr,Skip\r\n");
#else
            len = snprintf(monitoring.active_buffer, CSV_BUFFER_SIZE,
                "Index,Time_ms,State,Mode,Target_V,AC_V,AC_I,AC_W,DC_V,DC_I,DC_W,MI,Duty,Err,dErr,Fz,Skip\r\n");
#endif
            if (len > 0 && len < CSV_BUFFER_SIZE) {
                if (Monitoring_Start_DMA(len)) {
                    monitoring.header_sent = 1;
                    monitoring.sample_counter = 0;
                    return 1;
                }
            } else {
                monitoring.dma_errors++;
            }
        }
        return 0;
    }

    /* ========== STEP 2: FORMAT DATA INTO IDLE BUFFER ========== */

    /* Gather common telemetry (used in both modes) */
    uint32_t timestamp = HAL_GetTick();
    float target_voltage = Fuzzy_Controller_Get_Target_Voltage();
    float ac_voltage = AC_Sensor_Get_Voltage_RMS();
    float current_mi = POD_PWM_Get_Current_MI();
    float voltage_error = Fuzzy_Controller_Get_Error();
    float fuzzy_derror = Fuzzy_Controller_Get_Error_Derivative();

#if !LIGHT_MONITORING
    /* Gather extended telemetry (only used in full 16-column CSV mode) */
    float ac_current = AC_Sensor_Get_Current_RMS();
    float ac_power = ac_voltage * ac_current;

    float dc_voltage = DC_Sensor_Get_Voltage();
    float dc_current = DC_Sensor_Get_Current();
    float dc_power = dc_voltage * dc_current;

    float mlbc_duty = MLBC_Get_Duty_Cycle();

    uint8_t state_code;
    switch(system_state) {
    	case SYSTEM_STATE_OFF:               state_code = 0; break;
    	case SYSTEM_STATE_STARTING:          state_code = 1; break;
    	case SYSTEM_STATE_RUNNING:           state_code = 2; break;
    	case SYSTEM_STATE_SHUTDOWN_DELAY:    state_code = 3; break;
    	default:                             state_code = 255; break;
    }

    uint8_t mode_code = (system_mode == SYSTEM_MODE_OPEN_LOOP) ? 0 : 1;

    uint8_t fuzzy_state_code = (system_mode == SYSTEM_MODE_CLOSED_LOOP)
								? (uint8_t)Fuzzy_Controller_Get_State() : 0;
#endif

    /* Format into idle buffer — this always succeeds regardless of DMA state */
#if LIGHT_MONITORING
    len = snprintf(monitoring.idle_buffer, CSV_BUFFER_SIZE,
        "%lu,%lu,%.0f,%.1f,%.3g,%.2f,%.2f,%lu\r\n",
        monitoring.sample_counter,
        timestamp,
        target_voltage,
        ac_voltage,
        current_mi,
        voltage_error,
        fuzzy_derror,
        monitoring.samples_skipped
    );
#else
    len = snprintf(monitoring.idle_buffer, CSV_BUFFER_SIZE,
        "%lu,%lu,"
        "%d,%d,"
        "%.1f,"
        "%.1f,%.2f,%.1f,"
        "%.1f,%.2f,%.1f,"
        "%.3g,%.3f,"
        "%.2f,%.2f,%d,%lu\r\n",
        monitoring.sample_counter,
        timestamp,
        state_code,
        mode_code,
        target_voltage,
        ac_voltage, ac_current, ac_power,
        dc_voltage, dc_current, dc_power,
        current_mi, mlbc_duty,
        voltage_error, fuzzy_derror, fuzzy_state_code,
        monitoring.samples_skipped
    );
#endif

    /* Validate format result */
    if (len <= 0 || len >= CSV_BUFFER_SIZE) {
        monitoring.dma_errors++;
        return 0;
    }

    monitoring.idle_len = (uint16_t)len;
    monitoring.idle_has_data = 1;

    /* ========== STEP 3: TRY TO TRANSMIT ========== */

    /* Check timeout recovery (safeguard only, should rarely trigger in v4.0) */
    Monitoring_Is_DMA_Busy();

    if (monitoring.dma_busy) {
    	/*
    	 * DMA is legitimately still transmitting the previous buffer.
    	 * Data sits in the idle buffer. If this function is called again
    	 * before DMA finishes, the idle buffer gets overwritten with
    	 * the newest data. This is counted as a skip.
    	 */
    	monitoring.samples_skipped++;
    	return 0;
    }

    /* DMA is idle — swap and transmit */
    Monitoring_Swap_Buffers();
    uint16_t tx_len = monitoring.idle_len;  /* Save before clearing */

    monitoring.idle_has_data = 0;
    monitoring.idle_len = 0;

    if (Monitoring_Start_DMA(tx_len)) {
        monitoring.sample_counter++;
        return 1;
    }

    return 0;
}
