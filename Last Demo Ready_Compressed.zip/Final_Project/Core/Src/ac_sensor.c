/**
 * @file ac_sensor.c
 * @brief AC Sensor Implementation (Circular DMA)
 */

#include "ac_sensor.h"
#include <stdio.h>
#include <math.h>
#include <string.h>

/* Global Instance */
AC_Sensor_t ac_sensor;

/* Callback Registry */
static void (*ac_sensor_callback)(float, float) = NULL;

/* Private Helpers */
static void AC_Process_Buffer_Segment(uint32_t offset, uint32_t count);
static float AC_Apply_Calibration(float raw, float scale, float offset);

/**
 * @brief Initialize default parameters and state.
 */
void AC_Sensor_Init(void) {
    memset(&ac_sensor, 0, sizeof(AC_Sensor_t));

    /* Default Calibration Factors */
    ac_sensor.v_scale = 0.3692f;
    ac_sensor.v_offset = -0.8919f;
    ac_sensor.i_scale = 0.00167f;
    ac_sensor.i_offset = 0.0f;

    ac_sensor.mode = AC_MODE_NORMAL;
    ac_sensor.status = AC_STATUS_IDLE;
    ac_sensor.initialized = 1;

    printf("AC Sensor Initialized: Circular DMA Ready\r\n");
}

/**
 * @brief Start continuous sampling.
 * Configures DMA for Circular Mode (800 samples) and starts TIM3 trigger.
 */
void AC_Sensor_Start(void) {
    if (!ac_sensor.initialized) return;

    HAL_ADC_Stop_DMA(&hadc1); // Safety stop

    /* Reset Flags */
    ac_sensor.half_transfer_ready = 0;
    ac_sensor.full_transfer_ready = 0;

    /* Start DMA in Circular Mode */
    if (HAL_ADC_Start_DMA(&hadc1, (uint32_t*)ac_sensor.dma_buffer, AC_NORMAL_BUFFER_SIZE) != HAL_OK) {
        ac_sensor.status = AC_STATUS_ERROR;
        printf("ERROR: AC DMA Start Failed\r\n");
    } else {
        ac_sensor.status = AC_STATUS_RUNNING;
        HAL_TIM_Base_Start(&htim3); // Start 10kHz Trigger
        printf("AC Sensor Started (Circular)\r\n");
    }
}

void AC_Sensor_Stop(void) {
    HAL_ADC_Stop_DMA(&hadc1);
    HAL_TIM_Base_Stop(&htim3);
    ac_sensor.status = AC_STATUS_IDLE;
}

/**
 * @brief Switch between Normal (Circular) and Calibration (Linear Snapshot).
 * Stopping sensor required before mode switch.
 */
void AC_Sensor_Set_Mode(AC_Mode_t mode) {
    if (ac_sensor.mode == mode) return;

    AC_Sensor_Stop();
    ac_sensor.mode = mode;

    if (mode == AC_MODE_NORMAL) {
        // Restore DMA Circular Mode
        hdma_adc1.Init.Mode = DMA_CIRCULAR;
        HAL_DMA_Init(&hdma_adc1);
        AC_Sensor_Start();
    }
    else if (mode == AC_MODE_CALIBRATION) {
        printf("AC: Switching to Calibration (Snapshot)...\r\n");
        // Temp switch to DMA Normal Mode for large snapshot
        hdma_adc1.Init.Mode = DMA_NORMAL;
        HAL_DMA_Init(&hdma_adc1);

        HAL_ADC_Start_DMA(&hadc1, (uint32_t*)ac_sensor.dma_buffer, AC_CALIB_BUFFER_SIZE);
        HAL_TIM_Base_Start(&htim3);
    }
}

/**
 * @brief Main Worker. Checks ISR flags and processes data segments.
 */
void AC_Sensor_Update(void) {
    if (ac_sensor.status != AC_STATUS_RUNNING && ac_sensor.mode != AC_MODE_CALIBRATION) return;

    /* Mode: Normal (Continuous) */
    if (ac_sensor.mode == AC_MODE_NORMAL) {
        /* Process First Half (Indices 0-399) */
        if (ac_sensor.half_transfer_ready) {
            ac_sensor.half_transfer_ready = 0;
            AC_Process_Buffer_Segment(0, AC_NORMAL_SAMPLES_PER_HALF);
        }
        /* Process Second Half (Indices 400-799) */
        if (ac_sensor.full_transfer_ready) {
            ac_sensor.full_transfer_ready = 0;
            AC_Process_Buffer_Segment(AC_NORMAL_SAMPLES_PER_HALF, AC_NORMAL_SAMPLES_PER_HALF);
        }
    }
    /* Mode: Calibration (Snapshot) */
    else if (ac_sensor.mode == AC_MODE_CALIBRATION) {
        if (ac_sensor.full_transfer_ready) {
            ac_sensor.full_transfer_ready = 0;
            AC_Sensor_Stop(); // Stop after capture
            printf("AC: Snapshot Captured (%d samples)\r\n", AC_CALIB_BUFFER_SIZE);
        }
    }
}

/**
 * @brief De-interleave raw data, calculate RMS, and filter results.
 * @param offset Start index in dma_buffer
 * @param count Total samples in this segment (must be even)
 */
static void AC_Process_Buffer_Segment(uint32_t offset, uint32_t count) {
    uint32_t v_sum = 0, i_sum = 0;
    uint32_t samples = count / 2; // Pairs

    /* 1. Extract & Calculate DC Offset (Mean Method) */
    for (uint32_t i = 0; i < samples; i++) {
        uint32_t idx = offset + (i * 2);
        ac_sensor.voltage_raw[i] = ac_sensor.dma_buffer[idx];
        ac_sensor.current_raw[i] = ac_sensor.dma_buffer[idx+1];

        v_sum += ac_sensor.voltage_raw[i];
        i_sum += ac_sensor.current_raw[i];
    }
    ac_sensor.v_midpoint = (float)v_sum / (float)samples;
    ac_sensor.i_midpoint = (float)i_sum / (float)samples;

    /* 2. Calculate RMS (Sum of Squares) */
    float v_sq_sum = 0.0f, i_sq_sum = 0.0f;
    for (uint32_t i = 0; i < samples; i++) {
        float v_ac = (float)ac_sensor.voltage_raw[i] - ac_sensor.v_midpoint;
        float i_ac = (float)ac_sensor.current_raw[i] - ac_sensor.i_midpoint;

        v_sq_sum += v_ac * v_ac;
        i_sq_sum += i_ac * i_ac;
    }
    float v_inst = sqrtf(v_sq_sum / (float)samples);
    float i_inst = sqrtf(i_sq_sum / (float)samples);

    /* 3. Store raw RMS (pre-calibration) */
    ac_sensor.v_rms_raw = v_inst;
    ac_sensor.i_rms_raw = i_inst;

    /* 4. Apply Calibration & IIR Filter */
    float v_cal = AC_Apply_Calibration(v_inst, ac_sensor.v_scale, ac_sensor.v_offset);
    float i_cal = AC_Apply_Calibration(i_inst, ac_sensor.i_scale, ac_sensor.i_offset);

    ac_sensor.voltage_rms = (AC_IIR_FILTER_ALPHA * v_cal) + ((1.0f - AC_IIR_FILTER_ALPHA) * ac_sensor.voltage_rms);
    ac_sensor.current_rms = (AC_IIR_FILTER_ALPHA * i_cal) + ((1.0f - AC_IIR_FILTER_ALPHA) * ac_sensor.current_rms);

    ac_sensor.process_count++;
    ac_sensor.debug_data_ready = 1;

    /* 5. Trigger Control Loop */
    if (ac_sensor_callback) {
        ac_sensor_callback(ac_sensor.voltage_rms, ac_sensor.current_rms);
    }
}

/* ==========================================================================
 * INTERRUPT CALLBACKS
 * ========================================================================== */

void AC_Sensor_HalfTransfer_Callback(void) {
    if (ac_sensor.mode == AC_MODE_NORMAL) ac_sensor.half_transfer_ready = 1;
}

void AC_Sensor_FullTransfer_Callback(void) {
    ac_sensor.full_transfer_ready = 1;
}

/* ==========================================================================
 * UTILITIES
 * ========================================================================== */

void AC_Sensor_Register_Callback(void (*callback)(float, float)) {
    ac_sensor_callback = callback;
}

static float AC_Apply_Calibration(float raw, float scale, float offset) {
    float val = (raw * scale) + offset;
    return (val < 0.0f) ? 0.0f : val;
}

float AC_Sensor_Get_Voltage_RMS(void) { return ac_sensor.voltage_rms; }
float AC_Sensor_Get_Current_RMS(void) { return ac_sensor.current_rms; }

void AC_Sensor_Set_Debug(uint8_t flag) {
	ac_sensor.debug_enabled = flag;
    printf("AC Sensor debug %s\r\n", flag ? "enabled" : "disabled");
}

void AC_Sensor_Debug_Transmit(void) {
    if (ac_sensor.debug_enabled && ac_sensor.debug_data_ready) {
    	printf("AC: V=%.2f I=%.2f VRaw=%.2f IRaw=%.2f Cnt: %lu\r\n",
    			ac_sensor.voltage_rms, ac_sensor.current_rms,
				ac_sensor.v_rms_raw, ac_sensor.i_rms_raw,
				ac_sensor.process_count);
    }
}

void AC_Transmit_Calibration_Data(void) {
    uint32_t pairs = AC_CALIB_BUFFER_SIZE / 2;
    printf("=== AC SNAPSHOT (%lu pairs) ===\r\n", pairs);
    for(uint32_t i=0; i<pairs; i++) {
        printf("%lu,%d,%d\r\n", i, ac_sensor.dma_buffer[i*2], ac_sensor.dma_buffer[i*2+1]);
        if(i % 50 == 0) HAL_Delay(1); // Anti-overflow delay
    }
    printf("=== END SNAPSHOT ===\r\n");
}
