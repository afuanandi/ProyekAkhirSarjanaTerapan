/**
 * @file dc_sensor.c
 * @brief DC Voltage and Current Sensor Module Implementation
 * @author afuanandi
 * @date 2025
 *
 * DMA-based DC sensor with continuous conversion and circular buffering.
 * Pure measurement module — fault detection is handled by main.c.
 * Update rate: 20ms (synchronized with main system loop)
 *
 * Design Note:
 * DC sensor uses continuous circular DMA. The buffer is constantly being
 * refreshed, and we simply read its current contents every 20ms. The DMA
 * callback is used only to verify DMA is operational (health check), not
 * for timing synchronization.
 */

#include "dc_sensor.h"

/* Global DC Sensor structure */
DC_Sensor_TypeDef dc_sensor;

/**
 * @brief Initialize DC sensor system
 */
void DC_Sensor_Init(void) {
    /* Clear structure */
    memset(&dc_sensor, 0, sizeof(DC_Sensor_TypeDef));

    /* Initialize mode */
    dc_sensor.mode = DC_SENSOR_MODE_NORMAL;

    /* Initialize DC Voltage calibration parameters (Done) */
    dc_sensor.voltage_scale_factor = 0.0352f;
    dc_sensor.voltage_offset = -55.609f;

    /* TODO: Initialize DC Current calibration parameters */
    dc_sensor.current_scale_factor = DC_CURRENT_NOMINAL / (DC_ADC_RESOLUTION * 0.7f);
    dc_sensor.current_offset = 0.0f;

    /* Initialize statistics */
    dc_sensor.measurement_count = 0;

    /* Initialize DMA health monitoring */
    dc_sensor.dma_callback_count = 0;
    dc_sensor.last_dma_callback_count = 0;
    dc_sensor.last_health_check_time = 0;
    dc_sensor.dma_healthy = 0;

    /* Initialize debug */
    dc_sensor.debug_flag = 0;
    dc_sensor.calibration_counter = 0;

    printf("DC Sensor initialized - Continuous DMA circular buffer\r\n");
}

/**
 * @brief Start DC sensor data acquisition
 */
void DC_Sensor_Start(void) {
    /* Reset filter state for fresh start */
    dc_sensor.voltage_iir_filtered = 0.0f;
    dc_sensor.current_iir_filtered = 0.0f;
    dc_sensor.filter_initialized = 0;

    /* Reset DMA health monitoring */
    dc_sensor.dma_callback_count = 0;
    dc_sensor.last_dma_callback_count = 0;
    dc_sensor.last_health_check_time = HAL_GetTick();
    dc_sensor.dma_healthy = 0;

    /* Start ADC2 with DMA in circular mode */
    if (HAL_ADC_Start_DMA(&hadc2,
                          (uint32_t*)dc_sensor.dma_buffer,
                          DC_DMA_BUFFER_SIZE) != HAL_OK) {
        printf("ERROR: Failed to start ADC2 with DMA\r\n");
        return;
    }

    printf("DC Sensor started - Circular DMA active (%d samples)\r\n",
           DC_DMA_BUFFER_SIZE);
}

/**
 * @brief Stop DC sensor data acquisition
 */
void DC_Sensor_Stop(void) {
    HAL_ADC_Stop_DMA(&hadc2);
    printf("DC Sensor stopped\r\n");
}

/**
 * @brief Set operation mode
 */
void DC_Sensor_Set_Mode(DC_Sensor_Mode_t mode) {
    if(dc_sensor.mode != mode) {
        dc_sensor.mode = mode;
        dc_sensor.calibration_counter = 0;

        printf("DC Sensor: Mode -> %s\r\n",
               (mode == DC_SENSOR_MODE_NORMAL) ? "NORMAL" : "CALIBRATION");
    }
}


/**
 * @brief Main update function (call from main loop every 20ms)
 * With circular DMA on continuous ADC, the buffer is always valid and
 * constantly being updated. We simply read its current contents.
 * No need to wait for a "ready" flag.
 */
void DC_Sensor_Update(void) {
    uint32_t current_time = HAL_GetTick();

    /* ========== DMA Health Check ========== */
    if ((current_time - dc_sensor.last_health_check_time) >= DC_DMA_HEALTH_TIMEOUT_MS) {
        if (dc_sensor.dma_callback_count == dc_sensor.last_dma_callback_count) {
            /* No DMA callbacks received in timeout period — DMA may be stuck */
            dc_sensor.dma_healthy = 0;

            /* Attempt recovery: restart DMA */
            HAL_ADC_Stop_DMA(&hadc2);
            if (HAL_ADC_Start_DMA(&hadc2,
                                  (uint32_t*)dc_sensor.dma_buffer,
                                  DC_DMA_BUFFER_SIZE) == HAL_OK) {
                printf("DC Sensor: DMA restarted after timeout\r\n");
            }
        } else {
            dc_sensor.dma_healthy = 1;
        }

        dc_sensor.last_dma_callback_count = dc_sensor.dma_callback_count;
        dc_sensor.last_health_check_time = current_time;
    }

    /* ========== Process Data ========== */
    switch(dc_sensor.mode) {
        case DC_SENSOR_MODE_NORMAL:
            DC_Sensor_Process_Normal_Mode();
            break;

        case DC_SENSOR_MODE_CALIBRATION:
            /* Calibration mode — data ready for transmission */
            break;
    }

    /* Update statistics */
    dc_sensor.measurement_count++;

    /* Set debug flag if enabled */
    if(dc_sensor.debug_flag && dc_sensor.mode == DC_SENSOR_MODE_NORMAL) {
        dc_sensor.debug_data_ready = 1;
    }
}

/**
 * @brief DMA conversion complete callback
 * Called from HAL_ADC_ConvCpltCallback() in main.c
 */
void DC_Sensor_DMA_Complete_Callback(void) {
    dc_sensor.dma_callback_count++;
}

/* ==========================================================================
 * UTILITIES
 * ========================================================================== */

DC_Sensor_Mode_t DC_Sensor_Get_Mode(void) { return dc_sensor.mode; }
float DC_Sensor_Get_Voltage(void) { return dc_sensor.voltage; }
float DC_Sensor_Get_Current(void) { return dc_sensor.current; }
uint8_t DC_Sensor_Is_DMA_Healthy(void) { return dc_sensor.dma_healthy; }

/**
 * @brief Set voltage calibration parameters
 */
void DC_Sensor_Set_Voltage_Calibration(float scale_factor, float offset) {
    dc_sensor.voltage_scale_factor = scale_factor;
    dc_sensor.voltage_offset = offset;

    printf("DC Voltage calibration updated: Scale=%.6f, Offset=%.1f\r\n",
           scale_factor, offset);
}

/**
 * @brief Set current calibration parameters
 */
void DC_Sensor_Set_Current_Calibration(float scale_factor, float offset) {
    dc_sensor.current_scale_factor = scale_factor;
    dc_sensor.current_offset = offset;

    printf("DC Current calibration updated: Scale=%.6f, Offset=%.1f\r\n",
           scale_factor, offset);
}

/**
 * @brief Set debug flag
 */
void DC_Sensor_Set_Debug(uint8_t flag) {
    dc_sensor.debug_flag = flag;
    printf("DC Sensor debug %s\r\n", flag ? "enabled" : "disabled");
}

/**
 * @brief Apply averaging filter directly from DMA buffer
 */
void DC_Sensor_Apply_Filter(void) {
    uint32_t voltage_sum = 0;
    uint32_t current_sum = 0;

    for(uint8_t i = 0; i < DC_AVERAGE_SAMPLES; i++) {
        voltage_sum += dc_sensor.dma_buffer[i * 2];
        current_sum += dc_sensor.dma_buffer[i * 2 + 1];
    }

    dc_sensor.voltage_adc_filtered = (float)voltage_sum / (float)DC_AVERAGE_SAMPLES;
    dc_sensor.current_adc_filtered = (float)current_sum / (float)DC_AVERAGE_SAMPLES;
}

/**
 * @brief Apply calibration to convert ADC counts to real units
 */
void DC_Sensor_Apply_Calibration(void) {
    float voltage_new = DC_Sensor_Apply_Single_Calibration(
    		dc_sensor.voltage_adc_filtered,
    	    dc_sensor.voltage_scale_factor,
    	    dc_sensor.voltage_offset);

    float current_new = DC_Sensor_Apply_Single_Calibration(
    	    dc_sensor.current_adc_filtered,
    	    dc_sensor.current_scale_factor,
    	    dc_sensor.current_offset);

    /* ========== IIR LOW-PASS FILTER ========== */
    if (!dc_sensor.filter_initialized) {
        dc_sensor.voltage_iir_filtered = voltage_new;
        dc_sensor.current_iir_filtered = current_new;
        dc_sensor.filter_initialized = 1;
    } else {
        dc_sensor.voltage_iir_filtered = DC_IIR_FILTER_ALPHA * voltage_new +
                (1.0f - DC_IIR_FILTER_ALPHA) * dc_sensor.voltage_iir_filtered;
        dc_sensor.current_iir_filtered = DC_IIR_FILTER_ALPHA * current_new +
                (1.0f - DC_IIR_FILTER_ALPHA) * dc_sensor.current_iir_filtered;
    }

    dc_sensor.voltage = dc_sensor.voltage_iir_filtered;
    dc_sensor.current = dc_sensor.current_iir_filtered;

    /* Ensure values are non-negative */
    if(dc_sensor.voltage < 0.0f) dc_sensor.voltage = 0.0f;
    if(dc_sensor.current < 0.0f) dc_sensor.current = 0.0f;
}

/**
 * @brief Process data in normal mode (filtering and calibration)
 */
void DC_Sensor_Process_Normal_Mode(void) {
    DC_Sensor_Apply_Filter();
    DC_Sensor_Apply_Calibration();
}

/**
 * @brief Transmit DC calibration data (called from main calibration sequence)
 */
void DC_Transmit_Calibration_Data(void) {
    printf("=== DC CALIBRATION DATA START ===\r\n");
    printf("Samples: %d | Mode: DMA circular buffer\r\n", DC_AVERAGE_SAMPLES);
    printf("Index,Voltage_ADC,Current_ADC\r\n");

    for(uint8_t i = 0; i < DC_AVERAGE_SAMPLES; i++) {
        printf("%d,%d,%d\r\n",
               i,
               dc_sensor.dma_buffer[i * 2],
               dc_sensor.dma_buffer[i * 2 + 1]);

        if (i % 10 == 9) {
            HAL_Delay(1);
        }
    }

    printf("=== DC CALIBRATION DATA END ===\r\n\n");
}

/**
 * @brief Apply calibration to raw ADC value
 */
float DC_Sensor_Apply_Single_Calibration(float raw_value, float scale_factor, float offset) {
    return (raw_value * scale_factor) + offset;
}

/**
 * @brief Transmit DC sensor debug data via UART (call from main loop)
 * Only transmits when monitoring mode is OFF to prevent UART conflicts
 */
void DC_Sensor_Debug_Transmit(void) {
#if ENABLE_DC_SENSOR_DEBUG
    if (dc_sensor.debug_data_ready && monitoring_mode == MONITORING_MODE_OFF) {
        printf("DC: V=%.1f V, I=%.2f A, VRaw=%.1f, IRaw=%.1f, DMA=%lu, Health=%d\r\n",
               dc_sensor.voltage,
               dc_sensor.current,
               dc_sensor.voltage_adc_filtered,
               dc_sensor.current_adc_filtered,
               dc_sensor.dma_callback_count,
               dc_sensor.dma_healthy);
    }

    dc_sensor.debug_data_ready = 0;
#endif
}

/**
 * @brief Get sensor statistics string
 */
void DC_Sensor_Get_Statistics(char* buffer, size_t buffer_size) {
    const char* mode_str = (dc_sensor.mode == DC_SENSOR_MODE_NORMAL) ? "NORMAL" : "CALIBRATION";

    snprintf(buffer, buffer_size,
        "DC: %s,V:%.1fV,I:%.1fA,Meas:%lu,DMA:%lu,Health:%d",
        mode_str,
        dc_sensor.voltage, dc_sensor.current,
        dc_sensor.measurement_count,
        dc_sensor.dma_callback_count,
        dc_sensor.dma_healthy);
}
