/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "adc.h"
#include "dma.h"
#include "i2c.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "stdio.h"
#include "string.h"
#include "math.h"
#include "button_handler.h"
#include "pod_pwm.h"
#include "pwm_mlbc.h"
#include "ac_sensor.h"
#include "dc_sensor.h"
#include "oled_display.h"
#include "fuzzy_controller.h"
#include "monitoring_dma.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */

/* ==========================================================================
 * SYSTEM STATE VARIABLES
 * ========================================================================== */

/* Operating Modes */
volatile SystemMode_t system_mode = SYSTEM_MODE_OPEN_LOOP;
volatile SensorMode_t sensor_mode = SENSOR_MODE_NORMAL;
volatile MonitoringMode_t monitoring_mode = MONITORING_MODE_OFF;

/* System State Machine */
SystemState_t system_state = SYSTEM_STATE_OFF;
uint8_t system_initialized = 0;
uint8_t system_running = 0;
uint32_t shutdown_start_time = 0;
SystemFault_t system_fault_code = SYSTEM_FAULT_NONE;

/* Calibration State Machine */
static CalibrationState_t calib_state = CALIB_STATE_IDLE;
static uint32_t calib_timer = 0;
static uint8_t calib_triggered = 0;

/* ==========================================================================
 * TIMING VARIABLES
 * ========================================================================== */

static uint32_t main_loop_timer = 0;
static uint32_t fast_loop_timer = 0;
static uint32_t oled_update_timer = 0;

/* ==========================================================================
 * CONTROL VARIABLES
 * ========================================================================== */

float manual_modulation_index = MANUAL_MODULATION_INDEX_DEFAULT;
float manual_duty_cycle = MANUAL_DUTY_CYCLE_DEFAULT;

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */

/* System Initialization */
void System_Initialize(void);

/* Button and Switch Handling */
void Handle_Button_Inputs(void);
void Handle_Start_Stop_Button_NonBlocking(void);
void Handle_Mode_Button_NonBlocking(void);
void Handle_Shutdown_Timer(void);
void Update_System_Modes(void);

/* Fault Detection (centralized) */
void System_Check_Faults(void);
void System_Fault_Shutdown(SystemFault_t fault);

/* Calibration Mode Handler */
void Handle_Calibration_Mode(void);

/* Debug and Status Functions */
void Transmit_Debug_Data(void);
void Print_System_Status(void);

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

int _write(int file, char *ptr, int len) {
    if (!system_initialized) {
        HAL_UART_Transmit(&huart2, (uint8_t*)ptr, len, HAL_MAX_DELAY);
        return len;
    }

    /* When monitoring DMA owns USART2, discard ALL printf output */
    if (monitoring_mode == MONITORING_MODE_ON) { return len; }

    /* When monitoring is off but DMA might still be finishing, wait for it */
    if (monitoring.dma_busy) { return len; }

    HAL_UART_Transmit(&huart2, (uint8_t*)ptr, len, HAL_MAX_DELAY);
    return len;
}

/**
 * @brief AC sensor ISR callback — runs closed-loop control
 * Called from DMA complete ISR every 20ms after RMS is computed.
 */
void AC_Sensor_Control_Callback(float voltage_rms, float current_rms) {
    (void)current_rms;

    if (system_mode == SYSTEM_MODE_CLOSED_LOOP &&
        system_state == SYSTEM_STATE_RUNNING) {
        float fuzzy_mi = Fuzzy_Controller_Update(voltage_rms);
        POD_PWM_Set_MI(fuzzy_mi);
    }

    if (monitoring_mode == MONITORING_MODE_ON) { Monitoring_CSV_Log_DMA(); }
}

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */
  HAL_NVIC_SetPriority(SysTick_IRQn, 4, 0);
  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_USART2_UART_Init();
  MX_TIM1_Init();
  MX_TIM3_Init();
  MX_TIM8_Init();
  MX_I2C1_Init();
  MX_TIM2_Init();
  MX_ADC1_Init();
  MX_ADC2_Init();
  MX_USART3_UART_Init();
  /* USER CODE BEGIN 2 */
  Print_System_Status();
  System_Initialize();
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
	  uint32_t current_tick = HAL_GetTick();

      /* AC SENSOR PROCESSING — ungated, every loop iteration */
	  if (system_state == SYSTEM_STATE_STARTING ||
			  system_state == SYSTEM_STATE_RUNNING ||
			  system_state == SYSTEM_STATE_SHUTDOWN_DELAY) {
		  AC_Sensor_Update();
	  }

	  /* Handle button inputs and drive the non-blocking I2C state machine (5ms) */
	  if((current_tick - fast_loop_timer) >= FAST_LOOP_INTERVAL_MS) {
		  OLED_Display_Update_NonBlocking();  // Process chunked I2C transmission
		  Handle_Button_Inputs();
		  fast_loop_timer = current_tick;
	  }

	  /* Main system update loop (20ms) */
	  if((current_tick - main_loop_timer) >= MAIN_LOOP_INTERVAL_MS) {
	      Handle_Shutdown_Timer();
	      DC_Sensor_Update();
	      MLBC_Update();

	      /* Input power connected — measure, protect, and control */
	      if(system_state == SYSTEM_STATE_STARTING ||
	    		  system_state == SYSTEM_STATE_RUNNING) {

	    	  /* Centralized fault detection */
	    	  System_Check_Faults();

	    	  /* Check for MLBC soft-start completion */
	    	  if(system_state == SYSTEM_STATE_STARTING &&
	    			  MLBC_Get_State() == MLBC_STATE_RUNNING) {
	    		  system_state = SYSTEM_STATE_RUNNING;
	    		  if(monitoring_mode == MONITORING_MODE_OFF) {
	    			  printf(">>> SYSTEM RUNNING <<<\r\n");
	    		  }
	    	  }
	      }

	      Update_System_Modes();
	      Handle_Calibration_Mode();

	      /* System active — log and debug (includes discharge for waveform capture) */
	      if(system_state == SYSTEM_STATE_STARTING ||
	    		  system_state == SYSTEM_STATE_RUNNING ||
				  system_state == SYSTEM_STATE_SHUTDOWN_DELAY) {
	    	  if(DEBUG_MASTER_SWITCH) { Transmit_Debug_Data(); }
	      }

	      main_loop_timer = current_tick;
	  }

	  /* OLED update loop (500ms) */
	  if((current_tick - oled_update_timer) >= 500) {
		  OLED_Display_UpdateFromSystem(
		      DC_Sensor_Get_Voltage(),
		      DC_Sensor_Get_Current(),
		      AC_Sensor_Get_Voltage_RMS(),
		      AC_Sensor_Get_Current_RMS(),
		      POD_PWM_Get_Current_MI(),
		      system_running,
		      (system_mode == SYSTEM_MODE_CLOSED_LOOP) ? 1 : 0,
		      sensor_mode
		  );
	      oled_update_timer = current_tick;
	  }

  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 4;
  RCC_OscInitStruct.PLL.PLLN = 180;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 2;
  RCC_OscInitStruct.PLL.PLLR = 2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Activate the Over-Drive mode
  */
  if (HAL_PWREx_EnableOverDrive() != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_5) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */

/**
 * @brief Initialize the complete system
 */
void System_Initialize(void) {
	/* Initialize Button Handler */
	Button_Handler_Init();

    /* Initialize Relay Control */
    RELAY_OFF();		// Set PA12 HIGH = relay contacts open
    printf("Relay Control initialized: OPEN (safe state)\r\n");

    /* Initialize MLBC system */
    MLBC_Init();
    MLBC_Set_Soft_Start_Duration(SOFT_START_TIME_MS);
    MLBC_Set_Target_Duty_Cycle(manual_duty_cycle);
    MLBC_Set_Debug(ENABLE_MLBC_DEBUG);

	/* Initialize POD PWM system */
    POD_PWM_Init();
    POD_PWM_Set_Mode(POD_PWM_MODE_OPEN_LOOP);
    POD_PWM_Set_MI(manual_modulation_index);
    POD_PWM_Set_Debug(ENABLE_POD_PWM_DEBUG);


    /* Initialize DC Sensor */
    DC_Sensor_Init();
    DC_Sensor_Start();
    DC_Sensor_Set_Debug(ENABLE_DC_SENSOR_DEBUG);

    /* Initialize AC Sensor */
    AC_Sensor_Init();
    AC_Sensor_Register_Callback(AC_Sensor_Control_Callback);
    AC_Sensor_Set_Debug(ENABLE_AC_SENSOR_DEBUG);

    /* Initialize Fuzzy Controller */
    Fuzzy_Controller_Init();
    Fuzzy_Controller_Set_Debug(ENABLE_FUZZY_DEBUG);

    /* Initialize OLED */
    OLED_Display_Init();
    SH1106_Set_Debug(ENABLE_I2C_DEBUG);

    /* Initialize monitoring system */
    Monitoring_Init();

    /* Initialize timing variables */
    main_loop_timer = HAL_GetTick();
    fast_loop_timer = HAL_GetTick();
    oled_update_timer = HAL_GetTick();

    system_initialized = 1;
    system_state = SYSTEM_STATE_OFF;
    printf("System Initialization Complete\r\n");
}

/**
 * @brief Check DC input faults (called every 20ms when relay is closed)
 * Fault checks only run when relay is closed (STARTING or RUNNING)
 * During discharge (SHUTDOWN_DELAY), input is disconnected, not a fault
 */
void System_Check_Faults(void) {
    float dc_voltage = DC_Sensor_Get_Voltage();
    float dc_current = DC_Sensor_Get_Current();

    if (dc_current > DC_INPUT_OVERCURRENT_THRESHOLD) {
        System_Fault_Shutdown(SYSTEM_FAULT_OVERCURRENT);
        return;
    }

    if (dc_voltage > DC_INPUT_OVERVOLTAGE_THRESHOLD) {
        System_Fault_Shutdown(SYSTEM_FAULT_OVERVOLTAGE);
        return;
    }

    if (dc_voltage < DC_INPUT_UNDERVOLTAGE_THRESHOLD) {
        System_Fault_Shutdown(SYSTEM_FAULT_UNDERVOLTAGE);
        return;
    }

    if (MLBC_Get_Duty_Cycle() > MLBC_MAX_DUTY_CYCLE) {
        System_Fault_Shutdown(SYSTEM_FAULT_OVERDUTY);
        return;
    }
}

/**
 * @brief Initiate fault-triggered discharge shutdown
 * Same behavior as normal shutdown: relay off, keep switching to discharge caps.
 * @param fault: Fault code for tracking/debug
 */
void System_Fault_Shutdown(SystemFault_t fault) {
    system_fault_code = fault;

    RELAY_OFF();

    shutdown_start_time = HAL_GetTick();
    system_state = SYSTEM_STATE_SHUTDOWN_DELAY;

    if (monitoring_mode == MONITORING_MODE_OFF) {
        const char* fault_str;
        switch (fault) {
            case SYSTEM_FAULT_OVERCURRENT:  fault_str = "OVERCURRENT"; break;
            case SYSTEM_FAULT_OVERVOLTAGE:  fault_str = "OVERVOLTAGE"; break;
            case SYSTEM_FAULT_UNDERVOLTAGE: fault_str = "UNDERVOLTAGE"; break;
            case SYSTEM_FAULT_OVERDUTY:     fault_str = "OVERDUTY"; break;
            default:                        fault_str = "UNKNOWN"; break;
        }
        printf("\n>>> FAULT: %s — Initiating discharge shutdown <<<\r\n", fault_str);
    }
}

/**
 * @brief Handle all button inputs using non-blocking method
 */
void Handle_Button_Inputs(void) {
    /* Update button states (this is fast and non-blocking) */
    Button_Handler_Update();

    /* Handle start/stop button events */
    Handle_Start_Stop_Button_NonBlocking();

    /* Handle mode button events */
    Handle_Mode_Button_NonBlocking();
}

/**
 * @brief Handle start/stop button using non-blocking method
 */
void Handle_Start_Stop_Button_NonBlocking(void) {
    ButtonEvent_t event = Button_Handler_Get_Event(BUTTON_START_STOP);

    if (event != BUTTON_EVENT_PRESS) return;
    Button_Handler_Clear_Event(BUTTON_START_STOP);

    switch (system_state) {
        case SYSTEM_STATE_OFF:
            if (monitoring_mode == MONITORING_MODE_OFF) {
                printf("\n>>> SYSTEM STARTING <<<\r\n");
            }
            /* Clear any previous fault */
            system_fault_code = SYSTEM_FAULT_NONE;

            RELAY_ON();
            HAL_Delay(50);
            AC_Sensor_Start();
            MLBC_Start();

            system_state = SYSTEM_STATE_STARTING;
            system_running = 1;

            if (monitoring_mode == MONITORING_MODE_OFF) {
                printf("Relay closed | MLBC starting (5s ramp) | POD enabled\r\n\n");
            }
            break;

        case SYSTEM_STATE_STARTING:
        case SYSTEM_STATE_RUNNING:
            if (monitoring_mode == MONITORING_MODE_OFF) {
                printf("\n>>> SYSTEM STOPPING <<<\r\n");
            }

            RELAY_OFF();
            shutdown_start_time = HAL_GetTick();
            system_state = SYSTEM_STATE_SHUTDOWN_DELAY;

            if (monitoring_mode == MONITORING_MODE_OFF) {
                printf("Relay opened | Discharging all capacitors (5s)...\r\n\n");
            }
            break;

        case SYSTEM_STATE_SHUTDOWN_DELAY:
            if (monitoring_mode == MONITORING_MODE_OFF) {
                uint32_t elapsed = HAL_GetTick() - shutdown_start_time;
                uint32_t remaining = (SHUTDOWN_DISCHARGE_TIME_MS - elapsed) / 1000;
                if (monitoring_mode == MONITORING_MODE_OFF) {
                	printf("WARNING: Shutdown is still in progress (%lus remaining)\r\n", remaining);
                }
            }
            break;
    }
}

/**
 * @brief Handle mode button using non-blocking method
 */
void Handle_Mode_Button_NonBlocking(void) {
    ButtonEvent_t event = Button_Handler_Get_Event(BUTTON_MODE);

    if (event != BUTTON_EVENT_PRESS) return;
    Button_Handler_Clear_Event(BUTTON_MODE);

    if (monitoring_mode == MONITORING_MODE_OFF) {
        printf("Mode button pressed! Current mode: %s\r\n",
               (system_mode == SYSTEM_MODE_OPEN_LOOP) ? "OPEN_LOOP" : "CLOSED_LOOP");
    }

    if (system_mode == SYSTEM_MODE_OPEN_LOOP) {
        system_mode = SYSTEM_MODE_CLOSED_LOOP;
        Fuzzy_Controller_Enable(AC_Sensor_Get_Voltage_RMS());

        if (monitoring_mode == MONITORING_MODE_OFF) {
            printf("Switched to CLOSED LOOP mode\r\n");
        }
    } else {
        system_mode = SYSTEM_MODE_OPEN_LOOP;
        Fuzzy_Controller_Disable();
        manual_modulation_index = MANUAL_MODULATION_INDEX_DEFAULT;
        POD_PWM_Set_MI(manual_modulation_index);

        if (monitoring_mode == MONITORING_MODE_OFF) {
            printf("Switched to OPEN LOOP mode\r\n");
        }
    }
}

/**
 * @brief Handle calibration mode state machine
 * This mode is only used to gather snapshots of RAW ADC value
 * to make sure that the sensors are gathering a beautiful signal
 */
void Handle_Calibration_Mode(void) {
    switch(calib_state) {
        case CALIB_STATE_IDLE:
            /* Check if calibration mode activated via switch */
            if(sensor_mode == SENSOR_MODE_CALIBRATION && !calib_triggered) {
                printf("\n=== CALIBRATION SEQUENCE START ===\r\n");

                // 1. Switch to Calibration Mode (Starts AC Snapshot automatically)
                AC_Sensor_Set_Mode(AC_MODE_CALIBRATION);

                // 2. Switch DC Sensor to Calibration
                DC_Sensor_Set_Mode(DC_SENSOR_MODE_CALIBRATION);

                calib_state = CALIB_STATE_AC_COLLECTING;
                calib_timer = HAL_GetTick();
                calib_triggered = 1;
            }

            /* Reset trigger when switch returns to normal */
            if(sensor_mode == SENSOR_MODE_NORMAL && calib_triggered) {
                calib_triggered = 0;
            }
            break;

        case CALIB_STATE_AC_COLLECTING:
            if(ac_sensor.status == AC_STATUS_IDLE) {
                printf("AC: Collection complete (Buffer Full)\r\n");
                calib_state = CALIB_STATE_AC_TRANSMIT;
            }
            /* Timeout safety (500ms should be plenty for 5 cycles) */
            else if((HAL_GetTick() - calib_timer) >= 500) {
                printf("WARNING: AC collection timeout - Force Stop\r\n");
                AC_Sensor_Stop();
                calib_state = CALIB_STATE_AC_TRANSMIT;
            }
            break;

        case CALIB_STATE_AC_TRANSMIT:
            /* Transmit AC calibration data */
            AC_Transmit_Calibration_Data();

            calib_timer = HAL_GetTick();
            dc_sensor.calibration_counter = 0;
            calib_state = CALIB_STATE_DC_COLLECTING;
            break;

        case CALIB_STATE_DC_COLLECTING:
            /* Collect DC samples for 1 second */
            if((HAL_GetTick() - calib_timer) >= 1000) {
                printf("DC: Collection complete (1000ms)\r\n");
                calib_state = CALIB_STATE_DC_TRANSMIT;
            }
            break;

        case CALIB_STATE_DC_TRANSMIT:
            /* Transmit DC calibration data */
            DC_Transmit_Calibration_Data();

            calib_state = CALIB_STATE_COMPLETE;
            break;

        case CALIB_STATE_COMPLETE:
            {
                static uint8_t complete_msg_sent = 0;

                if (!complete_msg_sent) {
                    printf("=== CALIBRATION SEQUENCE COMPLETE ===\r\n");
                    printf("Turn OFF calibration switch to return to normal mode\r\n\n");
                    complete_msg_sent = 1;
                }

                /* Wait for user to turn off calibration switch */
                if(sensor_mode == SENSOR_MODE_NORMAL) {
                    // Return to Normal Control Mode
                    AC_Sensor_Set_Mode(AC_MODE_NORMAL);
                    DC_Sensor_Set_Mode(DC_SENSOR_MODE_NORMAL);

                    calib_state = CALIB_STATE_IDLE;
                    calib_triggered = 0;
                    complete_msg_sent = 0;
                }
            }
            break;
    }
}

/**
 * @brief Monitor shutdown timer and complete shutdown when discharge period ends
 * Called from main loop every cycle
 */
void Handle_Shutdown_Timer(void) {
    if(system_state != SYSTEM_STATE_SHUTDOWN_DELAY) {
        return;
    }

    uint32_t elapsed = HAL_GetTick() - shutdown_start_time;

    if(elapsed >= SHUTDOWN_DISCHARGE_TIME_MS) {
    	MLBC_Stop();
    	AC_Sensor_Stop();

    	system_state = SYSTEM_STATE_OFF;
    	system_running = 0;

    	if(monitoring_mode == MONITORING_MODE_OFF) {
    		if (system_fault_code != SYSTEM_FAULT_NONE) {
    			printf(">>> SYSTEM STOPPED (fault: 0x%02X) <<<\r\n", system_fault_code);
    		} else {
    			printf(">>> SYSTEM STOPPED <<<\r\n");
    		}
    	}

    } else {
    	static uint32_t last_print = 0;

    	/* Reset last_print at start of discharge to prevent stale state */
    	if (elapsed < MAIN_LOOP_INTERVAL_MS) {
    		last_print = 0;
    	}

    	if(monitoring_mode == MONITORING_MODE_OFF) {
            if((elapsed - last_print) >= 1000) {
                uint32_t remaining = (SHUTDOWN_DISCHARGE_TIME_MS - elapsed) / 1000;
                printf("Discharging... %lus remaining\r\n", remaining);
                last_print = elapsed;
            }
        }
    }
}

/**
 * @brief Update system modes based on DIP switches, not button
 */
void Update_System_Modes(void) {
    /* Read DIP switches (both active low) */
    uint8_t calibration_switch = !HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_5);
    uint8_t monitoring_switch = !HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_4);

    /* ===== MUTUAL EXCLUSION LOGIC ===== */

    if(monitoring_mode == MONITORING_MODE_ON) {
        /* Monitoring active - force calibration OFF, ignore calibration switch */
        sensor_mode = SENSOR_MODE_NORMAL;

        /* Allow monitoring to turn OFF */
        if(!monitoring_switch) {
            monitoring_mode = MONITORING_MODE_OFF;
            Monitoring_Reset();
        }
    }
    else if(sensor_mode == SENSOR_MODE_CALIBRATION) {
        /* Calibration active - ignore monitoring switch */

        /* Allow calibration to turn OFF */
        if(!calibration_switch) {
            sensor_mode = SENSOR_MODE_NORMAL;
            printf("Calibration  mode OFF\r\n");
        }
    }
    else {
        /* Neither active - check switches, monitoring takes priority */
        if(monitoring_switch) {
            monitoring_mode = MONITORING_MODE_ON;
            sensor_mode = SENSOR_MODE_NORMAL;
            Monitoring_Reset();
            printf("Monitoring mode ON\r\n");
        }
        else if(calibration_switch) {
            sensor_mode = SENSOR_MODE_CALIBRATION;
        }
    }
}

/**
 * @brief ADC Half-Transfer (HT) Callback
 * Triggered when DMA fills the FIRST HALF of the circular buffer.
 */
void HAL_ADC_ConvHalfCpltCallback(ADC_HandleTypeDef* hadc) {
    if(hadc->Instance == ADC1) { AC_Sensor_HalfTransfer_Callback(); }
}

/**
 * @brief ADC Transfer Complete (TC) Callback
 * Triggered when DMA fills the SECOND HALF of the circular buffer.
 */
void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef* hadc) {
    if(hadc->Instance == ADC1) { AC_Sensor_FullTransfer_Callback(); }
    else if(hadc->Instance == ADC2) { DC_Sensor_DMA_Complete_Callback(); }
}

/**
 * @brief UART DMA Transmit Complete Callback
 * Called by HAL from DMA1_Stream6 IRQ when USART2 TX DMA finishes.
 */
void HAL_UART_TxCpltCallback(UART_HandleTypeDef *huart) {
    if (huart->Instance == USART2) { Monitoring_DMA_TxComplete_Callback(); }
}

/**
 * @brief Transmit debug data from all subsystems
 */
void Transmit_Debug_Data(void) {
	if(ENABLE_AC_SENSOR_DEBUG) { AC_Sensor_Debug_Transmit(); }
	if(ENABLE_DC_SENSOR_DEBUG) { DC_Sensor_Debug_Transmit(); }
	if(ENABLE_POD_PWM_DEBUG) { POD_PWM_Debug_Transmit(); }
	if(ENABLE_MLBC_DEBUG) { MLBC_Debug_Transmit(); }
	if(ENABLE_FUZZY_DEBUG && system_mode == SYSTEM_MODE_CLOSED_LOOP) {
		Fuzzy_Controller_Debug_Transmit(); }
	if(ENABLE_I2C_DEBUG) { SH1106_I2C_Debug_Transmit(); }
}

/**
 * @brief Print current system status
 */
void Print_System_Status(void) {
    printf("=== SYSTEM STATUS ===\r\n");
    printf("System Mode: %s\r\n", (system_mode == SYSTEM_MODE_OPEN_LOOP) ? "OPEN LOOP" : "CLOSED LOOP");
    printf("Sensor Mode: %s\r\n", (sensor_mode == SENSOR_MODE_NORMAL) ? "NORMAL" : "CALIBRATION");
    printf("Manual MI: %.3f\r\n", manual_modulation_index);
    printf("Manual Duty Cycle: %.3f\r\n", manual_duty_cycle);

    printf("Control Architecture:\r\n");
    printf("  - POD PWM: TIM1 ISR @ 2.5kHz\r\n");
    printf("  - AC Sensor: TIM3 TRGO @ 10kHz\r\n");
    printf("  - PWM Method: %s\r\n", TRUE_PWM ? "Carrier-based" : "Staircase");
    printf("====================\r\n");
}
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
