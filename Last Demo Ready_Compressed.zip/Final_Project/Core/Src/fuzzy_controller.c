/**
 * @file fuzzy_controller.c
 * @brief Interval Type-2 Fuzzy Logic Controller Implementation
 * @author afuanandi & Claude
 * @date 2025
 *
 * RESPONSIBILITIES:
 * - State machine (DISABLED / NORMAL / FAULT)
 * - Error calculation (textbook: target - measured)
 * - Derivative filtering
 * - Parallel integral for zero steady-state error
 * - Output clamping [0, 2]
 * - Debug output
 *
 * CONTROL LAW:
 *   MI_final = clamp( MI_fuzzy(e, de) + Ki * integral(e * dt), 0, 2 )
 *
 * The fuzzy PD handles fast transients. The integral slowly eliminates
 * residual steady-state error that the PD structure cannot drive to zero.
 *
 * DECOUPLED:
 * - No sensor or plant dependencies
 * - Receives measured voltage as parameter
 * - Calls FuzzyInference() from fuzzy_init module
 * - Caller (main.c) decides when to invoke based on system state
 */

#include "fuzzy_controller.h"
#include "fuzzy_init.h"
#include <stdio.h>
#include <math.h>
#include <string.h>

/* Controller instance */
FuzzyController_t fuzzy_controller = {0};

/* Fuzzy system instance */
FuzzySystem fuzzy_system = {0};

/**
 * @brief Initialize fuzzy controller
 */
void Fuzzy_Controller_Init(void) {
    memset(&fuzzy_controller, 0, sizeof(FuzzyController_t));

    fuzzy_controller.state = FUZZY_STATE_DISABLED;
    fuzzy_controller.voltage_measured = FUZZY_TARGET_VOLTAGE;
    fuzzy_controller.fuzzy_output_final = 1.0f;
    fuzzy_controller.debug_enabled = 0;
    fuzzy_controller.ki_gain = FUZZY_KI_GAIN;

    if (InitializeFuzzySystem(&fuzzy_system) == 0) {
        fuzzy_controller.initialized = 1;
        printf("Fuzzy Controller: Interval Type-2 with Nie-Tan Type-Reduction\r\n");
        printf("Input: +/-%.0fV, Output: [0-2]\r\n", FUZZY_INPUT_RANGE_MAX);
        printf("Gains: Error=%.1f, dError=%.1f, Ki=%.4f\r\n",
               FUZZY_ERROR_GAIN, FUZZY_DERROR_GAIN, fuzzy_controller.ki_gain);
    } else {
        fuzzy_controller.state = FUZZY_STATE_FAULT;
        printf("ERROR: Fuzzy system initialization failed\r\n");
    }
}

/**
 * @brief Enable fuzzy controller
 * @param initial_voltage: Current AC voltage RMS for derivative initialization
 */
void Fuzzy_Controller_Enable(float initial_voltage) {
    if (!fuzzy_controller.initialized) return;

    fuzzy_controller.fuzzy_output_raw = MANUAL_MODULATION_INDEX_DEFAULT;
    fuzzy_controller.fuzzy_output_final = MANUAL_MODULATION_INDEX_DEFAULT;

    /* Initialize error state with actual measurement to prevent derivative spike */
    fuzzy_controller.voltage_measured = initial_voltage;
    float initial_error = FUZZY_TARGET_VOLTAGE - initial_voltage;
    fuzzy_controller.error = initial_error;
    fuzzy_controller.error_previous = initial_error;
    fuzzy_controller.error_derivative = 0.0f;
    fuzzy_controller.error_derivative_filtered = 0.0f;

    /* Reset integral - clean start, no history */
    fuzzy_controller.error_integral = 0.0f;
    fuzzy_controller.integral_contribution = 0.0f;

    fuzzy_controller.update_count = 0;
    fuzzy_controller.last_update_time = HAL_GetTick();
    fuzzy_controller.state = FUZZY_STATE_NORMAL;
    fuzzy_controller.new_data_available = 1;

    printf("Fuzzy: Enabled (MI=%.2f, Ki=%.4f)\r\n",
           MANUAL_MODULATION_INDEX_DEFAULT, fuzzy_controller.ki_gain);
}

/**
 * @brief Disable fuzzy controller
 */
void Fuzzy_Controller_Disable(void) {
    fuzzy_controller.state = FUZZY_STATE_DISABLED;
    fuzzy_controller.new_data_available = 0;

    /* Reset integral - don't carry stale state into next enable */
    fuzzy_controller.error_integral = 0.0f;
    fuzzy_controller.integral_contribution = 0.0f;

    printf("Fuzzy: Disabled\r\n");
}

/**
 * @brief Main fuzzy controller update
 * @param measured_voltage: Current AC voltage RMS from sensor
 * @return Modulation index [0, 2]
 */
float Fuzzy_Controller_Update(float measured_voltage) {
    uint32_t current_time = HAL_GetTick();

    if (fuzzy_controller.state != FUZZY_STATE_NORMAL) {
        return fuzzy_controller.fuzzy_output_final;
    }

    /* Store measurement */
    fuzzy_controller.voltage_measured = measured_voltage;

    /* Calculate error: textbook convention (positive = voltage too low) */
    fuzzy_controller.error = FUZZY_TARGET_VOLTAGE - measured_voltage;

    /* Re-initialize derivative on first execution after enable */
    if (fuzzy_controller.update_count == 0) {
        fuzzy_controller.error_previous = fuzzy_controller.error;
        fuzzy_controller.error_derivative = 0.0f;
        fuzzy_controller.error_derivative_filtered = 0.0f;
    }

    /* Calculate derivative */
    fuzzy_controller.error_derivative =
        fuzzy_controller.error - fuzzy_controller.error_previous;

    /* Filter derivative only (derivatives amplify noise) */
    fuzzy_controller.error_derivative_filtered =
        FUZZY_DERIV_FILTER_ALPHA * fuzzy_controller.error_derivative +
        (1.0f - FUZZY_DERIV_FILTER_ALPHA) * fuzzy_controller.error_derivative_filtered;

    fuzzy_controller.error_previous = fuzzy_controller.error;

    /* Scale inputs */
    fuzzy_controller.fuzzy_error = fuzzy_controller.error * FUZZY_ERROR_GAIN;
    fuzzy_controller.fuzzy_derror = fuzzy_controller.error_derivative_filtered * FUZZY_DERROR_GAIN;

    /* Safety check */
    if (fabsf(fuzzy_controller.fuzzy_error) > FUZZY_MAX_ERROR) {
        fuzzy_controller.state = FUZZY_STATE_FAULT;
        fuzzy_controller.new_data_available = 1;
        fuzzy_controller.error_integral = 0.0f;
        fuzzy_controller.integral_contribution = 0.0f;
        printf("FAULT: Error magnitude %.1fV exceeds limit %.1fV\r\n",
               fabsf(fuzzy_controller.fuzzy_error), FUZZY_MAX_ERROR);
        return fuzzy_controller.fuzzy_output_final;
    }

    /* ================================================================
     * Fuzzy PD inference
     * ================================================================ */
    fuzzy_controller.fuzzy_output_raw = FuzzyInference(
        &fuzzy_system,
        fuzzy_controller.fuzzy_error,
        fuzzy_controller.fuzzy_derror,
        &fuzzy_controller.y_upper,
        &fuzzy_controller.y_lower);

    /* ================================================================
     * Parallel integral term
     *
     * Accumulate: I(k) = I(k-1) + e(k) * dt
     * Anti-windup: clamp I to [INTEGRAL_MIN/Ki, INTEGRAL_MAX/Ki]
     * Combine: MI = MI_fuzzy + Ki * I
     * ================================================================ */
    fuzzy_controller.error_integral += fuzzy_controller.error * FUZZY_DT;

    /* Anti-windup: clamp the integral accumulator */
    if (fuzzy_controller.ki_gain > 0.0f) {
        float integral_limit_upper = FUZZY_INTEGRAL_MAX / fuzzy_controller.ki_gain;
        float integral_limit_lower = FUZZY_INTEGRAL_MIN / fuzzy_controller.ki_gain;

        if (fuzzy_controller.error_integral > integral_limit_upper)
            fuzzy_controller.error_integral = integral_limit_upper;
        if (fuzzy_controller.error_integral < integral_limit_lower)
            fuzzy_controller.error_integral = integral_limit_lower;
    }

    fuzzy_controller.integral_contribution =
        fuzzy_controller.ki_gain * fuzzy_controller.error_integral;

    /* Combine fuzzy PD + integral */
    fuzzy_controller.fuzzy_output_final =
        fuzzy_controller.fuzzy_output_raw + fuzzy_controller.integral_contribution;

    /* Clamp to valid range [0, 2] */
    if (fuzzy_controller.fuzzy_output_final < 0.0f) {
        fuzzy_controller.fuzzy_output_final = 0.0f;
    }
    if (fuzzy_controller.fuzzy_output_final > 2.0f) {
        fuzzy_controller.fuzzy_output_final = 2.0f;
    }

    fuzzy_controller.update_count++;
    fuzzy_controller.last_update_time = current_time;
    fuzzy_controller.new_data_available = 1;

    return fuzzy_controller.fuzzy_output_final;
}

/* ========================================================================
 * ACCESSOR FUNCTIONS
 * ======================================================================== */

FuzzyState_t Fuzzy_Controller_Get_State(void) {
    return fuzzy_controller.state;
}

uint8_t Fuzzy_Controller_Is_Active(void) {
    return (fuzzy_controller.state == FUZZY_STATE_NORMAL);
}

float Fuzzy_Controller_Get_Output(void) {
    return fuzzy_controller.fuzzy_output_final;
}

float Fuzzy_Controller_Get_Error(void) {
    return fuzzy_controller.error;
}

float Fuzzy_Controller_Get_Error_Derivative(void) {
    return fuzzy_controller.error_derivative_filtered;
}

float Fuzzy_Controller_Get_Target_Voltage(void) {
    return FUZZY_TARGET_VOLTAGE;
}

void Fuzzy_Controller_Set_Debug(uint8_t enable) {
    fuzzy_controller.debug_enabled = enable;
    printf("Fuzzy Controller debug %s\r\n", enable ? "enabled" : "disabled");
}

/**
 * @brief Set integral gain at runtime
 * @param ki: New integral gain (0 to disable integral action)
 */
void Fuzzy_Controller_Set_Ki(float ki) {
    fuzzy_controller.ki_gain = ki;
    fuzzy_controller.error_integral = 0.0f;
    fuzzy_controller.integral_contribution = 0.0f;
    printf("Fuzzy: Ki=%.5f%s\r\n", ki, (ki == 0.0f) ? " (integral disabled)" : "");
}

void Fuzzy_Controller_Debug_Transmit(void) {
    if (fuzzy_controller.new_data_available &&
        monitoring_mode == MONITORING_MODE_OFF) {

        printf("FUZZY_IT2,%.1f,%.3f,%.3f,%.3f,%.3f,%.3f,%.3f,%.3f,%.3f,%.3f,%.4f,%d\r\n",
               fuzzy_controller.voltage_measured,
               fuzzy_controller.error,
               fuzzy_controller.error_derivative,
               fuzzy_controller.error_derivative_filtered,
               fuzzy_controller.fuzzy_error,
               fuzzy_controller.fuzzy_derror,
               fuzzy_controller.y_upper,
               fuzzy_controller.y_lower,
               fuzzy_controller.fuzzy_output_raw,
               fuzzy_controller.fuzzy_output_final,
               fuzzy_controller.integral_contribution,
               fuzzy_controller.state);
    }

    fuzzy_controller.new_data_available = 0;
}

void Fuzzy_Controller_Get_Statistics(char* buffer, size_t buffer_size) {
    snprintf(buffer, buffer_size,
             "Fuzzy: State=%d, Updates=%lu, MI=%.3f, Err=%.2fV, Int=%.4f",
             fuzzy_controller.state,
             fuzzy_controller.update_count,
             fuzzy_controller.fuzzy_output_final,
             fuzzy_controller.error,
             fuzzy_controller.integral_contribution);
}
