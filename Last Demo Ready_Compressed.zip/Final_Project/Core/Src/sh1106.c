/**
 * @file sh1106.c
 * @brief Non-blocking SH1106 OLED driver implementation
 * @author afuanandi & Claude
 * @date 2025
 */

#include "sh1106.h"
#include "i2c.h"
#include <string.h>
#include <stdlib.h>
#include <stdio.h>

/* ==================== GLOBAL INSTANCE ==================== */

SH1106_Controller_t sh1106;

/* ==================== FONT DATA ==================== */

/* Basic 5x8 font (ASCII 32-127) */
static const uint8_t font5x8[][5] = {
    {0x00, 0x00, 0x00, 0x00, 0x00}, /* 32 Space */
    {0x00, 0x00, 0x5F, 0x00, 0x00}, /* 33 ! */
    {0x00, 0x07, 0x00, 0x07, 0x00}, /* 34 " */
    {0x14, 0x7F, 0x14, 0x7F, 0x14}, /* 35 # */
    {0x24, 0x2A, 0x7F, 0x2A, 0x12}, /* 36 $ */
    {0x23, 0x13, 0x08, 0x64, 0x62}, /* 37 % */
    {0x36, 0x49, 0x55, 0x22, 0x50}, /* 38 & */
    {0x00, 0x05, 0x03, 0x00, 0x00}, /* 39 ' */
    {0x00, 0x1C, 0x22, 0x41, 0x00}, /* 40 ( */
    {0x00, 0x41, 0x22, 0x1C, 0x00}, /* 41 ) */
    {0x14, 0x08, 0x3E, 0x08, 0x14}, /* 42 * */
    {0x08, 0x08, 0x3E, 0x08, 0x08}, /* 43 + */
    {0x00, 0x50, 0x30, 0x00, 0x00}, /* 44 , */
    {0x08, 0x08, 0x08, 0x08, 0x08}, /* 45 - */
    {0x00, 0x60, 0x60, 0x00, 0x00}, /* 46 . */
    {0x20, 0x10, 0x08, 0x04, 0x02}, /* 47 / */
    {0x3E, 0x51, 0x49, 0x45, 0x3E}, /* 48 0 */
    {0x00, 0x42, 0x7F, 0x40, 0x00}, /* 49 1 */
    {0x42, 0x61, 0x51, 0x49, 0x46}, /* 50 2 */
    {0x21, 0x41, 0x45, 0x4B, 0x31}, /* 51 3 */
    {0x18, 0x14, 0x12, 0x7F, 0x10}, /* 52 4 */
    {0x27, 0x45, 0x45, 0x45, 0x39}, /* 53 5 */
    {0x3C, 0x4A, 0x49, 0x49, 0x30}, /* 54 6 */
    {0x01, 0x71, 0x09, 0x05, 0x03}, /* 55 7 */
    {0x36, 0x49, 0x49, 0x49, 0x36}, /* 56 8 */
    {0x06, 0x49, 0x49, 0x29, 0x1E}, /* 57 9 */
    {0x00, 0x36, 0x36, 0x00, 0x00}, /* 58 : */
    {0x00, 0x56, 0x36, 0x00, 0x00}, /* 59 ; */
    {0x08, 0x14, 0x22, 0x41, 0x00}, /* 60 < */
    {0x14, 0x14, 0x14, 0x14, 0x14}, /* 61 = */
    {0x00, 0x41, 0x22, 0x14, 0x08}, /* 62 > */
    {0x02, 0x01, 0x51, 0x09, 0x06}, /* 63 ? */
    {0x32, 0x49, 0x79, 0x41, 0x3E}, /* 64 @ */
    {0x7E, 0x11, 0x11, 0x11, 0x7E}, /* 65 A */
    {0x7F, 0x49, 0x49, 0x49, 0x36}, /* 66 B */
    {0x3E, 0x41, 0x41, 0x41, 0x22}, /* 67 C */
    {0x7F, 0x41, 0x41, 0x22, 0x1C}, /* 68 D */
    {0x7F, 0x49, 0x49, 0x49, 0x41}, /* 69 E */
    {0x7F, 0x09, 0x09, 0x09, 0x01}, /* 70 F */
    {0x3E, 0x41, 0x49, 0x49, 0x7A}, /* 71 G */
    {0x7F, 0x08, 0x08, 0x08, 0x7F}, /* 72 H */
    {0x00, 0x41, 0x7F, 0x41, 0x00}, /* 73 I */
    {0x20, 0x40, 0x41, 0x3F, 0x01}, /* 74 J */
    {0x7F, 0x08, 0x14, 0x22, 0x41}, /* 75 K */
    {0x7F, 0x40, 0x40, 0x40, 0x40}, /* 76 L */
    {0x7F, 0x02, 0x0C, 0x02, 0x7F}, /* 77 M */
    {0x7F, 0x04, 0x08, 0x10, 0x7F}, /* 78 N */
    {0x3E, 0x41, 0x41, 0x41, 0x3E}, /* 79 O */
    {0x7F, 0x09, 0x09, 0x09, 0x06}, /* 80 P */
    {0x3E, 0x41, 0x51, 0x21, 0x5E}, /* 81 Q */
    {0x7F, 0x09, 0x19, 0x29, 0x46}, /* 82 R */
    {0x46, 0x49, 0x49, 0x49, 0x31}, /* 83 S */
    {0x01, 0x01, 0x7F, 0x01, 0x01}, /* 84 T */
    {0x3F, 0x40, 0x40, 0x40, 0x3F}, /* 85 U */
    {0x1F, 0x20, 0x40, 0x20, 0x1F}, /* 86 V */
    {0x3F, 0x40, 0x38, 0x40, 0x3F}, /* 87 W */
    {0x63, 0x14, 0x08, 0x14, 0x63}, /* 88 X */
    {0x07, 0x08, 0x70, 0x08, 0x07}, /* 89 Y */
    {0x61, 0x51, 0x49, 0x45, 0x43}, /* 90 Z */
    {0x00, 0x7F, 0x41, 0x41, 0x00}, /* 91 [ */
    {0x02, 0x04, 0x08, 0x10, 0x20}, /* 92 \ */
    {0x00, 0x41, 0x41, 0x7F, 0x00}, /* 93 ] */
    {0x04, 0x02, 0x01, 0x02, 0x04}, /* 94 ^ */
    {0x40, 0x40, 0x40, 0x40, 0x40}, /* 95 _ */
    {0x00, 0x01, 0x02, 0x04, 0x00}, /* 96 ` */
    {0x20, 0x54, 0x54, 0x54, 0x78}, /* 97 a */
    {0x7F, 0x48, 0x44, 0x44, 0x38}, /* 98 b */
    {0x38, 0x44, 0x44, 0x44, 0x20}, /* 99 c */
    {0x38, 0x44, 0x44, 0x48, 0x7F}, /* 100 d */
    {0x38, 0x54, 0x54, 0x54, 0x18}, /* 101 e */
    {0x08, 0x7E, 0x09, 0x01, 0x02}, /* 102 f */
    {0x0C, 0x52, 0x52, 0x52, 0x3E}, /* 103 g */
    {0x7F, 0x08, 0x04, 0x04, 0x78}, /* 104 h */
    {0x00, 0x44, 0x7D, 0x40, 0x00}, /* 105 i */
    {0x20, 0x40, 0x44, 0x3D, 0x00}, /* 106 j */
    {0x7F, 0x10, 0x28, 0x44, 0x00}, /* 107 k */
    {0x00, 0x41, 0x7F, 0x40, 0x00}, /* 108 l */
    {0x7C, 0x04, 0x18, 0x04, 0x78}, /* 109 m */
    {0x7C, 0x08, 0x04, 0x04, 0x78}, /* 110 n */
    {0x38, 0x44, 0x44, 0x44, 0x38}, /* 111 o */
    {0x7C, 0x14, 0x14, 0x14, 0x08}, /* 112 p */
    {0x08, 0x14, 0x14, 0x18, 0x7C}, /* 113 q */
    {0x7C, 0x08, 0x04, 0x04, 0x08}, /* 114 r */
    {0x48, 0x54, 0x54, 0x54, 0x20}, /* 115 s */
    {0x04, 0x3F, 0x44, 0x40, 0x20}, /* 116 t */
    {0x3C, 0x40, 0x40, 0x20, 0x7C}, /* 117 u */
    {0x1C, 0x20, 0x40, 0x20, 0x1C}, /* 118 v */
    {0x3C, 0x40, 0x30, 0x40, 0x3C}, /* 119 w */
    {0x44, 0x28, 0x10, 0x28, 0x44}, /* 120 x */
    {0x0C, 0x50, 0x50, 0x50, 0x3C}, /* 121 y */
    {0x44, 0x64, 0x54, 0x4C, 0x44}, /* 122 z */
    {0x00, 0x08, 0x36, 0x41, 0x00}, /* 123 { */
    {0x00, 0x00, 0x7F, 0x00, 0x00}, /* 124 | */
    {0x00, 0x41, 0x36, 0x08, 0x00}, /* 125 } */
    {0x10, 0x08, 0x08, 0x10, 0x08}, /* 126 ~ */
    {0x78, 0x46, 0x41, 0x46, 0x78}  /* 127 DEL */
};

/* ==================== INTERNAL FUNCTIONS ==================== */

/**
 * @brief Send a single command byte to display
 * @return HAL_OK on success, error otherwise
 */
static HAL_StatusTypeDef SH1106_SendCommand(uint8_t cmd)
{
    uint8_t data[2] = {0x00, cmd};  /* 0x00 = command mode */
    return HAL_I2C_Master_Transmit(&hi2c1, SH1106_I2C_ADDR << 1,
                                   data, 2, SH1106_I2C_TIMEOUT_MS);
}

/**
 * @brief Send data buffer to display
 * @return HAL_OK on success, error otherwise
 */
static HAL_StatusTypeDef SH1106_SendData(uint8_t* data, uint16_t size)
{
    return HAL_I2C_Master_Transmit(&hi2c1, SH1106_I2C_ADDR << 1,
                                   data, size, SH1106_I2C_TIMEOUT_MS);
}

/**
 * @brief I2C bus recovery with GPIO bit-banging
 *        Toggles SCL to release stuck slave holding SDA low
 */
static void SH1106_I2C_Recovery(void)
{
    sh1106.recoveries_attempted++;

    if (sh1106.debug_enabled) {
        printf("OLED: I2C recovery attempt #%lu\r\n", sh1106.recoveries_attempted);
    }

    GPIO_InitTypeDef GPIO_InitStruct = {0};

    /* 1. Disable I2C peripheral */
    hi2c1.Instance->CR1 &= ~I2C_CR1_PE;

    /* 2. Configure SCL and SDA as GPIO outputs (open-drain, no pull - external pull-ups) */
    GPIO_InitStruct.Pin = GPIO_PIN_6 | GPIO_PIN_7;
    GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_OD;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
    HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

    /* 3. Set both lines high */
    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_6, GPIO_PIN_SET);  /* SCL high */
    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_7, GPIO_PIN_SET);  /* SDA high */

    /* Short delay */
    for (volatile int i = 0; i < 100; i++);

    /* 4. Toggle SCL up to 16 times to release stuck slave */
    for (int i = 0; i < 16; i++) {
        /* Check if SDA is released (high) */
        if (HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_7) == GPIO_PIN_SET) {
            break;  /* Bus is free */
        }

        /* Toggle SCL */
        HAL_GPIO_WritePin(GPIOB, GPIO_PIN_6, GPIO_PIN_RESET);
        for (volatile int d = 0; d < 50; d++);
        HAL_GPIO_WritePin(GPIOB, GPIO_PIN_6, GPIO_PIN_SET);
        for (volatile int d = 0; d < 50; d++);
    }

    /* 5. Generate STOP condition manually */
    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_7, GPIO_PIN_RESET);  /* SDA low */
    for (volatile int d = 0; d < 50; d++);
    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_6, GPIO_PIN_SET);    /* SCL high */
    for (volatile int d = 0; d < 50; d++);
    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_7, GPIO_PIN_SET);    /* SDA high (STOP) */
    for (volatile int d = 0; d < 50; d++);

    /* 6. Reconfigure pins for I2C alternate function (match i2c.c settings) */
    GPIO_InitStruct.Pin = GPIO_PIN_6 | GPIO_PIN_7;
    GPIO_InitStruct.Mode = GPIO_MODE_AF_OD;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
    GPIO_InitStruct.Alternate = GPIO_AF4_I2C1;
    HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

    /* 7. Re-initialize I2C peripheral (this reconfigures all registers) */
    if (HAL_I2C_Init(&hi2c1) != HAL_OK) {
        if (sh1106.debug_enabled) {
            printf("OLED: HAL_I2C_Init failed\r\n");
        }
        return;
    }

    /* 8. Test if device responds */
    HAL_StatusTypeDef result = HAL_I2C_IsDeviceReady(&hi2c1, SH1106_I2C_ADDR << 1,
                                                      3, SH1106_I2C_TIMEOUT_MS);

    if (result == HAL_OK) {
        sh1106.recoveries_successful++;
        sh1106.consecutive_failures = 0;
        if (sh1106.debug_enabled) {
            printf("OLED: Recovery successful\r\n");
        }
    } else {
        if (sh1106.debug_enabled) {
            printf("OLED: Recovery failed, device not responding\r\n");
        }
    }
}

/**
 * @brief Set page address for writing
 */
static HAL_StatusTypeDef SH1106_SetPageAddress(uint8_t page)
{
    HAL_StatusTypeDef result;

    /* Page address */
    result = SH1106_SendCommand(SH1106_SETPAGEADDR | page);
    if (result != HAL_OK) return result;

    /* Column address - SH1106 has 132 columns, display starts at column 2 */
    result = SH1106_SendCommand(SH1106_SETLOWCOLUMN | 2);
    if (result != HAL_OK) return result;

    result = SH1106_SendCommand(SH1106_SETHIGHCOLUMN | 0);

    return result;
}

/**
 * @brief Prepare chunk data for transmission
 * @return Number of data bytes (not including control byte)
 */
static uint8_t SH1106_PrepareChunk(uint8_t page, uint8_t start_col, uint8_t max_size)
{
    uint8_t remaining = SH1106_WIDTH - start_col;
    uint8_t chunk_size = (remaining > max_size) ? max_size : remaining;

    if (chunk_size == 0) {
        return 0;
    }

    /* First byte is data mode control byte */
    sh1106.tx_buffer[0] = 0x40;

    /* Copy display buffer data */
    for (uint8_t i = 0; i < chunk_size; i++) {
        sh1106.tx_buffer[i + 1] = sh1106.buffer[page][start_col + i];
    }

    return chunk_size;
}

/* ==================== PUBLIC FUNCTIONS ==================== */

void SH1106_Init(void)
{
    /* Clear controller structure */
    memset(&sh1106, 0, sizeof(SH1106_Controller_t));

    /* Wait for display power-up */
    HAL_Delay(100);

    /* Send initialization sequence */
    SH1106_SendCommand(SH1106_DISPLAYOFF);
    SH1106_SendCommand(SH1106_SETDISPLAYCLOCKDIV);
    SH1106_SendCommand(0x80);
    SH1106_SendCommand(SH1106_SETMULTIPLEX);
    SH1106_SendCommand(0x3F);
    SH1106_SendCommand(SH1106_SETDISPLAYOFFSET);
    SH1106_SendCommand(0x00);
    SH1106_SendCommand(SH1106_SETSTARTLINE | 0x00);
    SH1106_SendCommand(SH1106_CHARGEPUMP);
    SH1106_SendCommand(0x14);
    SH1106_SendCommand(SH1106_MEMORYMODE);
    SH1106_SendCommand(0x00);
    SH1106_SendCommand(SH1106_SEGREMAP | 0x01);
    SH1106_SendCommand(SH1106_COMSCANDEC);
    SH1106_SendCommand(SH1106_SETCOMPINS);
    SH1106_SendCommand(0x12);
    SH1106_SendCommand(SH1106_SETCONTRAST);
    SH1106_SendCommand(0xCF);
    SH1106_SendCommand(SH1106_SETPRECHARGE);
    SH1106_SendCommand(0xF1);
    SH1106_SendCommand(SH1106_SETVCOMDETECT);
    SH1106_SendCommand(0x40);
    SH1106_SendCommand(SH1106_DISPLAYALLON_RESUME);
    SH1106_SendCommand(SH1106_NORMALDISPLAY);
    SH1106_SendCommand(SH1106_DISPLAYON);

    /* Clear buffer */
    SH1106_Clear();

    /* Mark initialized */
    sh1106.initialized = 1;
    sh1106.state = DISPLAY_STATE_IDLE;

    printf("SH1106 initialized - Non-blocking (no DMA)\r\n");
}

void SH1106_Update(void)
{
    if (!sh1106.initialized) {
        return;
    }

    HAL_StatusTypeDef result;

    switch (sh1106.state) {

        case DISPLAY_STATE_IDLE:
            /* Check if update requested */
            if (sh1106.update_pending) {
                sh1106.state = DISPLAY_STATE_PAGE_SETUP;
                sh1106.current_page = 0;
                sh1106.current_column = 0;
                sh1106.retry_count = 0;
            }
            break;

        case DISPLAY_STATE_PAGE_SETUP:
            /* Set page address */
            result = SH1106_SetPageAddress(sh1106.current_page);

            if (result == HAL_OK) {
                sh1106.state = DISPLAY_STATE_PAGE_DATA;
                sh1106.current_column = 0;
                sh1106.retry_count = 0;
            } else {
                /* Page setup failed */
                sh1106.i2c_errors++;
                sh1106.consecutive_failures++;
                sh1106.retry_count++;

                if (sh1106.retry_count >= SH1106_MAX_RETRIES) {
                    /* Skip this page, try next */
                    sh1106.state = DISPLAY_STATE_NEXT_PAGE;
                    sh1106.retry_count = 0;
                }

                /* Check if recovery needed */
                if (sh1106.consecutive_failures >= SH1106_MAX_CONSECUTIVE_FAILURES) {
                    sh1106.state = DISPLAY_STATE_RECOVERY;
                }
            }
            break;

        case DISPLAY_STATE_PAGE_DATA:
            /* Prepare and send one chunk */
            {
                uint8_t chunk_size = SH1106_PrepareChunk(sh1106.current_page,
                                                          sh1106.current_column,
                                                          SH1106_CHUNK_SIZE);

                if (chunk_size == 0) {
                    /* Page complete */
                    sh1106.state = DISPLAY_STATE_NEXT_PAGE;
                    break;
                }

                /* Send chunk (+1 for control byte) */
                result = SH1106_SendData(sh1106.tx_buffer, chunk_size + 1);

                if (result == HAL_OK) {
                    /* Success - advance column */
                    sh1106.current_column += chunk_size;
                    sh1106.retry_count = 0;
                    sh1106.consecutive_failures = 0;

                    if (sh1106.current_column >= SH1106_WIDTH) {
                        sh1106.state = DISPLAY_STATE_NEXT_PAGE;
                    }
                } else {
                    /* Failure */
                    sh1106.i2c_errors++;
                    sh1106.consecutive_failures++;
                    sh1106.retry_count++;

                    if (sh1106.retry_count >= SH1106_MAX_RETRIES) {
                        /* Skip rest of page */
                        sh1106.state = DISPLAY_STATE_NEXT_PAGE;
                        sh1106.retry_count = 0;
                    }

                    /* Check if recovery needed */
                    if (sh1106.consecutive_failures >= SH1106_MAX_CONSECUTIVE_FAILURES) {
                        sh1106.state = DISPLAY_STATE_RECOVERY;
                    }
                }
            }
            break;

        case DISPLAY_STATE_NEXT_PAGE:
            sh1106.current_page++;

            if (sh1106.current_page >= SH1106_PAGES) {
                /* All pages done */
                sh1106.state = DISPLAY_STATE_COMPLETE;
            } else {
                /* Setup next page */
                sh1106.state = DISPLAY_STATE_PAGE_SETUP;
                sh1106.current_column = 0;
                sh1106.retry_count = 0;
            }
            break;

        case DISPLAY_STATE_COMPLETE:
            sh1106.update_pending = 0;
            sh1106.successful_updates++;
            sh1106.state = DISPLAY_STATE_IDLE;

            if (sh1106.debug_enabled) {
                printf("OLED: Update complete (ok=%lu, err=%lu)\r\n",
                       sh1106.successful_updates, sh1106.i2c_errors);
            }
            break;

        case DISPLAY_STATE_RECOVERY:
            /* Perform I2C recovery */
            SH1106_I2C_Recovery();

            /* Enter cooldown */
            sh1106.state = DISPLAY_STATE_RECOVERY_COOLDOWN;
            sh1106.recovery_start_time = HAL_GetTick();
            sh1106.update_pending = 0;
            sh1106.failed_updates++;
            break;

        case DISPLAY_STATE_RECOVERY_COOLDOWN:
            /* Wait before allowing new updates */
            if ((HAL_GetTick() - sh1106.recovery_start_time) >= SH1106_RECOVERY_COOLDOWN_MS) {
                sh1106.state = DISPLAY_STATE_IDLE;
                sh1106.consecutive_failures = 0;

                if (sh1106.debug_enabled) {
                    printf("OLED: Recovery cooldown complete\r\n");
                }
            }
            break;
    }
}

void SH1106_RequestUpdate(void)
{
    if (!sh1106.initialized) {
        return;
    }

    sh1106.update_pending = 1;
}

uint8_t SH1106_IsUpdating(void)
{
    return (sh1106.state != DISPLAY_STATE_IDLE &&
            sh1106.state != DISPLAY_STATE_RECOVERY_COOLDOWN);
}

void SH1106_Clear(void)
{
    memset(sh1106.buffer, 0, sizeof(sh1106.buffer));
}

void SH1106_DrawPixel(uint8_t x, uint8_t y, bool color)
{
    if (x >= SH1106_WIDTH || y >= SH1106_HEIGHT) {
        return;
    }

    if (color) {
        sh1106.buffer[y / 8][x] |= (1 << (y % 8));
    } else {
        sh1106.buffer[y / 8][x] &= ~(1 << (y % 8));
    }
}

void SH1106_DrawChar(uint8_t x, uint8_t y, char c)
{
    if (c < 32 || c > 127) {
        return;
    }

    for (uint8_t i = 0; i < 5; i++) {
        uint8_t column = font5x8[c - 32][i];
        for (uint8_t j = 0; j < 8; j++) {
            if (column & (1 << j)) {
                SH1106_DrawPixel(x + i, y + j, true);
            }
        }
    }
}

void SH1106_DrawString(uint8_t x, uint8_t y, const char* str)
{
    while (*str) {
        SH1106_DrawChar(x, y, *str);
        x += 6;  /* 5 pixels + 1 space */
        str++;
    }
}

void SH1106_DrawLine(uint8_t x0, uint8_t y0, uint8_t x1, uint8_t y1)
{
    int16_t dx = abs(x1 - x0);
    int16_t dy = abs(y1 - y0);
    int16_t sx = (x0 < x1) ? 1 : -1;
    int16_t sy = (y0 < y1) ? 1 : -1;
    int16_t err = dx - dy;

    while (1) {
        SH1106_DrawPixel(x0, y0, true);

        if (x0 == x1 && y0 == y1) break;

        int16_t e2 = 2 * err;
        if (e2 > -dy) {
            err -= dy;
            x0 += sx;
        }
        if (e2 < dx) {
            err += dx;
            y0 += sy;
        }
    }
}

void SH1106_DrawRect(uint8_t x, uint8_t y, uint8_t width, uint8_t height)
{
    SH1106_DrawLine(x, y, x + width - 1, y);
    SH1106_DrawLine(x, y + height - 1, x + width - 1, y + height - 1);
    SH1106_DrawLine(x, y, x, y + height - 1);
    SH1106_DrawLine(x + width - 1, y, x + width - 1, y + height - 1);
}

void SH1106_FillRect(uint8_t x, uint8_t y, uint8_t width, uint8_t height)
{
    for (uint8_t i = x; i < x + width && i < SH1106_WIDTH; i++) {
        for (uint8_t j = y; j < y + height && j < SH1106_HEIGHT; j++) {
            SH1106_DrawPixel(i, j, true);
        }
    }
}

void SH1106_ClearRect(uint8_t x, uint8_t y, uint8_t width, uint8_t height)
{
    for (uint8_t i = x; i < x + width && i < SH1106_WIDTH; i++) {
        for (uint8_t j = y; j < y + height && j < SH1106_HEIGHT; j++) {
            SH1106_DrawPixel(i, j, false);
        }
    }
}

void SH1106_SetContrast(uint8_t contrast)
{
    SH1106_SendCommand(SH1106_SETCONTRAST);
    SH1106_SendCommand(contrast);
}

void SH1106_DisplayOn(void)
{
    SH1106_SendCommand(SH1106_DISPLAYON);
}

void SH1106_DisplayOff(void)
{
    SH1106_SendCommand(SH1106_DISPLAYOFF);
}

void SH1106_Set_Debug(uint8_t enable)
{
    sh1106.debug_enabled = enable;
    printf("OLED debug %s\r\n", enable ? "enabled" : "disabled");
}

void SH1106_GetStats(char* buffer, size_t size)
{
    snprintf(buffer, size,
             "OLED: State=%d, OK=%lu, Fail=%lu, I2C_Err=%lu, Recov=%lu/%lu",
             sh1106.state,
             sh1106.successful_updates,
             sh1106.failed_updates,
             sh1106.i2c_errors,
             sh1106.recoveries_successful,
             sh1106.recoveries_attempted);
}

void SH1106_Test(void)
{
    SH1106_Clear();
    SH1106_DrawString(10, 10, "POWER CONVERTER");
    SH1106_DrawString(10, 20, "STM32F446RE");
    SH1106_DrawString(10, 30, "SH1106 OLED");
    SH1106_DrawString(10, 40, "No DMA - Simple");
    SH1106_RequestUpdate();
}

void SH1106_I2C_Debug_Transmit(void)
{
    if (!sh1106.debug_enabled || monitoring_mode == MONITORING_MODE_ON) {
        return;
    }

    static uint32_t last_debug_time = 0;
    uint32_t now = HAL_GetTick();

    /* Print every 1 second */
    if ((now - last_debug_time) < 1000) {
        return;
    }
    last_debug_time = now;

    printf("I2C: State=%d, Err=0x%lX, SR1=0x%04lX, SR2=0x%04lX, Lock=%d | "
           "OLED: state=%d, page=%d, col=%d, pend=%d, ok=%lu, fail=%lu, err=%lu\r\n",
           (int)hi2c1.State,
           hi2c1.ErrorCode,
           (uint32_t)(hi2c1.Instance->SR1),
           (uint32_t)(hi2c1.Instance->SR2),
           (int)hi2c1.Lock,
           (int)sh1106.state,
           sh1106.current_page,
           sh1106.current_column,
           sh1106.update_pending,
           sh1106.successful_updates,
           sh1106.failed_updates,
           sh1106.i2c_errors);
}
