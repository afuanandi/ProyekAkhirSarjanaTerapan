/**
 * @file fuzzy_init.c
 * @brief IT2 Fuzzy System Initialization and Inference Engine
 * @author afuanandi & Claude
 * @date 2025
 *
 * This module owns all fuzzy system data and computation:
 * - Static storage for MFs and rules (no malloc)
 * - UMF/LMF initialization with configurable FOU pattern
 * - IT2 inference: fuzzification, rule evaluation, Nie-Tan type-reduction
 *
 * ERROR CONVENTION (textbook standard):
 * - error = target - measured
 * - Positive error (PB) = voltage too low  -> increase MI
 * - Negative error (NB) = voltage too high -> decrease MI
 */

#include "fuzzy_init.h"
#include <string.h>
#include <stdio.h>
#include <math.h>

/* ========================================================================
 * FOU PATTERN CONFIGURATION
 *
 * FOU_PATTERN 0 - Wide FOU at edges (NB/PB), narrow at center (Z)
 *   a_lower = b - (b - a) * k
 *   c_lower = b + (c - b) * k
 *   k=0.2  -> LMF is 20% of UMF width -> 80% FOU (high uncertainty)
 *   k=0.95 -> LMF is 95% of UMF width ->  5% FOU (low uncertainty)
 *   Interpretation: uncertain far from setpoint, certain near setpoint
 *
 * FOU_PATTERN 1 - Wide FOU at center (Z), narrow at edges (NB/PB)
 *   a_lower = b - (b - a) * (1 - k)
 *   c_lower = b + (c - b) * (1 - k)
 *   k=0.2  -> LMF is 80% of UMF width -> 20% FOU (low uncertainty)
 *   k=0.95 -> LMF is  5% of UMF width -> 95% FOU (high uncertainty)
 *   Interpretation: certain far from setpoint, uncertain near setpoint
 * ======================================================================== */
#define FOU_PATTERN 1

/* Common LMF peak height */
#define LMF_HEIGHT 0.5f

/* ========================================================================
 * STATIC STORAGE - replaces malloc, visible in linker .bss section
 * Total: 7*24 + 7*24 + 7*24 + 49*8 = 896 bytes
 * ======================================================================== */
static TriangularMF input1_mfs[7];
static TriangularMF input2_mfs[7];
static TriangularMF output_mfs[7];
static FuzzyRule    rule_base[49];

/* ========================================================================
 * INTERNAL HELPERS
 * ======================================================================== */

/**
 * @brief Compute lower MF bounds from UMF parameters and scale factor
 *
 * Requires mf->a, mf->b, mf->c to be set before calling.
 * Computes mf->a_lower, mf->c_lower, and mf->lower_height.
 *
 * @param mf: Pointer to MF (a, b, c must already be set)
 * @param k: Scale factor (0.0 to 1.0)
 */
static void ComputeLowerMF(TriangularMF* mf, float k) {
#if FOU_PATTERN == 0
    /* Pattern 0: Wide FOU at edges, narrow at center */
    mf->a_lower = mf->b - (mf->b - mf->a) * k;
    mf->c_lower = mf->b + (mf->c - mf->b) * k;
#else
    /* Pattern 1: Wide FOU at center, narrow at edges */
    mf->a_lower = mf->b - (mf->b - mf->a) * (1.0f - k);
    mf->c_lower = mf->b + (mf->c - mf->b) * (1.0f - k);
#endif
    mf->lower_height = LMF_HEIGHT;
}

/**
 * @brief Compute IT2 triangular MF membership (upper and lower)
 * @param x: Input value
 * @param mf: Pointer to IT2 triangular MF
 * @param result: Output firing interval [upper, lower]
 */
static void IT2_Triangular_MF(float x, const TriangularMF* mf, IT2_FiringInterval* result) {
    /* Compute Upper MF (standard triangle, peak = 1.0) */
    if (x <= mf->a || x >= mf->c) {
        result->upper = 0.0f;
    } else if (x == mf->b) {
        result->upper = 1.0f;
    } else if (x < mf->b) {
        result->upper = (x - mf->a) / (mf->b - mf->a);
    } else {
        result->upper = (mf->c - x) / (mf->c - mf->b);
    }

    /* Compute Lower MF (narrower triangle, peak = lower_height) */
    if (x <= mf->a_lower || x >= mf->c_lower) {
        result->lower = 0.0f;
    } else if (x == mf->b) {
        result->lower = mf->lower_height;
    } else if (x < mf->b) {
        result->lower = mf->lower_height * (x - mf->a_lower) / (mf->b - mf->a_lower);
    } else {
        result->lower = mf->lower_height * (mf->c_lower - x) / (mf->c_lower - mf->b);
    }
}

/* ========================================================================
 * PUBLIC FUNCTIONS
 * ======================================================================== */

/**
 * @brief Initialize the Interval Type-2 Fuzzy Logic System
 *
 * UMF: Original Type-1 triangular MFs with peak = 1.0
 * LMF: Computed via ComputeLowerMF() with per-MF scale factors
 * FOU pattern: Selected by FOU_PATTERN define
 */
int InitializeFuzzySystem(FuzzySystem* system) {
    if (system == NULL) {
        return -1;
    }

    /* ====================================================================
     * INPUT 1: Error (Voltage Error)
     * Range: [-60, 60] volts
     * Scale factors (k): NB/PB=0.2, NM/PM=0.45, NS/PS=0.7, Z=0.95
     * ==================================================================== */
    strcpy(system->inputs[0].name, "Error");
    system->inputs[0].min = -60.0f;
    system->inputs[0].max = 60.0f;
    system->inputs[0].numMFs = 7;
    system->inputs[0].mfs = input1_mfs;

    /* MF0: NB - k=0.2 */
    input1_mfs[0].a = -60.0f;
    input1_mfs[0].b = -50.0f;
    input1_mfs[0].c = -30.0f;
    ComputeLowerMF(&input1_mfs[0], 0.2f);

    /* MF1: NM - k=0.45 */
    input1_mfs[1].a = -40.0f;
    input1_mfs[1].b = -25.0f;
    input1_mfs[1].c = -10.0f;
    ComputeLowerMF(&input1_mfs[1], 0.45f);

    /* MF2: NS - k=0.7 */
    input1_mfs[2].a = -15.0f;
    input1_mfs[2].b = -5.0f;
    input1_mfs[2].c = 0.0f;
    ComputeLowerMF(&input1_mfs[2], 0.7f);

    /* MF3: Z - k=0.95 */
    input1_mfs[3].a = -5.0f;
    input1_mfs[3].b = 0.0f;
    input1_mfs[3].c = 5.0f;
    ComputeLowerMF(&input1_mfs[3], 0.95f);

    /* MF4: PS - k=0.7 */
    input1_mfs[4].a = 0.0f;
    input1_mfs[4].b = 5.0f;
    input1_mfs[4].c = 15.0f;
    ComputeLowerMF(&input1_mfs[4], 0.7f);

    /* MF5: PM - k=0.45 */
    input1_mfs[5].a = 10.0f;
    input1_mfs[5].b = 25.0f;
    input1_mfs[5].c = 40.0f;
    ComputeLowerMF(&input1_mfs[5], 0.45f);

    /* MF6: PB - k=0.2 */
    input1_mfs[6].a = 30.0f;
    input1_mfs[6].b = 50.0f;
    input1_mfs[6].c = 60.0f;
    ComputeLowerMF(&input1_mfs[6], 0.2f);

    /* ====================================================================
     * INPUT 2: dError (Error Derivative)
     * Same structure as Error input
     * ==================================================================== */
    strcpy(system->inputs[1].name, "dError");
    system->inputs[1].min = -60.0f;
    system->inputs[1].max = 60.0f;
    system->inputs[1].numMFs = 7;
    system->inputs[1].mfs = input2_mfs;

    memcpy(input2_mfs, input1_mfs, 7 * sizeof(TriangularMF));

    /* ====================================================================
     * OUTPUT: mi (Modulation Index)
     * Range: [0, 2] - NO NEGATIVE VALUES
     * ==================================================================== */
    strcpy(system->output.name, "mi");
    system->output.min = 0.0f;
    system->output.max = 2.0f;
    system->output.numMFs = 7;
    system->output.mfs = output_mfs;

    /* MF0: NB - k=0.2, peak at 0 (left boundary) */
    output_mfs[0].a = 0.0f;
    output_mfs[0].b = 0.0f;
    output_mfs[0].c = 0.333f;
    ComputeLowerMF(&output_mfs[0], 0.2f);

    /* MF1: NM - k=0.45, peak at 0.333 */
    output_mfs[1].a = 0.0f;
    output_mfs[1].b = 0.333f;
    output_mfs[1].c = 0.667f;
    ComputeLowerMF(&output_mfs[1], 0.45f);

    /* MF2: NS - k=0.7, peak at 0.75 */
    output_mfs[2].a = 0.5f;
    output_mfs[2].b = 0.75f;
    output_mfs[2].c = 1.0f;
    ComputeLowerMF(&output_mfs[2], 0.7f);

    /* MF3: Z - k=0.95, peak at 1.0 */
    output_mfs[3].a = 0.917f;
    output_mfs[3].b = 1.0f;
    output_mfs[3].c = 1.083f;
    ComputeLowerMF(&output_mfs[3], 0.95f);

    /* MF4: PS - k=0.7, peak at 1.25 */
    output_mfs[4].a = 1.0f;
    output_mfs[4].b = 1.25f;
    output_mfs[4].c = 1.5f;
    ComputeLowerMF(&output_mfs[4], 0.7f);

    /* MF5: PM - k=0.45, peak at 1.667 */
    output_mfs[5].a = 1.333f;
    output_mfs[5].b = 1.667f;
    output_mfs[5].c = 2.0f;
    ComputeLowerMF(&output_mfs[5], 0.45f);

    /* MF6: PB - k=0.2, peak at 2.0 (right boundary) */
    output_mfs[6].a = 1.667f;
    output_mfs[6].b = 2.0f;
    output_mfs[6].c = 2.0f;
    ComputeLowerMF(&output_mfs[6], 0.2f);

    /* ====================================================================
     * RULE BASE: 49 rules (7x7) from MATLAB .fis
     *
     * Textbook convention: error = target - measured
     *   Positive error (PB) = voltage too low  -> increase MI
     *   Negative error (NB) = voltage too high -> decrease MI
     *
     * Rule table (output MF index):
     * dE:      NB  NM  NS   Z  PS  PM  PB
     * E: NB  [  0   0   1   1   2   2   3 ]
     *    NM  [  0   1   1   2   2   3   4 ]
     *    NS  [  1   1   2   2   3   4   4 ]
     *     Z  [  1   2   3   3   3   4   5 ]
     *    PS  [  2   2   3   4   4   5   5 ]
     *    PM  [  2   3   4   4   5   5   6 ]
     *    PB  [  3   4   4   5   5   6   6 ]
     * ==================================================================== */
    system->numRules = 49;
    system->rules = rule_base;

    /* Row 1: Error=NB (0) - Voltage TOO HIGH -> DECREASE MI */
    rule_base[0]  = (FuzzyRule){0, 0, 0, 1.0f};
    rule_base[1]  = (FuzzyRule){0, 1, 0, 1.0f};
    rule_base[2]  = (FuzzyRule){0, 2, 1, 1.0f};
    rule_base[3]  = (FuzzyRule){0, 3, 1, 1.0f};
    rule_base[4]  = (FuzzyRule){0, 4, 2, 1.0f};
    rule_base[5]  = (FuzzyRule){0, 5, 2, 1.0f};
    rule_base[6]  = (FuzzyRule){0, 6, 3, 1.0f};

    /* Row 2: Error=NM (1) */
    rule_base[7]  = (FuzzyRule){1, 0, 0, 1.0f};
    rule_base[8]  = (FuzzyRule){1, 1, 1, 1.0f};
    rule_base[9]  = (FuzzyRule){1, 2, 1, 1.0f};
    rule_base[10] = (FuzzyRule){1, 3, 2, 1.0f};
    rule_base[11] = (FuzzyRule){1, 4, 2, 1.0f};
    rule_base[12] = (FuzzyRule){1, 5, 3, 1.0f};
    rule_base[13] = (FuzzyRule){1, 6, 4, 1.0f};

    /* Row 3: Error=NS (2) */
    rule_base[14] = (FuzzyRule){2, 0, 1, 1.0f};
    rule_base[15] = (FuzzyRule){2, 1, 1, 1.0f};
    rule_base[16] = (FuzzyRule){2, 2, 2, 1.0f};
    rule_base[17] = (FuzzyRule){2, 3, 2, 1.0f};
    rule_base[18] = (FuzzyRule){2, 4, 3, 1.0f};
    rule_base[19] = (FuzzyRule){2, 5, 4, 1.0f};
    rule_base[20] = (FuzzyRule){2, 6, 4, 1.0f};

    /* Row 4: Error=Z (3) - Voltage ON TARGET -> hold MI near 1.0 */
    rule_base[21] = (FuzzyRule){3, 0, 1, 1.0f};
    rule_base[22] = (FuzzyRule){3, 1, 2, 1.0f};
    rule_base[23] = (FuzzyRule){3, 2, 3, 1.0f};
    rule_base[24] = (FuzzyRule){3, 3, 3, 1.0f};
    rule_base[25] = (FuzzyRule){3, 4, 3, 1.0f};
    rule_base[26] = (FuzzyRule){3, 5, 4, 1.0f};
    rule_base[27] = (FuzzyRule){3, 6, 5, 1.0f};

    /* Row 5: Error=PS (4) */
    rule_base[28] = (FuzzyRule){4, 0, 2, 1.0f};
    rule_base[29] = (FuzzyRule){4, 1, 2, 1.0f};
    rule_base[30] = (FuzzyRule){4, 2, 3, 1.0f};
    rule_base[31] = (FuzzyRule){4, 3, 4, 1.0f};
    rule_base[32] = (FuzzyRule){4, 4, 4, 1.0f};
    rule_base[33] = (FuzzyRule){4, 5, 5, 1.0f};
    rule_base[34] = (FuzzyRule){4, 6, 5, 1.0f};

    /* Row 6: Error=PM (5) */
    rule_base[35] = (FuzzyRule){5, 0, 2, 1.0f};
    rule_base[36] = (FuzzyRule){5, 1, 3, 1.0f};
    rule_base[37] = (FuzzyRule){5, 2, 4, 1.0f};
    rule_base[38] = (FuzzyRule){5, 3, 4, 1.0f};
    rule_base[39] = (FuzzyRule){5, 4, 5, 1.0f};
    rule_base[40] = (FuzzyRule){5, 5, 5, 1.0f};
    rule_base[41] = (FuzzyRule){5, 6, 6, 1.0f};

    /* Row 7: Error=PB (6) - Voltage TOO LOW -> INCREASE MI */
    rule_base[42] = (FuzzyRule){6, 0, 3, 1.0f};
    rule_base[43] = (FuzzyRule){6, 1, 4, 1.0f};
    rule_base[44] = (FuzzyRule){6, 2, 4, 1.0f};
    rule_base[45] = (FuzzyRule){6, 3, 5, 1.0f};
    rule_base[46] = (FuzzyRule){6, 4, 5, 1.0f};
    rule_base[47] = (FuzzyRule){6, 5, 6, 1.0f};
    rule_base[48] = (FuzzyRule){6, 6, 6, 1.0f};

    printf("IT2 Fuzzy: 49 rules, FOU pattern %d\r\n", FOU_PATTERN);
    return 0;
}

/**
 * @brief IT2 Fuzzy Inference with Nie-Tan Type-Reduction
 *
 * @param system: Pointer to initialized fuzzy system
 * @param input1: Error input
 * @param input2: Error derivative input
 * @param y_upper: Output pointer for upper centroid (NULL if not needed)
 * @param y_lower: Output pointer for lower centroid (NULL if not needed)
 * @return Crisp modulation index output
 */
float FuzzyInference(FuzzySystem* system, float input1, float input2,
                     float* y_upper, float* y_lower) {
    /* Storage for input MF firing intervals */
    IT2_FiringInterval input1_intervals[7];
    IT2_FiringInterval input2_intervals[7];

    /* Step 1: Fuzzify inputs */
    for (int i = 0; i < 7; i++) {
        IT2_Triangular_MF(input1, &system->inputs[0].mfs[i], &input1_intervals[i]);
    }
    for (int i = 0; i < 7; i++) {
        IT2_Triangular_MF(input2, &system->inputs[1].mfs[i], &input2_intervals[i]);
    }

    /* Step 2: Rule evaluation and type-reduction accumulators */
    float upper_num = 0.0f;
    float upper_den = 0.0f;
    float lower_num = 0.0f;
    float lower_den = 0.0f;

    for (int r = 0; r < system->numRules; r++) {
        FuzzyRule* rule = &system->rules[r];

        IT2_FiringInterval* e_interval = &input1_intervals[rule->input1MF];
        IT2_FiringInterval* de_interval = &input2_intervals[rule->input2MF];

        float f_upper = fminf(e_interval->upper, de_interval->upper) * rule->weight;
        float f_lower = fminf(e_interval->lower, de_interval->lower) * rule->weight;

        float output_center = system->output.mfs[rule->outputMF].b;

        upper_num += f_upper * output_center;
        upper_den += f_upper;
        lower_num += f_lower * output_center;
        lower_den += f_lower;
    }

    /* Step 3: Compute centroids */
    float yu = (upper_den > 0.0001f) ? (upper_num / upper_den) : 1.0f;
    float yl = (lower_den > 0.0001f) ? (lower_num / lower_den) : 1.0f;

    /* Return debug values if requested */
    if (y_upper != NULL) *y_upper = yu;
    if (y_lower != NULL) *y_lower = yl;

    /* Step 4: Nie-Tan defuzzification */
    return (yu + yl) / 2.0f;
}
