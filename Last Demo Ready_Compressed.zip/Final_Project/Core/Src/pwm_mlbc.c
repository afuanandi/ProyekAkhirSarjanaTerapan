/**
 * @file pwm_mlbc.c
 * @brief Multi-Level Boost Converter (MLBC) PWM Control Implementation
 * @author afuanandi
 * @date 2025
 *
 * Pure PWM control module. Fault detection is handled by main.c.
 * This module manages: soft-start, duty cycle, state machine, hardware output.
 */

#include "pwm_mlbc.h"
#include "pod_pwm.h"  // For POD_PWM_Enable() integration

/* Global MLBC structure */
MLBC_TypeDef mlbc;

/**
 * @brief Initialize MLBC system
 */
void MLBC_Init(void) {
    memset(&mlbc, 0, sizeof(MLBC_TypeDef));

    mlbc.state = MLBC_STATE_STOPPED;

    /* Start PWM timer but with 0% duty cycle */
    HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_1);
    MLBC_Apply_PWM();

    printf("MLBC initialized with soft-start capability\r\n");
}

/**
 * @brief Main MLBC update function (call from main loop)
 * Handles the state machine and soft-start progression.
 */
void MLBC_Update(void) {
    mlbc.system_tick = HAL_GetTick();

    switch(mlbc.state) {
        case MLBC_STATE_STOPPED:
            mlbc.duty_cycle = 0.0f;
            mlbc.soft_start_active = 0;
            break;

        case MLBC_STATE_SOFT_START:
            if(mlbc.soft_start_active) {
                uint32_t elapsed = mlbc.system_tick - mlbc.soft_start_begin_time;

                if(elapsed >= mlbc.soft_start_duration_ms) {
                    /* Ramp finished: hand over to target duty cycle */
                    mlbc.duty_cycle = mlbc.soft_start_target_duty;
                    mlbc.state = MLBC_STATE_RUNNING;
                    mlbc.soft_start_active = 0;
                } else {
                    /* Linear ramp */
                    float progress = (float)elapsed / (float)mlbc.soft_start_duration_ms;
                    mlbc.duty_cycle = MLBC_SOFT_START_INITIAL_DUTY +
                                     (progress * (mlbc.soft_start_target_duty - MLBC_SOFT_START_INITIAL_DUTY));

                    if(mlbc.duty_cycle > mlbc.soft_start_target_duty) {
                        mlbc.duty_cycle = mlbc.soft_start_target_duty;
                    }
                }
            } else {
                /* Safeguard: if in SOFT_START state but flag is lost */
                mlbc.state = MLBC_STATE_STOPPED;
            }
            break;

        case MLBC_STATE_RUNNING:
            /* Normal operation: output follows user-defined target */
            mlbc.duty_cycle = mlbc.target_duty_cycle;
            break;

        case MLBC_STATE_SHUTDOWN:
            /* Immediate transition to stopped */
            mlbc.duty_cycle = 0.0f;
            mlbc.state = MLBC_STATE_STOPPED;
            break;
    }

    /* Push duty cycle to hardware */
    MLBC_Apply_PWM();

#if ENABLE_MLBC_DEBUG
    mlbc.debug_counter++;
#endif
}

/**
 * @brief Start the MLBC system with soft-start
 */
void MLBC_Start(void) {
    if(mlbc.state != MLBC_STATE_STOPPED) {
        printf("MLBC start failed - system not stopped (current state: %d)\r\n", mlbc.state);
        return;
    }

    /* Initialize soft-start parameters */
    mlbc.soft_start_begin_time = mlbc.system_tick;
    mlbc.soft_start_target_duty = mlbc.target_duty_cycle;
    mlbc.soft_start_active = 1;

    /* Enter soft-start state */
    mlbc.state = MLBC_STATE_SOFT_START;

    /* Enable POD PWM immediately — inverter switches concurrently during soft-start
     * as DC bus voltage rises, so does inverter output. This provides a
     * charge path for the inverter capacitors from the start. */
    POD_PWM_Enable(1);
}

/**
 * @brief Stop the MLBC system
 * Called during normal shutdown and after fault-triggered discharge completes.
 */
void MLBC_Stop(void) {
    if(mlbc.state != MLBC_STATE_STOPPED && mlbc.state != MLBC_STATE_SHUTDOWN) {
        mlbc.state = MLBC_STATE_SHUTDOWN;
        mlbc.soft_start_active = 0;

        /* Disable inverter */
        POD_PWM_Enable(0);
    }
}

/**
 * @brief Set target duty cycle
 */
void MLBC_Set_Target_Duty_Cycle(float duty) {
    if(duty < MLBC_MIN_DUTY_CYCLE) duty = MLBC_MIN_DUTY_CYCLE;
    if(duty > MLBC_MAX_DUTY_CYCLE) duty = MLBC_MAX_DUTY_CYCLE;

    mlbc.target_duty_cycle = duty;

    /* If currently in soft-start, update the target */
    if(mlbc.soft_start_active) {
        mlbc.soft_start_target_duty = duty;
    }
}

/**
 * @brief Get target duty cycle
 */
float MLBC_Get_Target_Duty_Cycle(void) { return mlbc.target_duty_cycle; }

/**
 * @brief Set soft-start duration
 */
void MLBC_Set_Soft_Start_Duration(uint32_t duration_ms) {
    if(duration_ms < 1000) {
        printf("WARNING: Soft-start duration %.1fs is very short - minimum 1s recommended\r\n",
               duration_ms / 1000.0f);
    }

    mlbc.soft_start_duration_ms = duration_ms;
    printf("MLBC soft-start duration set to %.1fs\r\n", duration_ms / 1000.0f);
}

/**
 * @brief Get soft-start progress percentage
 */
float MLBC_Get_Soft_Start_Progress(void) {
    if(!mlbc.soft_start_active) {
        return 0.0f;
    }

    uint32_t elapsed = mlbc.system_tick - mlbc.soft_start_begin_time;
    float progress = (float)elapsed / (float)mlbc.soft_start_duration_ms * 100.0f;

    if(progress > 100.0f) progress = 100.0f;

    return progress;
}

/**
 * @brief Set debug flag
 */
void MLBC_Set_Debug(uint8_t flag) {
    mlbc.debug_flag = flag;
    printf("MLBC debug %s\r\n", flag ? "enabled" : "disabled");
}

float MLBC_Get_Duty_Cycle(void) { return mlbc.duty_cycle; }
MLBC_State_t MLBC_Get_State(void) { return mlbc.state; }

/**
 * @brief Apply PWM duty cycle to hardware timer
 */
void MLBC_Apply_PWM(void) {
    /* TIM2 period configured for 40kHz: Period = 90MHz / 40kHz - 1 = 2249 */
    uint32_t compare_value = (uint32_t)(mlbc.duty_cycle * (float)(htim2.Init.Period + 1));

    if(compare_value > htim2.Init.Period) {
        compare_value = htim2.Init.Period;
    }

    __HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_1, compare_value);
}

/**
 * @brief Transmit debug data via UART (call from main loop)
 */
#if ENABLE_MLBC_DEBUG
void MLBC_Debug_Transmit(void) {
    extern volatile MonitoringMode_t monitoring_mode;

    if(mlbc.debug_flag && monitoring_mode == MONITORING_MODE_OFF) {
        char debug_buffer[MLBC_DEBUG_BUFFER_SIZE];

        if(mlbc.soft_start_active) {
            float progress = MLBC_Get_Soft_Start_Progress();
            uint32_t elapsed = mlbc.system_tick - mlbc.soft_start_begin_time;
            uint32_t remaining = (mlbc.soft_start_duration_ms > elapsed) ?
                                (mlbc.soft_start_duration_ms - elapsed) : 0;

            snprintf(debug_buffer, sizeof(debug_buffer),
                "MLBC_SOFTSTART,%lu,%.1f,%.3f,%.3f,%lums\r\n",
                mlbc.debug_counter,
                progress,
                mlbc.duty_cycle,
                mlbc.soft_start_target_duty,
                remaining);
        } else {
            const char* state_str;
            switch(mlbc.state) {
                case MLBC_STATE_STOPPED:    state_str = "STOPPED"; break;
                case MLBC_STATE_SOFT_START: state_str = "SOFTSTART"; break;
                case MLBC_STATE_RUNNING:    state_str = "RUNNING"; break;
                case MLBC_STATE_SHUTDOWN:   state_str = "SHUTDOWN"; break;
                default:                    state_str = "UNKNOWN"; break;
            }

            snprintf(debug_buffer, sizeof(debug_buffer),
                "MLBC_%s,%lu,%.3f,%.3f\r\n",
                state_str,
                mlbc.debug_counter,
                mlbc.target_duty_cycle,
                mlbc.duty_cycle);
        }

        printf("%s", debug_buffer);
    }
}
#endif
