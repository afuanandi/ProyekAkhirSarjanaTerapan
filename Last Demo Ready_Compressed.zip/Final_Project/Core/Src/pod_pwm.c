/**
 * @file pod_pwm.c
 * @brief Phase Opposition Disposition PWM for 7-Level PUCI Inverter
 * @version 3.3 - Dual Mode Implementation
 * @author afuanandi & Claude
 * @date 2025
 *
 * Based on https://doi.org/10.1109/TIA.2020.3008397 and proved to works
 */

#include "pod_pwm.h"
#include "sine_lut.h"
#include "math.h"
#include "stdio.h"

/* ========== GLOBAL VARIABLES ========== */

POD_PWM_TypeDef pod_pwm;

/* ========== SWITCHING PATTERNS ========== */

/**
 * Switching patterns for 7-level PUCI inverter
 *
 * Organization: [Level][Pattern][Switch]
 * - Level index: 0=+3, 1=+2, 2=+1, 3=0, 4=-1, 5=-2, 6=-3
 * - Pattern index: 0, 1, 2 (rotated for capacitor balancing)
 * - Switch order: S1, S2, S3, S4, S5, S6, S7, S8
 *
 * Three patterns are used to balance flying capacitor voltages
 * by distributing switching stress evenly across devices.
 */
static const uint8_t SwitchingPatterns[7][3][8] = {
    // Level +3
    {{1,0,0,0,0,1,1,1}, {1,0,0,0,0,1,1,1}, {1,0,0,0,0,1,1,1}},
    // Level +2
    {{1,0,1,0,0,1,0,1}, {1,1,0,0,0,0,1,1}, {1,0,0,1,0,1,1,0}},
    // Level +1
    {{1,0,1,1,0,1,0,0}, {1,1,0,1,0,0,1,0}, {1,1,1,0,0,0,0,1}},
    // Level 0
    {{0,0,0,0,1,1,1,1}, {0,0,0,0,1,1,1,1}, {0,0,0,0,1,1,1,1}},
    // Level -1
    {{0,1,0,0,1,0,1,1}, {0,0,1,0,1,1,0,1}, {0,0,0,1,1,1,1,0}},
    // Level -2
    {{0,1,0,1,1,0,1,0}, {0,0,1,1,1,1,0,0}, {0,1,1,0,1,0,0,1}},
    // Level -3
    {{0,1,1,1,1,0,0,0}, {0,1,1,1,1,0,0,0}, {0,1,1,1,1,0,0,0}}
};

/* ========== INTERNAL FUNCTION PROTOTYPES ========== */

static void POD_PWM_Generate_Sine_Reference(void);
static float POD_PWM_Get_Sine_LUT(float phase);

#if TRUE_PWM == 1
/* Multi-carrier POD mode functions */
static void POD_PWM_Generate_Carriers(void);
static int8_t POD_PWM_Determine_Level_Carrier(float ref);
#else
/* Fixed threshold mode functions */
static int8_t POD_PWM_Determine_Level_Threshold(float ref);
#endif

/* ========== PUBLIC FUNCTIONS ========== */

void POD_PWM_Init(void) {
    /* Initialize all structure members to default values */
    pod_pwm.reference = 0.0f;
    pod_pwm.reference_phase = 0.0f;
    pod_pwm.modulation_index = 1.0f;
    pod_pwm.mode = POD_PWM_MODE_OPEN_LOOP;
    pod_pwm.current_level = 0;
    pod_pwm.target_level = 0;
    pod_pwm.manual_level = 0;
    pod_pwm.last_level = 0;
    pod_pwm.pattern_index = 0;
    pod_pwm.system_enabled = 0;

#if ENABLE_POD_PWM_DEBUG
    pod_pwm.debug_counter = 0;
    pod_pwm.debug_flag = 0;
    pod_pwm.debug_buffer_index = 0;
    pod_pwm.debug_buffer_ready = 0;
#endif


#if TRUE_PWM == 1
    /* Initialize carrier-specific variables */
    pod_pwm.carrier_state = 0;
    for(int i = 0; i < 6; i++) {
        pod_pwm.carriers[i] = 0.0f;
    }
#endif

    /* Synchronize timer counters to prevent phase mismatch */
    __HAL_TIM_SET_COUNTER(&htim1, 0);
    __HAL_TIM_SET_COUNTER(&htim8, 0);

    /* Start timers */
    HAL_TIM_Base_Start_IT(&htim1);
    HAL_TIM_Base_Start(&htim8);

    /* Start all PWM channels with complementary outputs */
    HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_1);
    HAL_TIMEx_PWMN_Start(&htim1, TIM_CHANNEL_1);
    HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_2);
    HAL_TIMEx_PWMN_Start(&htim1, TIM_CHANNEL_2);

    HAL_TIM_PWM_Start(&htim8, TIM_CHANNEL_1);
    HAL_TIMEx_PWMN_Start(&htim8, TIM_CHANNEL_1);
    HAL_TIM_PWM_Start(&htim8, TIM_CHANNEL_2);
    HAL_TIMEx_PWMN_Start(&htim8, TIM_CHANNEL_2);

    /* Initialize output to safe state (level 0) */
    POD_PWM_Apply_Switching_States(0, 0);

    /* Print initialization message */
#if TRUE_PWM == 1
    printf("POD PWM v3.3 - Multi-Carrier POD Method\r\n");
    printf("Carrier frequency: %.1f kHz\r\n", CARRIER_FREQ / 1000.0f);
    printf("POD phase arrangement: Positive in-phase, Negative opposite\r\n");
#else
    printf("POD PWM v3.3 - Fixed Threshold Method\r\n");
    printf("Thresholds: ±0.5, ±1.5, ±2.5\r\n");
    printf("Rate limiting: ±1 level per ISR call\r\n");
#endif
    printf("Update frequency: %.1f kHz\r\n", UPDATE_FREQ / 1000.0f);
    printf("Fundamental frequency: %.0f Hz\r\n", FUNDAMENTAL_FREQ);
}

void POD_PWM_Update_Reference(void) {
    /* Safety check - disable output if system is not enabled */
    if(!pod_pwm.system_enabled) {
        pod_pwm.reference = 0.0f;
        pod_pwm.current_level = 0;
        pod_pwm.target_level = 0;
        POD_PWM_Apply_Switching_States(0, 0);
#if ENABLE_POD_PWM_DEBUG
        pod_pwm.debug_counter++;
#endif
        return;
    }

    /* Step 1: Generate 50Hz sine reference */
    POD_PWM_Generate_Sine_Reference();

    int8_t new_target_level;

#if TRUE_PWM == 1
    /* ========== MULTI-CARRIER POD METHOD ========== */

    /* Generate 6 software carriers with POD phase arrangement */
    POD_PWM_Generate_Carriers();

    /* Determine output level by comparing reference against carriers */
    if(pod_pwm.mode == POD_PWM_MODE_MANUAL_LEVEL) {
        new_target_level = pod_pwm.manual_level;
    } else {
        new_target_level = POD_PWM_Determine_Level_Carrier(pod_pwm.reference);
    }

    /* Apply level directly without rate limiting - allows natural PWM */
    pod_pwm.target_level = new_target_level;
    pod_pwm.current_level = pod_pwm.target_level;

#else
    /* ========== FIXED THRESHOLD METHOD ========== */

    /* Determine output level using fixed threshold comparison */
    if(pod_pwm.mode == POD_PWM_MODE_MANUAL_LEVEL) {
        new_target_level = pod_pwm.manual_level;
    } else {
        new_target_level = POD_PWM_Determine_Level_Threshold(pod_pwm.reference);
    }

    /* Apply rate limiting to prevent excessive switching */
    if(new_target_level > pod_pwm.last_level + 1) {
    	pod_pwm.target_level = pod_pwm.last_level + 1;
    } else if(new_target_level < pod_pwm.last_level - 1) {
    	pod_pwm.target_level = pod_pwm.last_level - 1;
    } else {
    	pod_pwm.target_level = new_target_level;
    }

    pod_pwm.current_level = pod_pwm.target_level;
    pod_pwm.last_level = pod_pwm.current_level;
#endif

    /* Step 2: Apply switching pattern to hardware */
    POD_PWM_Apply_Switching_States(pod_pwm.current_level, pod_pwm.pattern_index);

    /* Step 3: Collect debug data if enabled */
#if ENABLE_POD_PWM_DEBUG
    if(pod_pwm.debug_flag && !pod_pwm.debug_buffer_ready) {
        uint32_t buffer_size = DEBUG_SAMPLES_PER_CYCLE * DEBUG_CYCLES_TO_CAPTURE;
        if(pod_pwm.debug_buffer_index < buffer_size) {
            DebugSample *sample = &pod_pwm.debug_buffer[pod_pwm.debug_buffer_index];
            sample->reference = pod_pwm.reference;
            sample->level = pod_pwm.current_level;
            sample->pattern_index = pod_pwm.pattern_index;
#if TRUE_PWM == 1
            sample->carrier_state = pod_pwm.carrier_state;
#endif

            pod_pwm.debug_buffer_index++;
            if(pod_pwm.debug_buffer_index >= buffer_size) {
                pod_pwm.debug_buffer_ready = 1;
            }
        }
    }
    pod_pwm.debug_counter++;
#endif
}

void POD_PWM_Apply_Switching_States(int8_t level, uint8_t pattern) {
    /* Get switching state from lookup table */
    SwitchingState state = POD_PWM_Get_Switching_State(level, pattern);

    /* Get timer period for CCR calculation */
    uint16_t period = htim1.Init.Period;

    /* Write CCR values to hardware - discrete ON/OFF only */
    __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_1, state.S1 ? period : 0);
    __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_2, state.S2 ? period : 0);
    __HAL_TIM_SET_COMPARE(&htim8, TIM_CHANNEL_1, state.S3 ? period : 0);
    __HAL_TIM_SET_COMPARE(&htim8, TIM_CHANNEL_2, state.S4 ? period : 0);
}

SwitchingState POD_PWM_Get_Switching_State(int8_t level, uint8_t pattern) {
    SwitchingState state;

    /* Map voltage level (-3 to +3) to array index (0 to 6) */
    int table_index;
    switch(level) {
        case  3: table_index = 0; break;
        case  2: table_index = 1; break;
        case  1: table_index = 2; break;
        case  0: table_index = 3; break;
        case -1: table_index = 4; break;
        case -2: table_index = 5; break;
        case -3: table_index = 6; break;
        default: table_index = 3; break;  // Safe default to level 0
    }

    /* Validate pattern index */
    if(pattern >= NUM_PATTERNS) pattern = 0;

    /* Extract switching state from lookup table */
    const uint8_t *p = SwitchingPatterns[table_index][pattern];
    state.S1 = p[0];
    state.S2 = p[1];
    state.S3 = p[2];
    state.S4 = p[3];
    state.S5 = p[4];
    state.S6 = p[5];
    state.S7 = p[6];
    state.S8 = p[7];

    return state;
}

void POD_PWM_Handle_Pattern_Switching(void) {
    /* Rotate through 3 patterns: 0 → 1 → 2 → 0 */
    pod_pwm.pattern_index = (pod_pwm.pattern_index + 1) % NUM_PATTERNS;
}

/* ========== CONTROL INTERFACE ========== */

void POD_PWM_Set_Mode(POD_PWM_Mode_t mode) {
    pod_pwm.mode = mode;
}

void POD_PWM_Set_MI(float mi) {
    if(mi < 0.0f) mi = 0.0f;
    if(mi > MAX_MODULATION_INDEX) mi = MAX_MODULATION_INDEX;
    pod_pwm.modulation_index = mi;
}

float POD_PWM_Get_Current_MI(void) {
    return pod_pwm.modulation_index;
}

void POD_PWM_Set_Manual_Level(int8_t level) {
    if(level < -3) level = -3;
    if(level > 3) level = 3;
    pod_pwm.manual_level = level;
}

void POD_PWM_Enable(uint8_t enable) {
    pod_pwm.system_enabled = enable;

    if(enable) {
        /* Reset state for clean start */
        pod_pwm.reference_phase = 0.0f;
        pod_pwm.reference = 0.0f;
        pod_pwm.pattern_index = 0;
        pod_pwm.current_level = 0;
        pod_pwm.target_level = 0;
        pod_pwm.last_level = 0;
    } else {
        /* Force safe state when disabled */
        POD_PWM_Apply_Switching_States(0, 0);
    }
}

void POD_PWM_Set_Debug(uint8_t flag) {
	pod_pwm.debug_flag = flag;
    printf("POD PWM debug %s\r\n", flag ? "enabled" : "disabled");
}

void POD_PWM_Reset_Debug_Counter(void) {
#if ENABLE_POD_PWM_DEBUG
    pod_pwm.debug_counter = 0;
    pod_pwm.debug_buffer_index = 0;
    pod_pwm.debug_buffer_ready = 0;
#endif
}

void POD_PWM_Debug_Transmit(void) {
#if ENABLE_POD_PWM_DEBUG
    if(pod_pwm.debug_flag && pod_pwm.debug_buffer_ready && monitoring_mode == MONITORING_MODE_OFF){
        /* Print CSV header */
#if TRUE_PWM == 1
        printf("Index,Reference,Level,Pattern,CarrierState\r\n");
#else
        printf("Index,Reference,Level,Pattern\r\n");
#endif

        /* Transmit all samples */
        for(uint32_t i = 0; i < pod_pwm.debug_buffer_index; i++) {
            DebugSample *s = &pod_pwm.debug_buffer[i];
#if TRUE_PWM == 1
            printf("%lu,%.3f,%d,%d,%d\r\n",
                i, s->reference, s->level, s->pattern_index, s->carrier_state);
#else
            printf("%lu,%.3f,%d,%d\r\n",
                i, s->reference, s->level, s->pattern_index);
#endif
        }

        /* Reset buffer for next capture */
        pod_pwm.debug_buffer_index = 0;
        pod_pwm.debug_buffer_ready = 0;
    }
#endif
}

/* ========== INTERNAL FUNCTIONS ========== */

static void POD_PWM_Generate_Sine_Reference(void) {
    /* Increment phase accumulator */
    pod_pwm.reference_phase += (FUNDAMENTAL_FREQ / UPDATE_FREQ);

    /* Handle phase wrap-around and trigger pattern switching */
    if(pod_pwm.reference_phase >= 1.0f) {
        pod_pwm.reference_phase -= 1.0f;
        POD_PWM_Handle_Pattern_Switching();
    }

    /* Get sine value from lookup table */
    float sine_value = POD_PWM_Get_Sine_LUT(pod_pwm.reference_phase * TWO_PI);

    /* Scale to voltage reference range (-3.0 to +3.0) */
    pod_pwm.reference = pod_pwm.modulation_index * 3.0f * sine_value;
}

static float POD_PWM_Get_Sine_LUT(float phase) {
    /* Convert phase (0 to 2π) to lookup table index */
    float index_float = (phase / TWO_PI) * (float)SINE_LUT_SIZE;

    /* Apply -90° phase shift for cosine-like start (low-to-high voltage) */
    index_float -= (float)SINE_LUT_SIZE / 4.0f;
    if(index_float < 0.0f) {
        index_float += (float)SINE_LUT_SIZE;
    }

    /* Convert to integer index with bounds checking */
    uint32_t index = (uint32_t)index_float;
    if(index >= SINE_LUT_SIZE) index = 0;

    return sine_lut[index];
}

#if TRUE_PWM == 1
/* ========== MULTI-CARRIER POD MODE ========== */

static void POD_PWM_Generate_Carriers(void) {
    pod_pwm.carrier_state = !pod_pwm.carrier_state;

    /* Generate */
    float triangle_wave = pod_pwm.carrier_state ? 0.5f : -0.5f;

    /* Update Carriers */
    pod_pwm.carriers[0] = 2.5f + triangle_wave;
    pod_pwm.carriers[1] = 1.5f + triangle_wave;
    pod_pwm.carriers[2] = 0.5f + triangle_wave;
    pod_pwm.carriers[3] = -0.5f - triangle_wave;
    pod_pwm.carriers[4] = -1.5f - triangle_wave;
    pod_pwm.carriers[5] = -2.5f - triangle_wave;
}

static int8_t POD_PWM_Determine_Level_Carrier(float ref) {
    /* Compare reference against all 6 carriers in descending order */
    if(ref > pod_pwm.carriers[0]) return 3;
    if(ref > pod_pwm.carriers[1]) return 2;
    if(ref > pod_pwm.carriers[2]) return 1;
    if(ref > pod_pwm.carriers[3]) return 0;
    if(ref > pod_pwm.carriers[4]) return -1;
    if(ref > pod_pwm.carriers[5]) return -2;
    return -3;
}

#else
/* ========== FIXED THRESHOLD MODE ========== */

static int8_t POD_PWM_Determine_Level_Threshold(float ref) {
    /* Compare reference against fixed thresholds */
    if(ref > 2.5f) return 3;
    else if(ref > 1.5f) return 2;
    else if(ref > 0.5f) return 1;
    else if(ref > -0.5f) return 0;
    else if(ref > -1.5f) return -1;
    else if(ref > -2.5f) return -2;
    else return -3;
}

#endif
