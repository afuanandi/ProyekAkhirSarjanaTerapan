Core/Src/fuzzy_init.o: ../Core/Src/fuzzy_init.c ../Core/Inc/fuzzy_init.h \
 ../Core/Inc/fuzzy_structures.h
../Core/Inc/fuzzy_init.h:
../Core/Inc/fuzzy_structures.h:
