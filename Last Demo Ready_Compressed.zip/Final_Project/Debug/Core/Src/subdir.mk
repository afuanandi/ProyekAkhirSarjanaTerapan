################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (11.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Core/Src/ac_sensor.c \
../Core/Src/adc.c \
../Core/Src/button_handler.c \
../Core/Src/dc_sensor.c \
../Core/Src/dma.c \
../Core/Src/fuzzy_controller.c \
../Core/Src/fuzzy_init.c \
../Core/Src/gpio.c \
../Core/Src/i2c.c \
../Core/Src/main.c \
../Core/Src/monitoring_dma.c \
../Core/Src/oled_display.c \
../Core/Src/pod_pwm.c \
../Core/Src/pwm_mlbc.c \
../Core/Src/sh1106.c \
../Core/Src/stm32f4xx_hal_msp.c \
../Core/Src/stm32f4xx_it.c \
../Core/Src/syscalls.c \
../Core/Src/sysmem.c \
../Core/Src/system_stm32f4xx.c \
../Core/Src/tim.c \
../Core/Src/usart.c 

OBJS += \
./Core/Src/ac_sensor.o \
./Core/Src/adc.o \
./Core/Src/button_handler.o \
./Core/Src/dc_sensor.o \
./Core/Src/dma.o \
./Core/Src/fuzzy_controller.o \
./Core/Src/fuzzy_init.o \
./Core/Src/gpio.o \
./Core/Src/i2c.o \
./Core/Src/main.o \
./Core/Src/monitoring_dma.o \
./Core/Src/oled_display.o \
./Core/Src/pod_pwm.o \
./Core/Src/pwm_mlbc.o \
./Core/Src/sh1106.o \
./Core/Src/stm32f4xx_hal_msp.o \
./Core/Src/stm32f4xx_it.o \
./Core/Src/syscalls.o \
./Core/Src/sysmem.o \
./Core/Src/system_stm32f4xx.o \
./Core/Src/tim.o \
./Core/Src/usart.o 

C_DEPS += \
./Core/Src/ac_sensor.d \
./Core/Src/adc.d \
./Core/Src/button_handler.d \
./Core/Src/dc_sensor.d \
./Core/Src/dma.d \
./Core/Src/fuzzy_controller.d \
./Core/Src/fuzzy_init.d \
./Core/Src/gpio.d \
./Core/Src/i2c.d \
./Core/Src/main.d \
./Core/Src/monitoring_dma.d \
./Core/Src/oled_display.d \
./Core/Src/pod_pwm.d \
./Core/Src/pwm_mlbc.d \
./Core/Src/sh1106.d \
./Core/Src/stm32f4xx_hal_msp.d \
./Core/Src/stm32f4xx_it.d \
./Core/Src/syscalls.d \
./Core/Src/sysmem.d \
./Core/Src/system_stm32f4xx.d \
./Core/Src/tim.d \
./Core/Src/usart.d 


# Each subdirectory must supply rules for building sources it contributes
Core/Src/%.o Core/Src/%.su Core/Src/%.cyclo: ../Core/Src/%.c Core/Src/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F446xx -c -I../Core/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../Drivers/CMSIS/Include -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-Core-2f-Src

clean-Core-2f-Src:
	-$(RM) ./Core/Src/ac_sensor.cyclo ./Core/Src/ac_sensor.d ./Core/Src/ac_sensor.o ./Core/Src/ac_sensor.su ./Core/Src/adc.cyclo ./Core/Src/adc.d ./Core/Src/adc.o ./Core/Src/adc.su ./Core/Src/button_handler.cyclo ./Core/Src/button_handler.d ./Core/Src/button_handler.o ./Core/Src/button_handler.su ./Core/Src/dc_sensor.cyclo ./Core/Src/dc_sensor.d ./Core/Src/dc_sensor.o ./Core/Src/dc_sensor.su ./Core/Src/dma.cyclo ./Core/Src/dma.d ./Core/Src/dma.o ./Core/Src/dma.su ./Core/Src/fuzzy_controller.cyclo ./Core/Src/fuzzy_controller.d ./Core/Src/fuzzy_controller.o ./Core/Src/fuzzy_controller.su ./Core/Src/fuzzy_init.cyclo ./Core/Src/fuzzy_init.d ./Core/Src/fuzzy_init.o ./Core/Src/fuzzy_init.su ./Core/Src/gpio.cyclo ./Core/Src/gpio.d ./Core/Src/gpio.o ./Core/Src/gpio.su ./Core/Src/i2c.cyclo ./Core/Src/i2c.d ./Core/Src/i2c.o ./Core/Src/i2c.su ./Core/Src/main.cyclo ./Core/Src/main.d ./Core/Src/main.o ./Core/Src/main.su ./Core/Src/monitoring_dma.cyclo ./Core/Src/monitoring_dma.d ./Core/Src/monitoring_dma.o ./Core/Src/monitoring_dma.su ./Core/Src/oled_display.cyclo ./Core/Src/oled_display.d ./Core/Src/oled_display.o ./Core/Src/oled_display.su ./Core/Src/pod_pwm.cyclo ./Core/Src/pod_pwm.d ./Core/Src/pod_pwm.o ./Core/Src/pod_pwm.su ./Core/Src/pwm_mlbc.cyclo ./Core/Src/pwm_mlbc.d ./Core/Src/pwm_mlbc.o ./Core/Src/pwm_mlbc.su ./Core/Src/sh1106.cyclo ./Core/Src/sh1106.d ./Core/Src/sh1106.o ./Core/Src/sh1106.su ./Core/Src/stm32f4xx_hal_msp.cyclo ./Core/Src/stm32f4xx_hal_msp.d ./Core/Src/stm32f4xx_hal_msp.o ./Core/Src/stm32f4xx_hal_msp.su ./Core/Src/stm32f4xx_it.cyclo ./Core/Src/stm32f4xx_it.d ./Core/Src/stm32f4xx_it.o ./Core/Src/stm32f4xx_it.su ./Core/Src/syscalls.cyclo ./Core/Src/syscalls.d ./Core/Src/syscalls.o ./Core/Src/syscalls.su ./Core/Src/sysmem.cyclo ./Core/Src/sysmem.d ./Core/Src/sysmem.o ./Core/Src/sysmem.su ./Core/Src/system_stm32f4xx.cyclo ./Core/Src/system_stm32f4xx.d ./Core/Src/system_stm32f4xx.o ./Core/Src/system_stm32f4xx.su ./Core/Src/tim.cyclo ./Core/Src/tim.d ./Core/Src/tim.o ./Core/Src/tim.su ./Core/Src/usart.cyclo ./Core/Src/usart.d ./Core/Src/usart.o ./Core/Src/usart.su

.PHONY: clean-Core-2f-Src

